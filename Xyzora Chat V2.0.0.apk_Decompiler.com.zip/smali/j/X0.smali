###### Class j.X0 (j.X0)
.class public final Lj/X0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz0/b;
.implements LY1/b;


# instance fields
.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;

.field public i:Ljava/lang/Object;

.field public j:Ljava/lang/Object;

.field public k:Ljava/lang/Object;


# virtual methods
.method public a(Lb2/s;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lj/X0;->h:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashSet;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public get()Ljava/lang/Object;
    .registers 12

    .line 1
    iget-object v0, p0, Lj/X0;->e:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ld0/n;

    .line 4
    .line 5
    iget-object v0, v0, Ld0/n;->f:Ljava/lang/Object;

    .line 6
    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Landroid/content/Context;

    .line 9
    .line 10
    iget-object v0, p0, Lj/X0;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Ln2/a;

    .line 13
    .line 14
    invoke-interface {v0}, Ln2/a;->get()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    move-object v3, v0

    .line 19
    check-cast v3, Ly0/f;

    .line 20
    .line 21
    iget-object v0, p0, Lj/X0;->g:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Ln2/a;

    .line 24
    .line 25
    invoke-interface {v0}, Ln2/a;->get()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    move-object v4, v0

    .line 30
    check-cast v4, LE0/d;

    .line 31
    .line 32
    iget-object v0, p0, Lj/X0;->h:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, LC0/f;

    .line 35
    .line 36
    invoke-virtual {v0}, LC0/f;->get()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    move-object v5, v0

    .line 41
    check-cast v5, LD0/d;

    .line 42
    .line 43
    iget-object v0, p0, Lj/X0;->i:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v0, Ln2/a;

    .line 46
    .line 47
    invoke-interface {v0}, Ln2/a;->get()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    move-object v6, v0

    .line 52
    check-cast v6, Ljava/util/concurrent/Executor;

    .line 53
    .line 54
    iget-object v0, p0, Lj/X0;->j:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v0, Ln2/a;

    .line 57
    .line 58
    invoke-interface {v0}, Ln2/a;->get()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    move-object v7, v0

    .line 63
    check-cast v7, LF0/c;

    .line 64
    .line 65
    new-instance v8, LM0/f;

    .line 66
    .line 67
    const/4 v0, 0x5

    .line 68
    invoke-direct {v8, v0}, LM0/f;-><init>(I)V

    .line 69
    .line 70
    .line 71
    new-instance v9, LJ0/g;

    .line 72
    .line 73
    const/4 v0, 0x5

    .line 74
    invoke-direct {v9, v0}, LJ0/g;-><init>(I)V

    .line 75
    .line 76
    .line 77
    iget-object v0, p0, Lj/X0;->k:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v0, Ln2/a;

    .line 80
    .line 81
    invoke-interface {v0}, Ln2/a;->get()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    move-object v10, v0

    .line 86
    check-cast v10, LE0/c;

    .line 87
    .line 88
    new-instance v1, LD0/m;

    .line 89
    .line 90
    invoke-direct/range {v1 .. v10}, LD0/m;-><init>(Landroid/content/Context;Ly0/f;LE0/d;LD0/d;Ljava/util/concurrent/Executor;LF0/c;LG0/a;LG0/a;LE0/c;)V

    .line 91
    .line 92
    .line 93
    return-object v1
.end method
