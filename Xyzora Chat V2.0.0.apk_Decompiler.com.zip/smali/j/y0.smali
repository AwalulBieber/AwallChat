###### Class j.C0190y0 (j.y0)
.class public final Lj/y0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic e:Landroidx/appcompat/widget/SearchView;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/SearchView;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lj/y0;->e:Landroidx/appcompat/widget/SearchView;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 6

    .line 1
    iget-object p1, p0, Lj/y0;->e:Landroidx/appcompat/widget/SearchView;

    .line 2
    .line 3
    invoke-virtual {p1, p3}, Landroidx/appcompat/widget/SearchView;->l(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
