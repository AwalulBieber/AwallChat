###### Class j.C0170o (j.o)
.class public final Lj/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:Landroid/graphics/PorterDuff$Mode;

.field public static c:Lj/o;


# instance fields
.field public a:Lj/p0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 2
    .line 3
    sput-object v0, Lj/o;->b:Landroid/graphics/PorterDuff$Mode;

    .line 4
    .line 5
    return-void
.end method

.method public static declared-synchronized b()V
    .registers 7

    .line 1
    const/4 v0, 0x7

    .line 2
    const-class v1, Lj/o;

    .line 3
    .line 4
    monitor-enter v1

    .line 5
    :try_start_4
    sget-object v2, Lj/o;->c:Lj/o;

    .line 6
    .line 7
    if-nez v2, :cond_71

    .line 8
    .line 9
    new-instance v2, Lj/o;

    .line 10
    .line 11
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    sput-object v2, Lj/o;->c:Lj/o;

    .line 15
    .line 16
    invoke-static {}, Lj/p0;->b()Lj/p0;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    iput-object v3, v2, Lj/o;->a:Lj/p0;

    .line 21
    .line 22
    sget-object v2, Lj/o;->c:Lj/o;

    .line 23
    .line 24
    iget-object v2, v2, Lj/o;->a:Lj/p0;

    .line 25
    .line 26
    new-instance v3, Lg1/s;

    .line 27
    .line 28
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 29
    .line 30
    .line 31
    const v4, 0x7f07004a

    .line 32
    .line 33
    .line 34
    const/high16 v5, 0x7f070000

    .line 35
    .line 36
    const v6, 0x7f07004c

    .line 37
    .line 38
    .line 39
    filled-new-array {v6, v4, v5}, [I

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    iput-object v4, v3, Lg1/s;->a:Ljava/lang/Object;

    .line 44
    .line 45
    new-array v4, v0, [I

    .line 46
    .line 47
    fill-array-data v4, :array_76

    .line 48
    .line 49
    .line 50
    iput-object v4, v3, Lg1/s;->b:Ljava/lang/Object;

    .line 51
    .line 52
    new-array v0, v0, [I

    .line 53
    .line 54
    fill-array-data v0, :array_88

    .line 55
    .line 56
    .line 57
    iput-object v0, v3, Lg1/s;->c:Ljava/lang/Object;

    .line 58
    .line 59
    const v0, 0x7f07000f

    .line 60
    .line 61
    .line 62
    const v4, 0x7f070030

    .line 63
    .line 64
    .line 65
    const v5, 0x7f070031

    .line 66
    .line 67
    .line 68
    filled-new-array {v5, v0, v4}, [I

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iput-object v0, v3, Lg1/s;->d:Ljava/lang/Object;

    .line 73
    .line 74
    const v0, 0x7f070043

    .line 75
    .line 76
    .line 77
    const v4, 0x7f07004d

    .line 78
    .line 79
    .line 80
    filled-new-array {v0, v4}, [I

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    iput-object v0, v3, Lg1/s;->e:Ljava/lang/Object;

    .line 85
    .line 86
    const v0, 0x7f070004

    .line 87
    .line 88
    .line 89
    const v4, 0x7f07000a

    .line 90
    .line 91
    .line 92
    const v5, 0x7f070003

    .line 93
    .line 94
    .line 95
    const v6, 0x7f070009

    .line 96
    .line 97
    .line 98
    filled-new-array {v5, v6, v0, v4}, [I

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    iput-object v0, v3, Lg1/s;->f:Ljava/lang/Object;

    .line 103
    .line 104
    monitor-enter v2
    :try_end_68
    .catchall {:try_start_4 .. :try_end_68} :catchall_6f

    .line 105
    :try_start_68
    iput-object v3, v2, Lj/p0;->e:Lg1/s;
    :try_end_6a
    .catchall {:try_start_68 .. :try_end_6a} :catchall_6c

    .line 106
    .line 107
    :try_start_6a
    monitor-exit v2
    :try_end_6b
    .catchall {:try_start_6a .. :try_end_6b} :catchall_6f

    .line 108
    goto :goto_71

    .line 109
    :catchall_6c
    move-exception v0

    .line 110
    :try_start_6d
    monitor-exit v2
    :try_end_6e
    .catchall {:try_start_6d .. :try_end_6e} :catchall_6c

    .line 111
    :try_start_6e
    throw v0
    :try_end_6f
    .catchall {:try_start_6e .. :try_end_6f} :catchall_6f

    .line 112
    :catchall_6f
    move-exception v0

    .line 113
    goto :goto_73

    .line 114
    :cond_71
    :goto_71
    monitor-exit v1

    .line 115
    return-void

    .line 116
    :goto_73
    :try_start_73
    monitor-exit v1
    :try_end_74
    .catchall {:try_start_73 .. :try_end_74} :catchall_6f

    .line 117
    throw v0

    .line 118
    nop

    .line 119
    :array_76
    .array-data 4
        0x7f070018
        0x7f07003b
        0x7f07001f
        0x7f07001a
        0x7f07001b
        0x7f07001e
        0x7f07001d
    .end array-data

    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    :array_88
    .array-data 4
        0x7f070049
        0x7f07004b
        0x7f070011
        0x7f070045
        0x7f070046
        0x7f070047
        0x7f070048
    .end array-data
.end method

.method public static c(Landroid/graphics/drawable/Drawable;LX/d;[I)V
    .registers 7

    .line 1
    sget-object v0, Lj/p0;->f:Landroid/graphics/PorterDuff$Mode;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Lj/P;->a:[I

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-ne v1, p0, :cond_53

    .line 14
    .line 15
    instance-of v1, p0, Landroid/graphics/drawable/LayerDrawable;

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    if-eqz v1, :cond_21

    .line 19
    .line 20
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_21

    .line 25
    .line 26
    new-array v1, v2, [I

    .line 27
    .line 28
    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 32
    .line 33
    .line 34
    :cond_21
    iget-boolean v0, p1, LX/d;->b:Z

    .line 35
    .line 36
    if-nez v0, :cond_2e

    .line 37
    .line 38
    iget-boolean v1, p1, LX/d;->a:Z

    .line 39
    .line 40
    if-eqz v1, :cond_2a

    .line 41
    .line 42
    goto :goto_2e

    .line 43
    :cond_2a
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->clearColorFilter()V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_2e
    :goto_2e
    const/4 v1, 0x0

    .line 48
    if-eqz v0, :cond_36

    .line 49
    .line 50
    iget-object v0, p1, LX/d;->c:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v0, Landroid/content/res/ColorStateList;

    .line 53
    .line 54
    goto :goto_37

    .line 55
    :cond_36
    move-object v0, v1

    .line 56
    :goto_37
    iget-boolean v3, p1, LX/d;->a:Z

    .line 57
    .line 58
    if-eqz v3, :cond_40

    .line 59
    .line 60
    iget-object p1, p1, LX/d;->d:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast p1, Landroid/graphics/PorterDuff$Mode;

    .line 63
    .line 64
    goto :goto_42

    .line 65
    :cond_40
    sget-object p1, Lj/p0;->f:Landroid/graphics/PorterDuff$Mode;

    .line 66
    .line 67
    :goto_42
    if-eqz v0, :cond_4f

    .line 68
    .line 69
    if-nez p1, :cond_47

    .line 70
    .line 71
    goto :goto_4f

    .line 72
    :cond_47
    invoke-virtual {v0, p2, v2}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    .line 73
    .line 74
    .line 75
    move-result p2

    .line 76
    invoke-static {p2, p1}, Lj/p0;->e(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    :cond_4f
    :goto_4f
    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_53
    const-string p0, "ResourceManagerInternal"

    .line 85
    .line 86
    const-string p1, "Mutated drawable is not the same instance as the input."

    .line 87
    .line 88
    invoke-static {p0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 89
    .line 90
    .line 91
    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .registers 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lj/o;->a:Lj/p0;

    .line 3
    .line 4
    invoke-virtual {v0, p1, p2}, Lj/p0;->c(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 5
    .line 6
    .line 7
    move-result-object p1
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_9

    .line 8
    monitor-exit p0

    .line 9
    return-object p1

    .line 10
    :catchall_9
    move-exception p1

    .line 11
    :try_start_a
    monitor-exit p0
    :try_end_b
    .catchall {:try_start_a .. :try_end_b} :catchall_9

    .line 12
    throw p1
.end method
