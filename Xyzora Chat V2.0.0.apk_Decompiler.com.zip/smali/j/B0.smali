###### Class j.B0 (j.B0)
.class public interface abstract Lj/B0;
.super Ljava/lang/Object;
.source "SourceFile"
