###### Class j.A (j.A)
.class public final Lj/A;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/widget/TextView;

.field public b:LX/d;

.field public c:LX/d;

.field public d:LX/d;

.field public e:LX/d;

.field public f:LX/d;

.field public g:LX/d;

.field public h:LX/d;

.field public final i:Lj/K;

.field public j:I

.field public k:I

.field public l:Landroid/graphics/Typeface;

.field public m:Z


# direct methods
.method public constructor <init>(Landroid/widget/TextView;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lj/A;->j:I

    .line 6
    .line 7
    const/4 v0, -0x1

    .line 8
    iput v0, p0, Lj/A;->k:I

    .line 9
    .line 10
    iput-object p1, p0, Lj/A;->a:Landroid/widget/TextView;

    .line 11
    .line 12
    new-instance v0, Lj/K;

    .line 13
    .line 14
    invoke-direct {v0, p1}, Lj/K;-><init>(Landroid/widget/TextView;)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lj/A;->i:Lj/K;

    .line 18
    .line 19
    return-void
.end method

.method public static c(Landroid/content/Context;Lj/o;I)LX/d;
    .registers 4

    .line 1
    monitor-enter p1

    .line 2
    :try_start_1
    iget-object v0, p1, Lj/o;->a:Lj/p0;

    .line 3
    .line 4
    invoke-virtual {v0, p0, p2}, Lj/p0;->f(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 5
    .line 6
    .line 7
    move-result-object p0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_17

    .line 8
    monitor-exit p1

    .line 9
    if-eqz p0, :cond_15

    .line 10
    .line 11
    new-instance p1, LX/d;

    .line 12
    .line 13
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    const/4 p2, 0x1

    .line 17
    iput-boolean p2, p1, LX/d;->b:Z

    .line 18
    .line 19
    iput-object p0, p1, LX/d;->c:Ljava/lang/Object;

    .line 20
    .line 21
    return-object p1

    .line 22
    :cond_15
    const/4 p0, 0x0

    .line 23
    return-object p0

    .line 24
    :catchall_17
    move-exception p0

    .line 25
    :try_start_18
    monitor-exit p1
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_17

    .line 26
    throw p0
.end method


# virtual methods
.method public final a(Landroid/graphics/drawable/Drawable;LX/d;)V
    .registers 4

    .line 1
    if-eqz p1, :cond_d

    .line 2
    .line 3
    if-eqz p2, :cond_d

    .line 4
    .line 5
    iget-object v0, p0, Lj/A;->a:Landroid/widget/TextView;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/view/View;->getDrawableState()[I

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {p1, p2, v0}, Lj/o;->c(Landroid/graphics/drawable/Drawable;LX/d;[I)V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method

.method public final b()V
    .registers 7

    .line 1
    iget-object v0, p0, Lj/A;->b:LX/d;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object v3, p0, Lj/A;->a:Landroid/widget/TextView;

    .line 6
    .line 7
    if-nez v0, :cond_14

    .line 8
    .line 9
    iget-object v0, p0, Lj/A;->c:LX/d;

    .line 10
    .line 11
    if-nez v0, :cond_14

    .line 12
    .line 13
    iget-object v0, p0, Lj/A;->d:LX/d;

    .line 14
    .line 15
    if-nez v0, :cond_14

    .line 16
    .line 17
    iget-object v0, p0, Lj/A;->e:LX/d;

    .line 18
    .line 19
    if-eqz v0, :cond_36

    .line 20
    .line 21
    :cond_14
    invoke-virtual {v3}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    aget-object v4, v0, v2

    .line 26
    .line 27
    iget-object v5, p0, Lj/A;->b:LX/d;

    .line 28
    .line 29
    invoke-virtual {p0, v4, v5}, Lj/A;->a(Landroid/graphics/drawable/Drawable;LX/d;)V

    .line 30
    .line 31
    .line 32
    const/4 v4, 0x1

    .line 33
    aget-object v4, v0, v4

    .line 34
    .line 35
    iget-object v5, p0, Lj/A;->c:LX/d;

    .line 36
    .line 37
    invoke-virtual {p0, v4, v5}, Lj/A;->a(Landroid/graphics/drawable/Drawable;LX/d;)V

    .line 38
    .line 39
    .line 40
    aget-object v4, v0, v1

    .line 41
    .line 42
    iget-object v5, p0, Lj/A;->d:LX/d;

    .line 43
    .line 44
    invoke-virtual {p0, v4, v5}, Lj/A;->a(Landroid/graphics/drawable/Drawable;LX/d;)V

    .line 45
    .line 46
    .line 47
    const/4 v4, 0x3

    .line 48
    aget-object v0, v0, v4

    .line 49
    .line 50
    iget-object v4, p0, Lj/A;->e:LX/d;

    .line 51
    .line 52
    invoke-virtual {p0, v0, v4}, Lj/A;->a(Landroid/graphics/drawable/Drawable;LX/d;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    iget-object v0, p0, Lj/A;->f:LX/d;

    .line 56
    .line 57
    if-nez v0, :cond_40

    .line 58
    .line 59
    iget-object v0, p0, Lj/A;->g:LX/d;

    .line 60
    .line 61
    if-eqz v0, :cond_3f

    .line 62
    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    return-void

    .line 65
    :cond_40
    :goto_40
    invoke-static {v3}, Lj/w;->a(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    aget-object v2, v0, v2

    .line 70
    .line 71
    iget-object v3, p0, Lj/A;->f:LX/d;

    .line 72
    .line 73
    invoke-virtual {p0, v2, v3}, Lj/A;->a(Landroid/graphics/drawable/Drawable;LX/d;)V

    .line 74
    .line 75
    .line 76
    aget-object v0, v0, v1

    .line 77
    .line 78
    iget-object v1, p0, Lj/A;->g:LX/d;

    .line 79
    .line 80
    invoke-virtual {p0, v0, v1}, Lj/A;->a(Landroid/graphics/drawable/Drawable;LX/d;)V

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method public final d(Landroid/util/AttributeSet;I)V
    .registers 27

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v5, p1

    .line 4
    .line 5
    move/from16 v7, p2

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    iget-object v8, v1, Lj/A;->a:Landroid/widget/TextView;

    .line 9
    .line 10
    invoke-virtual {v8}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 11
    .line 12
    .line 13
    move-result-object v9

    .line 14
    sget-object v2, Lj/o;->b:Landroid/graphics/PorterDuff$Mode;

    .line 15
    .line 16
    const-class v2, Lj/o;

    .line 17
    .line 18
    monitor-enter v2

    .line 19
    :try_start_12
    sget-object v3, Lj/o;->c:Lj/o;

    .line 20
    .line 21
    if-nez v3, :cond_1d

    .line 22
    .line 23
    invoke-static {}, Lj/o;->b()V

    .line 24
    .line 25
    .line 26
    goto :goto_1d

    .line 27
    :catchall_1a
    move-exception v0

    .line 28
    goto/16 :goto_3ab

    .line 29
    .line 30
    :cond_1d
    :goto_1d
    sget-object v10, Lj/o;->c:Lj/o;
    :try_end_1f
    .catchall {:try_start_12 .. :try_end_1f} :catchall_1a

    .line 31
    .line 32
    monitor-exit v2

    .line 33
    sget-object v4, Le/a;->f:[I

    .line 34
    .line 35
    invoke-static {v9, v5, v4, v7}, LC0/f;->K(Landroid/content/Context;Landroid/util/AttributeSet;[II)LC0/f;

    .line 36
    .line 37
    .line 38
    move-result-object v11

    .line 39
    iget-object v2, v1, Lj/A;->a:Landroid/widget/TextView;

    .line 40
    .line 41
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    iget-object v6, v11, LC0/f;->g:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v6, Landroid/content/res/TypedArray;

    .line 48
    .line 49
    invoke-static/range {v2 .. v7}, LC/C;->c(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 50
    .line 51
    .line 52
    iget-object v2, v11, LC0/f;->g:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v2, Landroid/content/res/TypedArray;

    .line 55
    .line 56
    const/4 v12, 0x0

    .line 57
    const/4 v13, -0x1

    .line 58
    invoke-virtual {v2, v12, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    const/4 v14, 0x3

    .line 63
    invoke-virtual {v2, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 64
    .line 65
    .line 66
    move-result v4

    .line 67
    if-eqz v4, :cond_4e

    .line 68
    .line 69
    invoke-virtual {v2, v14, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 70
    .line 71
    .line 72
    move-result v4

    .line 73
    invoke-static {v9, v10, v4}, Lj/A;->c(Landroid/content/Context;Lj/o;I)LX/d;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    iput-object v4, v1, Lj/A;->b:LX/d;

    .line 78
    .line 79
    :cond_4e
    invoke-virtual {v2, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    if-eqz v4, :cond_5e

    .line 84
    .line 85
    invoke-virtual {v2, v0, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    invoke-static {v9, v10, v4}, Lj/A;->c(Landroid/content/Context;Lj/o;I)LX/d;

    .line 90
    .line 91
    .line 92
    move-result-object v4

    .line 93
    iput-object v4, v1, Lj/A;->c:LX/d;

    .line 94
    .line 95
    :cond_5e
    const/4 v15, 0x4

    .line 96
    invoke-virtual {v2, v15}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 97
    .line 98
    .line 99
    move-result v4

    .line 100
    if-eqz v4, :cond_6f

    .line 101
    .line 102
    invoke-virtual {v2, v15, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 103
    .line 104
    .line 105
    move-result v4

    .line 106
    invoke-static {v9, v10, v4}, Lj/A;->c(Landroid/content/Context;Lj/o;I)LX/d;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    iput-object v4, v1, Lj/A;->d:LX/d;

    .line 111
    .line 112
    :cond_6f
    const/4 v4, 0x2

    .line 113
    invoke-virtual {v2, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 114
    .line 115
    .line 116
    move-result v6

    .line 117
    if-eqz v6, :cond_80

    .line 118
    .line 119
    invoke-virtual {v2, v4, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 120
    .line 121
    .line 122
    move-result v6

    .line 123
    invoke-static {v9, v10, v6}, Lj/A;->c(Landroid/content/Context;Lj/o;I)LX/d;

    .line 124
    .line 125
    .line 126
    move-result-object v6

    .line 127
    iput-object v6, v1, Lj/A;->e:LX/d;

    .line 128
    .line 129
    :cond_80
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 130
    .line 131
    const/4 v14, 0x5

    .line 132
    invoke-virtual {v2, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 133
    .line 134
    .line 135
    move-result v17

    .line 136
    if-eqz v17, :cond_93

    .line 137
    .line 138
    invoke-virtual {v2, v14, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 139
    .line 140
    .line 141
    move-result v4

    .line 142
    invoke-static {v9, v10, v4}, Lj/A;->c(Landroid/content/Context;Lj/o;I)LX/d;

    .line 143
    .line 144
    .line 145
    move-result-object v4

    .line 146
    iput-object v4, v1, Lj/A;->f:LX/d;

    .line 147
    .line 148
    :cond_93
    const/4 v4, 0x6

    .line 149
    invoke-virtual {v2, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 150
    .line 151
    .line 152
    move-result v18

    .line 153
    if-eqz v18, :cond_a4

    .line 154
    .line 155
    invoke-virtual {v2, v4, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 156
    .line 157
    .line 158
    move-result v2

    .line 159
    invoke-static {v9, v10, v2}, Lj/A;->c(Landroid/content/Context;Lj/o;I)LX/d;

    .line 160
    .line 161
    .line 162
    move-result-object v2

    .line 163
    iput-object v2, v1, Lj/A;->g:LX/d;

    .line 164
    .line 165
    :cond_a4
    invoke-virtual {v11}, LC0/f;->O()V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v8}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    instance-of v2, v2, Landroid/text/method/PasswordTransformationMethod;

    .line 173
    .line 174
    sget-object v11, Le/a;->s:[I

    .line 175
    .line 176
    const/16 v4, 0x1a

    .line 177
    .line 178
    const/16 v0, 0xe

    .line 179
    .line 180
    const/16 v15, 0xd

    .line 181
    .line 182
    const/16 v14, 0xf

    .line 183
    .line 184
    if-eq v3, v13, :cond_f9

    .line 185
    .line 186
    new-instance v13, LC0/f;

    .line 187
    .line 188
    invoke-virtual {v9, v3, v11}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 189
    .line 190
    .line 191
    move-result-object v3

    .line 192
    invoke-direct {v13, v9, v3}, LC0/f;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 193
    .line 194
    .line 195
    if-nez v2, :cond_d3

    .line 196
    .line 197
    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 198
    .line 199
    .line 200
    move-result v20

    .line 201
    if-eqz v20, :cond_d3

    .line 202
    .line 203
    invoke-virtual {v3, v0, v12}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 204
    .line 205
    .line 206
    move-result v20

    .line 207
    move/from16 v21, v20

    .line 208
    .line 209
    const/16 v20, 0x1

    .line 210
    .line 211
    goto :goto_d7

    .line 212
    :cond_d3
    move/from16 v20, v12

    .line 213
    .line 214
    move/from16 v21, v20

    .line 215
    .line 216
    :goto_d7
    invoke-virtual {v1, v9, v13}, Lj/A;->f(Landroid/content/Context;LC0/f;)V

    .line 217
    .line 218
    .line 219
    invoke-virtual {v3, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 220
    .line 221
    .line 222
    move-result v22

    .line 223
    if-eqz v22, :cond_e5

    .line 224
    .line 225
    invoke-virtual {v3, v14}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v22

    .line 229
    goto :goto_e7

    .line 230
    :cond_e5
    const/16 v22, 0x0

    .line 231
    .line 232
    :goto_e7
    if-lt v6, v4, :cond_f4

    .line 233
    .line 234
    invoke-virtual {v3, v15}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 235
    .line 236
    .line 237
    move-result v23

    .line 238
    if-eqz v23, :cond_f4

    .line 239
    .line 240
    invoke-virtual {v3, v15}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object v3

    .line 244
    goto :goto_f5

    .line 245
    :cond_f4
    const/4 v3, 0x0

    .line 246
    :goto_f5
    invoke-virtual {v13}, LC0/f;->O()V

    .line 247
    .line 248
    .line 249
    goto :goto_100

    .line 250
    :cond_f9
    move/from16 v20, v12

    .line 251
    .line 252
    move/from16 v21, v20

    .line 253
    .line 254
    const/4 v3, 0x0

    .line 255
    const/16 v22, 0x0

    .line 256
    .line 257
    :goto_100
    new-instance v13, LC0/f;

    .line 258
    .line 259
    invoke-virtual {v9, v5, v11, v7, v12}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 260
    .line 261
    .line 262
    move-result-object v11

    .line 263
    invoke-direct {v13, v9, v11}, LC0/f;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 264
    .line 265
    .line 266
    if-nez v2, :cond_117

    .line 267
    .line 268
    invoke-virtual {v11, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 269
    .line 270
    .line 271
    move-result v23

    .line 272
    if-eqz v23, :cond_117

    .line 273
    .line 274
    invoke-virtual {v11, v0, v12}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 275
    .line 276
    .line 277
    move-result v21

    .line 278
    const/16 v20, 0x1

    .line 279
    .line 280
    :cond_117
    move/from16 v0, v21

    .line 281
    .line 282
    invoke-virtual {v11, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 283
    .line 284
    .line 285
    move-result v21

    .line 286
    if-eqz v21, :cond_123

    .line 287
    .line 288
    invoke-virtual {v11, v14}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 289
    .line 290
    .line 291
    move-result-object v22

    .line 292
    :cond_123
    if-lt v6, v4, :cond_12f

    .line 293
    .line 294
    invoke-virtual {v11, v15}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 295
    .line 296
    .line 297
    move-result v4

    .line 298
    if-eqz v4, :cond_12f

    .line 299
    .line 300
    invoke-virtual {v11, v15}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 301
    .line 302
    .line 303
    move-result-object v3

    .line 304
    :cond_12f
    const/16 v4, 0x1c

    .line 305
    .line 306
    if-lt v6, v4, :cond_144

    .line 307
    .line 308
    invoke-virtual {v11, v12}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 309
    .line 310
    .line 311
    move-result v4

    .line 312
    if-eqz v4, :cond_144

    .line 313
    .line 314
    const/4 v4, -0x1

    .line 315
    invoke-virtual {v11, v12, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 316
    .line 317
    .line 318
    move-result v6

    .line 319
    if-nez v6, :cond_144

    .line 320
    .line 321
    const/4 v4, 0x0

    .line 322
    invoke-virtual {v8, v12, v4}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 323
    .line 324
    .line 325
    :cond_144
    invoke-virtual {v1, v9, v13}, Lj/A;->f(Landroid/content/Context;LC0/f;)V

    .line 326
    .line 327
    .line 328
    invoke-virtual {v13}, LC0/f;->O()V

    .line 329
    .line 330
    .line 331
    if-nez v2, :cond_153

    .line 332
    .line 333
    if-eqz v20, :cond_153

    .line 334
    .line 335
    iget-object v2, v1, Lj/A;->a:Landroid/widget/TextView;

    .line 336
    .line 337
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 338
    .line 339
    .line 340
    :cond_153
    iget-object v0, v1, Lj/A;->l:Landroid/graphics/Typeface;

    .line 341
    .line 342
    if-eqz v0, :cond_165

    .line 343
    .line 344
    iget v2, v1, Lj/A;->k:I

    .line 345
    .line 346
    const/4 v4, -0x1

    .line 347
    if-ne v2, v4, :cond_162

    .line 348
    .line 349
    iget v2, v1, Lj/A;->j:I

    .line 350
    .line 351
    invoke-virtual {v8, v0, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 352
    .line 353
    .line 354
    goto :goto_165

    .line 355
    :cond_162
    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 356
    .line 357
    .line 358
    :cond_165
    :goto_165
    if-eqz v3, :cond_16a

    .line 359
    .line 360
    invoke-static {v8, v3}, Lj/y;->d(Landroid/widget/TextView;Ljava/lang/String;)Z

    .line 361
    .line 362
    .line 363
    :cond_16a
    if-eqz v22, :cond_173

    .line 364
    .line 365
    invoke-static/range {v22 .. v22}, Lj/x;->a(Ljava/lang/String;)Landroid/os/LocaleList;

    .line 366
    .line 367
    .line 368
    move-result-object v0

    .line 369
    invoke-static {v8, v0}, Lj/x;->b(Landroid/widget/TextView;Landroid/os/LocaleList;)V

    .line 370
    .line 371
    .line 372
    :cond_173
    sget-object v4, Le/a;->g:[I

    .line 373
    .line 374
    iget-object v0, v1, Lj/A;->i:Lj/K;

    .line 375
    .line 376
    iget-object v11, v0, Lj/K;->j:Landroid/content/Context;

    .line 377
    .line 378
    invoke-virtual {v11, v5, v4, v7, v12}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 379
    .line 380
    .line 381
    move-result-object v6

    .line 382
    iget-object v2, v0, Lj/K;->i:Landroid/widget/TextView;

    .line 383
    .line 384
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 385
    .line 386
    .line 387
    move-result-object v3

    .line 388
    const/4 v13, 0x2

    .line 389
    const/4 v14, 0x6

    .line 390
    invoke-static/range {v2 .. v7}, LC/C;->c(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;I)V

    .line 391
    .line 392
    .line 393
    const/4 v2, 0x5

    .line 394
    invoke-virtual {v6, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 395
    .line 396
    .line 397
    move-result v3

    .line 398
    if-eqz v3, :cond_195

    .line 399
    .line 400
    invoke-virtual {v6, v2, v12}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 401
    .line 402
    .line 403
    move-result v2

    .line 404
    iput v2, v0, Lj/K;->a:I

    .line 405
    .line 406
    :cond_195
    const/4 v2, 0x4

    .line 407
    invoke-virtual {v6, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 408
    .line 409
    .line 410
    move-result v3

    .line 411
    const/high16 v7, -0x40800000    # -1.0f

    .line 412
    .line 413
    if-eqz v3, :cond_1a3

    .line 414
    .line 415
    invoke-virtual {v6, v2, v7}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 416
    .line 417
    .line 418
    move-result v2

    .line 419
    goto :goto_1a4

    .line 420
    :cond_1a3
    move v2, v7

    .line 421
    :goto_1a4
    invoke-virtual {v6, v13}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 422
    .line 423
    .line 424
    move-result v3

    .line 425
    if-eqz v3, :cond_1b0

    .line 426
    .line 427
    invoke-virtual {v6, v13, v7}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 428
    .line 429
    .line 430
    move-result v3

    .line 431
    :goto_1ae
    const/4 v14, 0x1

    .line 432
    goto :goto_1b2

    .line 433
    :cond_1b0
    move v3, v7

    .line 434
    goto :goto_1ae

    .line 435
    :goto_1b2
    invoke-virtual {v6, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 436
    .line 437
    .line 438
    move-result v18

    .line 439
    if-eqz v18, :cond_1be

    .line 440
    .line 441
    invoke-virtual {v6, v14, v7}, Landroid/content/res/TypedArray;->getDimension(IF)F

    .line 442
    .line 443
    .line 444
    move-result v19

    .line 445
    :goto_1bc
    const/4 v14, 0x3

    .line 446
    goto :goto_1c1

    .line 447
    :cond_1be
    move/from16 v19, v7

    .line 448
    .line 449
    goto :goto_1bc

    .line 450
    :goto_1c1
    invoke-virtual {v6, v14}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 451
    .line 452
    .line 453
    move-result v16

    .line 454
    move/from16 p2, v7

    .line 455
    .line 456
    if-eqz v16, :cond_1fa

    .line 457
    .line 458
    invoke-virtual {v6, v14, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 459
    .line 460
    .line 461
    move-result v7

    .line 462
    if-lez v7, :cond_1fa

    .line 463
    .line 464
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->getResources()Landroid/content/res/Resources;

    .line 465
    .line 466
    .line 467
    move-result-object v14

    .line 468
    invoke-virtual {v14, v7}, Landroid/content/res/Resources;->obtainTypedArray(I)Landroid/content/res/TypedArray;

    .line 469
    .line 470
    .line 471
    move-result-object v7

    .line 472
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->length()I

    .line 473
    .line 474
    .line 475
    move-result v14

    .line 476
    new-array v15, v14, [I

    .line 477
    .line 478
    if-lez v14, :cond_1f7

    .line 479
    .line 480
    :goto_1df
    if-ge v12, v14, :cond_1ee

    .line 481
    .line 482
    const/4 v13, -0x1

    .line 483
    invoke-virtual {v7, v12, v13}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 484
    .line 485
    .line 486
    move-result v22

    .line 487
    aput v22, v15, v12

    .line 488
    .line 489
    const/16 v18, 0x1

    .line 490
    .line 491
    add-int/lit8 v12, v12, 0x1

    .line 492
    .line 493
    const/4 v13, 0x2

    .line 494
    goto :goto_1df

    .line 495
    :cond_1ee
    invoke-static {v15}, Lj/K;->b([I)[I

    .line 496
    .line 497
    .line 498
    move-result-object v12

    .line 499
    iput-object v12, v0, Lj/K;->f:[I

    .line 500
    .line 501
    invoke-virtual {v0}, Lj/K;->h()Z

    .line 502
    .line 503
    .line 504
    :cond_1f7
    invoke-virtual {v7}, Landroid/content/res/TypedArray;->recycle()V

    .line 505
    .line 506
    .line 507
    :cond_1fa
    invoke-virtual {v6}, Landroid/content/res/TypedArray;->recycle()V

    .line 508
    .line 509
    .line 510
    iget v6, v0, Lj/K;->a:I

    .line 511
    .line 512
    const/high16 v7, 0x3f800000    # 1.0f

    .line 513
    .line 514
    const/4 v14, 0x1

    .line 515
    if-ne v6, v14, :cond_234

    .line 516
    .line 517
    iget-boolean v6, v0, Lj/K;->g:Z

    .line 518
    .line 519
    if-nez v6, :cond_231

    .line 520
    .line 521
    invoke-virtual {v11}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 522
    .line 523
    .line 524
    move-result-object v6

    .line 525
    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 526
    .line 527
    .line 528
    move-result-object v6

    .line 529
    cmpl-float v11, v3, p2

    .line 530
    .line 531
    if-nez v11, :cond_21c

    .line 532
    .line 533
    const/high16 v3, 0x41400000    # 12.0f

    .line 534
    .line 535
    const/4 v13, 0x2

    .line 536
    invoke-static {v13, v3, v6}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 537
    .line 538
    .line 539
    move-result v3

    .line 540
    goto :goto_21d

    .line 541
    :cond_21c
    const/4 v13, 0x2

    .line 542
    :goto_21d
    cmpl-float v11, v19, p2

    .line 543
    .line 544
    if-nez v11, :cond_227

    .line 545
    .line 546
    const/high16 v11, 0x42e00000    # 112.0f

    .line 547
    .line 548
    invoke-static {v13, v11, v6}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 549
    .line 550
    .line 551
    move-result v19

    .line 552
    :cond_227
    move/from16 v6, v19

    .line 553
    .line 554
    cmpl-float v11, v2, p2

    .line 555
    .line 556
    if-nez v11, :cond_22e

    .line 557
    .line 558
    move v2, v7

    .line 559
    :cond_22e
    invoke-virtual {v0, v3, v6, v2}, Lj/K;->i(FFF)V

    .line 560
    .line 561
    .line 562
    :cond_231
    invoke-virtual {v0}, Lj/K;->g()Z

    .line 563
    .line 564
    .line 565
    :cond_234
    sget-boolean v2, Lj/a1;->a:Z

    .line 566
    .line 567
    if-eqz v2, :cond_265

    .line 568
    .line 569
    iget v2, v0, Lj/K;->a:I

    .line 570
    .line 571
    if-eqz v2, :cond_265

    .line 572
    .line 573
    iget-object v2, v0, Lj/K;->f:[I

    .line 574
    .line 575
    array-length v3, v2

    .line 576
    if-lez v3, :cond_265

    .line 577
    .line 578
    invoke-static {v8}, Lj/y;->a(Landroid/widget/TextView;)I

    .line 579
    .line 580
    .line 581
    move-result v3

    .line 582
    int-to-float v3, v3

    .line 583
    cmpl-float v3, v3, p2

    .line 584
    .line 585
    if-eqz v3, :cond_261

    .line 586
    .line 587
    iget v2, v0, Lj/K;->d:F

    .line 588
    .line 589
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 590
    .line 591
    .line 592
    move-result v2

    .line 593
    iget v3, v0, Lj/K;->e:F

    .line 594
    .line 595
    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    .line 596
    .line 597
    .line 598
    move-result v3

    .line 599
    iget v0, v0, Lj/K;->c:F

    .line 600
    .line 601
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 602
    .line 603
    .line 604
    move-result v0

    .line 605
    const/4 v6, 0x0

    .line 606
    invoke-static {v8, v2, v3, v0, v6}, Lj/y;->b(Landroid/widget/TextView;IIII)V

    .line 607
    .line 608
    .line 609
    goto :goto_265

    .line 610
    :cond_261
    const/4 v6, 0x0

    .line 611
    invoke-static {v8, v2, v6}, Lj/y;->c(Landroid/widget/TextView;[II)V

    .line 612
    .line 613
    .line 614
    :cond_265
    :goto_265
    invoke-virtual {v9, v5, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 615
    .line 616
    .line 617
    move-result-object v0

    .line 618
    const/16 v2, 0x8

    .line 619
    .line 620
    const/4 v4, -0x1

    .line 621
    invoke-virtual {v0, v2, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 622
    .line 623
    .line 624
    move-result v2

    .line 625
    if-eq v2, v4, :cond_279

    .line 626
    .line 627
    invoke-virtual {v10, v9, v2}, Lj/o;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 628
    .line 629
    .line 630
    move-result-object v2

    .line 631
    :goto_276
    const/16 v3, 0xd

    .line 632
    .line 633
    goto :goto_27b

    .line 634
    :cond_279
    const/4 v2, 0x0

    .line 635
    goto :goto_276

    .line 636
    :goto_27b
    invoke-virtual {v0, v3, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 637
    .line 638
    .line 639
    move-result v3

    .line 640
    if-eq v3, v4, :cond_286

    .line 641
    .line 642
    invoke-virtual {v10, v9, v3}, Lj/o;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 643
    .line 644
    .line 645
    move-result-object v3

    .line 646
    goto :goto_287

    .line 647
    :cond_286
    const/4 v3, 0x0

    .line 648
    :goto_287
    const/16 v5, 0x9

    .line 649
    .line 650
    invoke-virtual {v0, v5, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 651
    .line 652
    .line 653
    move-result v5

    .line 654
    if-eq v5, v4, :cond_295

    .line 655
    .line 656
    invoke-virtual {v10, v9, v5}, Lj/o;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 657
    .line 658
    .line 659
    move-result-object v5

    .line 660
    :goto_293
    const/4 v14, 0x6

    .line 661
    goto :goto_297

    .line 662
    :cond_295
    const/4 v5, 0x0

    .line 663
    goto :goto_293

    .line 664
    :goto_297
    invoke-virtual {v0, v14, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 665
    .line 666
    .line 667
    move-result v6

    .line 668
    if-eq v6, v4, :cond_2a2

    .line 669
    .line 670
    invoke-virtual {v10, v9, v6}, Lj/o;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 671
    .line 672
    .line 673
    move-result-object v6

    .line 674
    goto :goto_2a3

    .line 675
    :cond_2a2
    const/4 v6, 0x0

    .line 676
    :goto_2a3
    const/16 v11, 0xa

    .line 677
    .line 678
    invoke-virtual {v0, v11, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 679
    .line 680
    .line 681
    move-result v11

    .line 682
    if-eq v11, v4, :cond_2b0

    .line 683
    .line 684
    invoke-virtual {v10, v9, v11}, Lj/o;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 685
    .line 686
    .line 687
    move-result-object v11

    .line 688
    goto :goto_2b1

    .line 689
    :cond_2b0
    const/4 v11, 0x0

    .line 690
    :goto_2b1
    const/4 v12, 0x7

    .line 691
    invoke-virtual {v0, v12, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 692
    .line 693
    .line 694
    move-result v12

    .line 695
    if-eq v12, v4, :cond_2bd

    .line 696
    .line 697
    invoke-virtual {v10, v9, v12}, Lj/o;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 698
    .line 699
    .line 700
    move-result-object v4

    .line 701
    goto :goto_2be

    .line 702
    :cond_2bd
    const/4 v4, 0x0

    .line 703
    :goto_2be
    if-nez v11, :cond_315

    .line 704
    .line 705
    if-eqz v4, :cond_2c3

    .line 706
    .line 707
    goto :goto_315

    .line 708
    :cond_2c3
    if-nez v2, :cond_2cb

    .line 709
    .line 710
    if-nez v3, :cond_2cb

    .line 711
    .line 712
    if-nez v5, :cond_2cb

    .line 713
    .line 714
    if-eqz v6, :cond_338

    .line 715
    .line 716
    :cond_2cb
    invoke-static {v8}, Lj/w;->a(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 717
    .line 718
    .line 719
    move-result-object v4

    .line 720
    const/16 v20, 0x0

    .line 721
    .line 722
    aget-object v10, v4, v20

    .line 723
    .line 724
    if-nez v10, :cond_2fe

    .line 725
    .line 726
    const/16 v21, 0x2

    .line 727
    .line 728
    aget-object v11, v4, v21

    .line 729
    .line 730
    if-eqz v11, :cond_2dc

    .line 731
    .line 732
    goto :goto_2fe

    .line 733
    :cond_2dc
    invoke-virtual {v8}, Landroid/widget/TextView;->getCompoundDrawables()[Landroid/graphics/drawable/Drawable;

    .line 734
    .line 735
    .line 736
    move-result-object v4

    .line 737
    if-eqz v2, :cond_2e3

    .line 738
    .line 739
    goto :goto_2e5

    .line 740
    :cond_2e3
    aget-object v2, v4, v20

    .line 741
    .line 742
    :goto_2e5
    if-eqz v3, :cond_2e8

    .line 743
    .line 744
    goto :goto_2ec

    .line 745
    :cond_2e8
    const/16 v18, 0x1

    .line 746
    .line 747
    aget-object v3, v4, v18

    .line 748
    .line 749
    :goto_2ec
    if-eqz v5, :cond_2ef

    .line 750
    .line 751
    goto :goto_2f3

    .line 752
    :cond_2ef
    const/16 v21, 0x2

    .line 753
    .line 754
    aget-object v5, v4, v21

    .line 755
    .line 756
    :goto_2f3
    if-eqz v6, :cond_2f6

    .line 757
    .line 758
    goto :goto_2fa

    .line 759
    :cond_2f6
    const/16 v16, 0x3

    .line 760
    .line 761
    aget-object v6, v4, v16

    .line 762
    .line 763
    :goto_2fa
    invoke-virtual {v8, v2, v3, v5, v6}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 764
    .line 765
    .line 766
    goto :goto_338

    .line 767
    :cond_2fe
    :goto_2fe
    if-eqz v3, :cond_303

    .line 768
    .line 769
    :goto_300
    const/16 v21, 0x2

    .line 770
    .line 771
    goto :goto_308

    .line 772
    :cond_303
    const/16 v18, 0x1

    .line 773
    .line 774
    aget-object v3, v4, v18

    .line 775
    .line 776
    goto :goto_300

    .line 777
    :goto_308
    aget-object v2, v4, v21

    .line 778
    .line 779
    if-eqz v6, :cond_30d

    .line 780
    .line 781
    goto :goto_311

    .line 782
    :cond_30d
    const/16 v16, 0x3

    .line 783
    .line 784
    aget-object v6, v4, v16

    .line 785
    .line 786
    :goto_311
    invoke-static {v8, v10, v3, v2, v6}, Lj/w;->b(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 787
    .line 788
    .line 789
    goto :goto_338

    .line 790
    :cond_315
    :goto_315
    invoke-static {v8}, Lj/w;->a(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    .line 791
    .line 792
    .line 793
    move-result-object v2

    .line 794
    if-eqz v11, :cond_31c

    .line 795
    .line 796
    goto :goto_320

    .line 797
    :cond_31c
    const/16 v20, 0x0

    .line 798
    .line 799
    aget-object v11, v2, v20

    .line 800
    .line 801
    :goto_320
    if-eqz v3, :cond_323

    .line 802
    .line 803
    goto :goto_327

    .line 804
    :cond_323
    const/16 v18, 0x1

    .line 805
    .line 806
    aget-object v3, v2, v18

    .line 807
    .line 808
    :goto_327
    if-eqz v4, :cond_32a

    .line 809
    .line 810
    goto :goto_32e

    .line 811
    :cond_32a
    const/16 v21, 0x2

    .line 812
    .line 813
    aget-object v4, v2, v21

    .line 814
    .line 815
    :goto_32e
    if-eqz v6, :cond_331

    .line 816
    .line 817
    goto :goto_335

    .line 818
    :cond_331
    const/16 v16, 0x3

    .line 819
    .line 820
    aget-object v6, v2, v16

    .line 821
    .line 822
    :goto_335
    invoke-static {v8, v11, v3, v4, v6}, Lj/w;->b(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 823
    .line 824
    .line 825
    :cond_338
    :goto_338
    const/16 v2, 0xb

    .line 826
    .line 827
    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 828
    .line 829
    .line 830
    move-result v3

    .line 831
    if-eqz v3, :cond_35b

    .line 832
    .line 833
    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 834
    .line 835
    .line 836
    move-result v3

    .line 837
    if-eqz v3, :cond_354

    .line 838
    .line 839
    const/4 v6, 0x0

    .line 840
    invoke-virtual {v0, v2, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 841
    .line 842
    .line 843
    move-result v3

    .line 844
    if-eqz v3, :cond_354

    .line 845
    .line 846
    invoke-static {v9, v3}, La/a;->n(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 847
    .line 848
    .line 849
    move-result-object v3

    .line 850
    if-eqz v3, :cond_354

    .line 851
    .line 852
    goto :goto_358

    .line 853
    :cond_354
    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    .line 854
    .line 855
    .line 856
    move-result-object v3

    .line 857
    :goto_358
    invoke-virtual {v8, v3}, Landroid/widget/TextView;->setCompoundDrawableTintList(Landroid/content/res/ColorStateList;)V

    .line 858
    .line 859
    .line 860
    :cond_35b
    const/16 v2, 0xc

    .line 861
    .line 862
    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 863
    .line 864
    .line 865
    move-result v3

    .line 866
    const/4 v4, -0x1

    .line 867
    if-eqz v3, :cond_370

    .line 868
    .line 869
    invoke-virtual {v0, v2, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 870
    .line 871
    .line 872
    move-result v2

    .line 873
    const/4 v3, 0x0

    .line 874
    invoke-static {v2, v3}, Lj/P;->c(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 875
    .line 876
    .line 877
    move-result-object v2

    .line 878
    invoke-virtual {v8, v2}, Landroid/widget/TextView;->setCompoundDrawableTintMode(Landroid/graphics/PorterDuff$Mode;)V

    .line 879
    .line 880
    .line 881
    :cond_370
    const/16 v2, 0xf

    .line 882
    .line 883
    invoke-virtual {v0, v2, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 884
    .line 885
    .line 886
    move-result v2

    .line 887
    const/16 v3, 0x12

    .line 888
    .line 889
    invoke-virtual {v0, v3, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 890
    .line 891
    .line 892
    move-result v3

    .line 893
    const/16 v5, 0x13

    .line 894
    .line 895
    invoke-virtual {v0, v5, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 896
    .line 897
    .line 898
    move-result v5

    .line 899
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 900
    .line 901
    .line 902
    if-eq v2, v4, :cond_38a

    .line 903
    .line 904
    invoke-static {v8, v2}, La/a;->y(Landroid/widget/TextView;I)V

    .line 905
    .line 906
    .line 907
    :cond_38a
    if-eq v3, v4, :cond_38f

    .line 908
    .line 909
    invoke-static {v8, v3}, La/a;->z(Landroid/widget/TextView;I)V

    .line 910
    .line 911
    .line 912
    :cond_38f
    if-eq v5, v4, :cond_3aa

    .line 913
    .line 914
    if-ltz v5, :cond_3a4

    .line 915
    .line 916
    invoke-virtual {v8}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    .line 917
    .line 918
    .line 919
    move-result-object v0

    .line 920
    const/4 v3, 0x0

    .line 921
    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->getFontMetricsInt(Landroid/graphics/Paint$FontMetricsInt;)I

    .line 922
    .line 923
    .line 924
    move-result v0

    .line 925
    if-eq v5, v0, :cond_3aa

    .line 926
    .line 927
    sub-int/2addr v5, v0

    .line 928
    int-to-float v0, v5

    .line 929
    invoke-virtual {v8, v0, v7}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 930
    .line 931
    .line 932
    return-void

    .line 933
    :cond_3a4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 934
    .line 935
    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 936
    .line 937
    .line 938
    throw v0

    .line 939
    :cond_3aa
    return-void

    .line 940
    :goto_3ab
    :try_start_3ab
    monitor-exit v2
    :try_end_3ac
    .catchall {:try_start_3ab .. :try_end_3ac} :catchall_1a

    .line 941
    throw v0
.end method

.method public final e(Landroid/content/Context;I)V
    .registers 8

    .line 1
    sget-object v0, Le/a;->s:[I

    .line 2
    .line 3
    new-instance v1, LC0/f;

    .line 4
    .line 5
    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    invoke-direct {v1, p1, p2}, LC0/f;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 10
    .line 11
    .line 12
    const/16 v0, 0xe

    .line 13
    .line 14
    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    iget-object v3, p0, Lj/A;->a:Landroid/widget/TextView;

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    if-eqz v2, :cond_1d

    .line 22
    .line 23
    invoke-virtual {p2, v0, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 28
    .line 29
    .line 30
    :cond_1d
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 31
    .line 32
    invoke-virtual {p2, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    if-eqz v2, :cond_30

    .line 37
    .line 38
    const/4 v2, -0x1

    .line 39
    invoke-virtual {p2, v4, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    if-nez v2, :cond_30

    .line 44
    .line 45
    const/4 v2, 0x0

    .line 46
    invoke-virtual {v3, v4, v2}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 47
    .line 48
    .line 49
    :cond_30
    invoke-virtual {p0, p1, v1}, Lj/A;->f(Landroid/content/Context;LC0/f;)V

    .line 50
    .line 51
    .line 52
    const/16 p1, 0x1a

    .line 53
    .line 54
    if-lt v0, p1, :cond_48

    .line 55
    .line 56
    const/16 p1, 0xd

    .line 57
    .line 58
    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_48

    .line 63
    .line 64
    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    if-eqz p1, :cond_48

    .line 69
    .line 70
    invoke-static {v3, p1}, Lj/y;->d(Landroid/widget/TextView;Ljava/lang/String;)Z

    .line 71
    .line 72
    .line 73
    :cond_48
    invoke-virtual {v1}, LC0/f;->O()V

    .line 74
    .line 75
    .line 76
    iget-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 77
    .line 78
    if-eqz p1, :cond_54

    .line 79
    .line 80
    iget p2, p0, Lj/A;->j:I

    .line 81
    .line 82
    invoke-virtual {v3, p1, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 83
    .line 84
    .line 85
    :cond_54
    return-void
.end method

.method public final f(Landroid/content/Context;LC0/f;)V
    .registers 14

    .line 1
    iget v0, p0, Lj/A;->j:I

    .line 2
    .line 3
    iget-object v1, p2, LC0/f;->g:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Landroid/content/res/TypedArray;

    .line 6
    .line 7
    const/4 v2, 0x2

    .line 8
    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    iput v0, p0, Lj/A;->j:I

    .line 13
    .line 14
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 15
    .line 16
    const/16 v3, 0x1c

    .line 17
    .line 18
    const/4 v4, -0x1

    .line 19
    if-lt v0, v3, :cond_23

    .line 20
    .line 21
    const/16 v5, 0xb

    .line 22
    .line 23
    invoke-virtual {v1, v5, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    iput v5, p0, Lj/A;->k:I

    .line 28
    .line 29
    if-eq v5, v4, :cond_23

    .line 30
    .line 31
    iget v5, p0, Lj/A;->j:I

    .line 32
    .line 33
    and-int/2addr v5, v2

    .line 34
    iput v5, p0, Lj/A;->j:I

    .line 35
    .line 36
    :cond_23
    const/16 v5, 0xa

    .line 37
    .line 38
    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 39
    .line 40
    .line 41
    move-result v6

    .line 42
    const/16 v7, 0xc

    .line 43
    .line 44
    const/4 v8, 0x0

    .line 45
    const/4 v9, 0x1

    .line 46
    if-nez v6, :cond_5a

    .line 47
    .line 48
    invoke-virtual {v1, v7}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 49
    .line 50
    .line 51
    move-result v6

    .line 52
    if-eqz v6, :cond_36

    .line 53
    .line 54
    goto :goto_5a

    .line 55
    :cond_36
    invoke-virtual {v1, v9}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    if-eqz p1, :cond_d5

    .line 60
    .line 61
    iput-boolean v8, p0, Lj/A;->m:Z

    .line 62
    .line 63
    invoke-virtual {v1, v9, v9}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    if-eq p1, v9, :cond_55

    .line 68
    .line 69
    if-eq p1, v2, :cond_50

    .line 70
    .line 71
    const/4 p2, 0x3

    .line 72
    if-eq p1, p2, :cond_4b

    .line 73
    .line 74
    goto/16 :goto_d5

    .line 75
    .line 76
    :cond_4b
    sget-object p1, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    .line 77
    .line 78
    iput-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 79
    .line 80
    return-void

    .line 81
    :cond_50
    sget-object p1, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    .line 82
    .line 83
    iput-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 84
    .line 85
    return-void

    .line 86
    :cond_55
    sget-object p1, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    .line 87
    .line 88
    iput-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 89
    .line 90
    return-void

    .line 91
    :cond_5a
    :goto_5a
    const/4 v6, 0x0

    .line 92
    iput-object v6, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 93
    .line 94
    invoke-virtual {v1, v7}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 95
    .line 96
    .line 97
    move-result v6

    .line 98
    if-eqz v6, :cond_64

    .line 99
    .line 100
    move v5, v7

    .line 101
    :cond_64
    iget v6, p0, Lj/A;->k:I

    .line 102
    .line 103
    iget v7, p0, Lj/A;->j:I

    .line 104
    .line 105
    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    .line 106
    .line 107
    .line 108
    move-result p1

    .line 109
    if-nez p1, :cond_a8

    .line 110
    .line 111
    new-instance p1, Ljava/lang/ref/WeakReference;

    .line 112
    .line 113
    iget-object v10, p0, Lj/A;->a:Landroid/widget/TextView;

    .line 114
    .line 115
    invoke-direct {p1, v10}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    new-instance v10, Lj/u;

    .line 119
    .line 120
    invoke-direct {v10, p0, v6, v7, p1}, Lj/u;-><init>(Lj/A;IILjava/lang/ref/WeakReference;)V

    .line 121
    .line 122
    .line 123
    :try_start_7a
    iget p1, p0, Lj/A;->j:I

    .line 124
    .line 125
    invoke-virtual {p2, v5, p1, v10}, LC0/f;->E(IILj/u;)Landroid/graphics/Typeface;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    if-eqz p1, :cond_9f

    .line 130
    .line 131
    if-lt v0, v3, :cond_9d

    .line 132
    .line 133
    iget p2, p0, Lj/A;->k:I

    .line 134
    .line 135
    if-eq p2, v4, :cond_9d

    .line 136
    .line 137
    invoke-static {p1, v8}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    iget p2, p0, Lj/A;->k:I

    .line 142
    .line 143
    iget v0, p0, Lj/A;->j:I

    .line 144
    .line 145
    and-int/2addr v0, v2

    .line 146
    if-eqz v0, :cond_95

    .line 147
    .line 148
    move v0, v9

    .line 149
    goto :goto_96

    .line 150
    :cond_95
    move v0, v8

    .line 151
    :goto_96
    invoke-static {p1, p2, v0}, Lj/z;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 152
    .line 153
    .line 154
    move-result-object p1

    .line 155
    iput-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 156
    .line 157
    goto :goto_9f

    .line 158
    :cond_9d
    iput-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 159
    .line 160
    :cond_9f
    :goto_9f
    iget-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 161
    .line 162
    if-nez p1, :cond_a5

    .line 163
    .line 164
    move p1, v9

    .line 165
    goto :goto_a6

    .line 166
    :cond_a5
    move p1, v8

    .line 167
    :goto_a6
    iput-boolean p1, p0, Lj/A;->m:Z
    :try_end_a8
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_7a .. :try_end_a8} :catch_a8
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_7a .. :try_end_a8} :catch_a8

    .line 168
    .line 169
    :catch_a8
    :cond_a8
    iget-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 170
    .line 171
    if-nez p1, :cond_d5

    .line 172
    .line 173
    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    if-eqz p1, :cond_d5

    .line 178
    .line 179
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 180
    .line 181
    if-lt p2, v3, :cond_cd

    .line 182
    .line 183
    iget p2, p0, Lj/A;->k:I

    .line 184
    .line 185
    if-eq p2, v4, :cond_cd

    .line 186
    .line 187
    invoke-static {p1, v8}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    iget p2, p0, Lj/A;->k:I

    .line 192
    .line 193
    iget v0, p0, Lj/A;->j:I

    .line 194
    .line 195
    and-int/2addr v0, v2

    .line 196
    if-eqz v0, :cond_c6

    .line 197
    .line 198
    move v8, v9

    .line 199
    :cond_c6
    invoke-static {p1, p2, v8}, Lj/z;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    iput-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 204
    .line 205
    goto :goto_d5

    .line 206
    :cond_cd
    iget p2, p0, Lj/A;->j:I

    .line 207
    .line 208
    invoke-static {p1, p2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 209
    .line 210
    .line 211
    move-result-object p1

    .line 212
    iput-object p1, p0, Lj/A;->l:Landroid/graphics/Typeface;

    .line 213
    .line 214
    :cond_d5
    :goto_d5
    return-void
.end method
