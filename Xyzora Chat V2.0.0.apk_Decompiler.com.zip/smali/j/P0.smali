###### Class j.P0 (j.P0)
.class public final Lj/P0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Li/p;


# instance fields
.field public e:Li/i;

.field public f:Li/j;

.field public final synthetic g:Landroidx/appcompat/widget/Toolbar;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/Toolbar;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lj/P0;->g:Landroidx/appcompat/widget/Toolbar;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Li/i;Z)V
    .registers 3

    .line 1
    return-void
.end method

.method public final b(Li/j;)Z
    .registers 9

    .line 1
    iget-object v0, p0, Lj/P0;->g:Landroidx/appcompat/widget/Toolbar;

    .line 2
    .line 3
    iget-object v1, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 4
    .line 5
    instance-of v2, v1, Lh/a;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x1

    .line 9
    if-eqz v2, :cond_2b

    .line 10
    .line 11
    check-cast v1, Lh/a;

    .line 12
    .line 13
    check-cast v1, Landroidx/appcompat/widget/SearchView;

    .line 14
    .line 15
    iget-object v2, v1, Landroidx/appcompat/widget/SearchView;->t:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    .line 16
    .line 17
    const-string v5, ""

    .line 18
    .line 19
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2}, Landroid/widget/TextView;->length()I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    invoke-virtual {v2, v6}, Landroid/widget/EditText;->setSelection(I)V

    .line 27
    .line 28
    .line 29
    iput-object v5, v1, Landroidx/appcompat/widget/SearchView;->c0:Ljava/lang/CharSequence;

    .line 30
    .line 31
    invoke-virtual {v1}, Landroidx/appcompat/widget/SearchView;->clearFocus()V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1, v4}, Landroidx/appcompat/widget/SearchView;->u(Z)V

    .line 35
    .line 36
    .line 37
    iget v5, v1, Landroidx/appcompat/widget/SearchView;->e0:I

    .line 38
    .line 39
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setImeOptions(I)V

    .line 40
    .line 41
    .line 42
    iput-boolean v3, v1, Landroidx/appcompat/widget/SearchView;->d0:Z

    .line 43
    .line 44
    :cond_2b
    iget-object v1, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 45
    .line 46
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 47
    .line 48
    .line 49
    iget-object v1, v0, Landroidx/appcompat/widget/Toolbar;->l:Lj/q;

    .line 50
    .line 51
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 52
    .line 53
    .line 54
    const/4 v1, 0x0

    .line 55
    iput-object v1, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 56
    .line 57
    iget-object v2, v0, Landroidx/appcompat/widget/Toolbar;->I:Ljava/util/ArrayList;

    .line 58
    .line 59
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    sub-int/2addr v5, v4

    .line 64
    :goto_3f
    if-ltz v5, :cond_4d

    .line 65
    .line 66
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v6

    .line 70
    check-cast v6, Landroid/view/View;

    .line 71
    .line 72
    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 73
    .line 74
    .line 75
    add-int/lit8 v5, v5, -0x1

    .line 76
    .line 77
    goto :goto_3f

    .line 78
    :cond_4d
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 79
    .line 80
    .line 81
    iput-object v1, p0, Lj/P0;->f:Li/j;

    .line 82
    .line 83
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    .line 84
    .line 85
    .line 86
    iput-boolean v3, p1, Li/j;->B:Z

    .line 87
    .line 88
    iget-object p1, p1, Li/j;->n:Li/i;

    .line 89
    .line 90
    invoke-virtual {p1, v3}, Li/i;->o(Z)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->s()V

    .line 94
    .line 95
    .line 96
    return v4
.end method

.method public final d()Z
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final e(Landroid/content/Context;Li/i;)V
    .registers 4

    .line 1
    iget-object p1, p0, Lj/P0;->e:Li/i;

    .line 2
    .line 3
    if-eqz p1, :cond_b

    .line 4
    .line 5
    iget-object v0, p0, Lj/P0;->f:Li/j;

    .line 6
    .line 7
    if-eqz v0, :cond_b

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Li/i;->d(Li/j;)Z

    .line 10
    .line 11
    .line 12
    :cond_b
    iput-object p2, p0, Lj/P0;->e:Li/i;

    .line 13
    .line 14
    return-void
.end method

.method public final g(Li/j;)Z
    .registers 8

    .line 1
    iget-object v0, p0, Lj/P0;->g:Landroidx/appcompat/widget/Toolbar;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->c()V

    .line 4
    .line 5
    .line 6
    iget-object v1, v0, Landroidx/appcompat/widget/Toolbar;->l:Lj/q;

    .line 7
    .line 8
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-eq v1, v0, :cond_1d

    .line 13
    .line 14
    instance-of v2, v1, Landroid/view/ViewGroup;

    .line 15
    .line 16
    if-eqz v2, :cond_18

    .line 17
    .line 18
    check-cast v1, Landroid/view/ViewGroup;

    .line 19
    .line 20
    iget-object v2, v0, Landroidx/appcompat/widget/Toolbar;->l:Lj/q;

    .line 21
    .line 22
    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    iget-object v1, v0, Landroidx/appcompat/widget/Toolbar;->l:Lj/q;

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 28
    .line 29
    .line 30
    :cond_1d
    iget-object v1, p1, Li/j;->z:Landroid/view/View;

    .line 31
    .line 32
    if-eqz v1, :cond_22

    .line 33
    .line 34
    goto :goto_23

    .line 35
    :cond_22
    const/4 v1, 0x0

    .line 36
    :goto_23
    iput-object v1, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 37
    .line 38
    iput-object p1, p0, Lj/P0;->f:Li/j;

    .line 39
    .line 40
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    const/4 v2, 0x2

    .line 45
    if-eq v1, v0, :cond_53

    .line 46
    .line 47
    instance-of v3, v1, Landroid/view/ViewGroup;

    .line 48
    .line 49
    if-eqz v3, :cond_39

    .line 50
    .line 51
    check-cast v1, Landroid/view/ViewGroup;

    .line 52
    .line 53
    iget-object v3, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 54
    .line 55
    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 56
    .line 57
    .line 58
    :cond_39
    invoke-static {}, Landroidx/appcompat/widget/Toolbar;->g()Lj/Q0;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    iget v3, v0, Landroidx/appcompat/widget/Toolbar;->r:I

    .line 63
    .line 64
    and-int/lit8 v3, v3, 0x70

    .line 65
    .line 66
    const v4, 0x800003

    .line 67
    .line 68
    .line 69
    or-int/2addr v3, v4

    .line 70
    iput v3, v1, Lj/Q0;->a:I

    .line 71
    .line 72
    iput v2, v1, Lj/Q0;->b:I

    .line 73
    .line 74
    iget-object v3, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 75
    .line 76
    invoke-virtual {v3, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 77
    .line 78
    .line 79
    iget-object v1, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 80
    .line 81
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 82
    .line 83
    .line 84
    :cond_53
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 85
    .line 86
    .line 87
    move-result v1

    .line 88
    const/4 v3, 0x1

    .line 89
    sub-int/2addr v1, v3

    .line 90
    :goto_59
    if-ltz v1, :cond_78

    .line 91
    .line 92
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 97
    .line 98
    .line 99
    move-result-object v5

    .line 100
    check-cast v5, Lj/Q0;

    .line 101
    .line 102
    iget v5, v5, Lj/Q0;->b:I

    .line 103
    .line 104
    if-eq v5, v2, :cond_75

    .line 105
    .line 106
    iget-object v5, v0, Landroidx/appcompat/widget/Toolbar;->e:Landroidx/appcompat/widget/ActionMenuView;

    .line 107
    .line 108
    if-eq v4, v5, :cond_75

    .line 109
    .line 110
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeViewAt(I)V

    .line 111
    .line 112
    .line 113
    iget-object v5, v0, Landroidx/appcompat/widget/Toolbar;->I:Ljava/util/ArrayList;

    .line 114
    .line 115
    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    :cond_75
    add-int/lit8 v1, v1, -0x1

    .line 119
    .line 120
    goto :goto_59

    .line 121
    :cond_78
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    .line 122
    .line 123
    .line 124
    iput-boolean v3, p1, Li/j;->B:Z

    .line 125
    .line 126
    iget-object p1, p1, Li/j;->n:Li/i;

    .line 127
    .line 128
    const/4 v1, 0x0

    .line 129
    invoke-virtual {p1, v1}, Li/i;->o(Z)V

    .line 130
    .line 131
    .line 132
    iget-object p1, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroid/view/View;

    .line 133
    .line 134
    instance-of v2, p1, Lh/a;

    .line 135
    .line 136
    if-eqz v2, :cond_aa

    .line 137
    .line 138
    check-cast p1, Lh/a;

    .line 139
    .line 140
    check-cast p1, Landroidx/appcompat/widget/SearchView;

    .line 141
    .line 142
    iget-boolean v2, p1, Landroidx/appcompat/widget/SearchView;->d0:Z

    .line 143
    .line 144
    if-eqz v2, :cond_92

    .line 145
    .line 146
    goto :goto_aa

    .line 147
    :cond_92
    iput-boolean v3, p1, Landroidx/appcompat/widget/SearchView;->d0:Z

    .line 148
    .line 149
    iget-object v2, p1, Landroidx/appcompat/widget/SearchView;->t:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    .line 150
    .line 151
    invoke-virtual {v2}, Landroid/widget/TextView;->getImeOptions()I

    .line 152
    .line 153
    .line 154
    move-result v4

    .line 155
    iput v4, p1, Landroidx/appcompat/widget/SearchView;->e0:I

    .line 156
    .line 157
    const/high16 v5, 0x2000000

    .line 158
    .line 159
    or-int/2addr v4, v5

    .line 160
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setImeOptions(I)V

    .line 161
    .line 162
    .line 163
    const-string v4, ""

    .line 164
    .line 165
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p1, v1}, Landroidx/appcompat/widget/SearchView;->setIconified(Z)V

    .line 169
    .line 170
    .line 171
    :cond_aa
    :goto_aa
    invoke-virtual {v0}, Landroidx/appcompat/widget/Toolbar;->s()V

    .line 172
    .line 173
    .line 174
    return v3
.end method

.method public final h()V
    .registers 5

    .line 1
    iget-object v0, p0, Lj/P0;->f:Li/j;

    .line 2
    .line 3
    if-eqz v0, :cond_24

    .line 4
    .line 5
    iget-object v0, p0, Lj/P0;->e:Li/i;

    .line 6
    .line 7
    if-eqz v0, :cond_1f

    .line 8
    .line 9
    iget-object v0, v0, Li/i;->f:Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x0

    .line 16
    :goto_f
    if-ge v1, v0, :cond_1f

    .line 17
    .line 18
    iget-object v2, p0, Lj/P0;->e:Li/i;

    .line 19
    .line 20
    invoke-virtual {v2, v1}, Li/i;->getItem(I)Landroid/view/MenuItem;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    iget-object v3, p0, Lj/P0;->f:Li/j;

    .line 25
    .line 26
    if-ne v2, v3, :cond_1c

    .line 27
    .line 28
    goto :goto_24

    .line 29
    :cond_1c
    add-int/lit8 v1, v1, 0x1

    .line 30
    .line 31
    goto :goto_f

    .line 32
    :cond_1f
    iget-object v0, p0, Lj/P0;->f:Li/j;

    .line 33
    .line 34
    invoke-virtual {p0, v0}, Lj/P0;->b(Li/j;)Z

    .line 35
    .line 36
    .line 37
    :cond_24
    :goto_24
    return-void
.end method

.method public final k(Li/t;)Z
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method
