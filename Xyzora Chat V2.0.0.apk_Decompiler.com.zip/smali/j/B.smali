###### Class j.B (j.B)
.class public interface abstract Lj/B;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(I)V
.end method

.method public abstract c(I)V
.end method
