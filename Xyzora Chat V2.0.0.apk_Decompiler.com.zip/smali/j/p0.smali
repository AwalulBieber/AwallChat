###### Class j.C0173p0 (j.p0)
.class public final Lj/p0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final f:Landroid/graphics/PorterDuff$Mode;

.field public static g:Lj/p0;

.field public static final h:Lj/o0;


# instance fields
.field public a:Ljava/util/WeakHashMap;

.field public final b:Ljava/util/WeakHashMap;

.field public c:Landroid/util/TypedValue;

.field public d:Z

.field public e:Lg1/s;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 2
    .line 3
    sput-object v0, Lj/p0;->f:Landroid/graphics/PorterDuff$Mode;

    .line 4
    .line 5
    new-instance v0, Lj/o0;

    .line 6
    .line 7
    const/4 v1, 0x6

    .line 8
    invoke-direct {v0, v1}, Ln/i;-><init>(I)V

    .line 9
    .line 10
    .line 11
    sput-object v0, Lj/p0;->h:Lj/o0;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/WeakHashMap;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, Ljava/util/WeakHashMap;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lj/p0;->b:Ljava/util/WeakHashMap;

    .line 11
    .line 12
    return-void
.end method

.method public static declared-synchronized b()Lj/p0;
    .registers 2

    .line 1
    const-class v0, Lj/p0;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, Lj/p0;->g:Lj/p0;

    .line 5
    .line 6
    if-nez v1, :cond_11

    .line 7
    .line 8
    new-instance v1, Lj/p0;

    .line 9
    .line 10
    invoke-direct {v1}, Lj/p0;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lj/p0;->g:Lj/p0;

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :catchall_f
    move-exception v1

    .line 17
    goto :goto_15

    .line 18
    :cond_11
    :goto_11
    sget-object v1, Lj/p0;->g:Lj/p0;
    :try_end_13
    .catchall {:try_start_3 .. :try_end_13} :catchall_f

    .line 19
    .line 20
    monitor-exit v0

    .line 21
    return-object v1

    .line 22
    :goto_15
    :try_start_15
    monitor-exit v0
    :try_end_16
    .catchall {:try_start_15 .. :try_end_16} :catchall_f

    .line 23
    throw v1
.end method

.method public static declared-synchronized e(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    .registers 6

    .line 1
    const-class v0, Lj/p0;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, Lj/p0;->h:Lj/o0;

    .line 5
    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/16 v2, 0x1f

    .line 10
    .line 11
    add-int v3, v2, p0

    .line 12
    .line 13
    mul-int/2addr v3, v2

    .line 14
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    add-int/2addr v2, v3

    .line 19
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    invoke-virtual {v1, v2}, Ln/i;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    check-cast v2, Landroid/graphics/PorterDuffColorFilter;

    .line 28
    .line 29
    if-nez v2, :cond_35

    .line 30
    .line 31
    new-instance v2, Landroid/graphics/PorterDuffColorFilter;

    .line 32
    .line 33
    invoke-direct {v2, p0, p1}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    add-int/2addr p0, v3

    .line 41
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    invoke-virtual {v1, p0, v2}, Ln/i;->b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    check-cast p0, Landroid/graphics/PorterDuffColorFilter;
    :try_end_32
    .catchall {:try_start_3 .. :try_end_32} :catchall_33

    .line 50
    .line 51
    goto :goto_35

    .line 52
    :catchall_33
    move-exception p0

    .line 53
    goto :goto_37

    .line 54
    :cond_35
    :goto_35
    monitor-exit v0

    .line 55
    return-object v2

    .line 56
    :goto_37
    :try_start_37
    monitor-exit v0
    :try_end_38
    .catchall {:try_start_37 .. :try_end_38} :catchall_33

    .line 57
    throw p0
.end method


# virtual methods
.method public final a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .registers 12

    .line 1
    iget-object v0, p0, Lj/p0;->c:Landroid/util/TypedValue;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Landroid/util/TypedValue;

    .line 6
    .line 7
    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lj/p0;->c:Landroid/util/TypedValue;

    .line 11
    .line 12
    :cond_b
    iget-object v0, p0, Lj/p0;->c:Landroid/util/TypedValue;

    .line 13
    .line 14
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const/4 v2, 0x1

    .line 19
    invoke-virtual {v1, p2, v0, v2}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    .line 20
    .line 21
    .line 22
    iget v1, v0, Landroid/util/TypedValue;->assetCookie:I

    .line 23
    .line 24
    int-to-long v1, v1

    .line 25
    const/16 v3, 0x20

    .line 26
    .line 27
    shl-long/2addr v1, v3

    .line 28
    iget v3, v0, Landroid/util/TypedValue;->data:I

    .line 29
    .line 30
    int-to-long v3, v3

    .line 31
    or-long/2addr v1, v3

    .line 32
    monitor-enter p0

    .line 33
    :try_start_20
    iget-object v3, p0, Lj/p0;->b:Ljava/util/WeakHashMap;

    .line 34
    .line 35
    invoke-virtual {v3, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    check-cast v3, Ln/g;
    :try_end_28
    .catchall {:try_start_20 .. :try_end_28} :catchall_56

    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    if-nez v3, :cond_2d

    .line 43
    .line 44
    monitor-exit p0

    .line 45
    goto :goto_71

    .line 46
    :cond_2d
    :try_start_2d
    iget-object v5, v3, Ln/g;->f:[J

    .line 47
    .line 48
    iget v6, v3, Ln/g;->h:I

    .line 49
    .line 50
    invoke-static {v5, v6, v1, v2}, Lo/a;->b([JIJ)I

    .line 51
    .line 52
    .line 53
    move-result v5

    .line 54
    if-ltz v5, :cond_3f

    .line 55
    .line 56
    iget-object v6, v3, Ln/g;->g:[Ljava/lang/Object;

    .line 57
    .line 58
    aget-object v5, v6, v5

    .line 59
    .line 60
    sget-object v6, Ln/h;->a:Ljava/lang/Object;

    .line 61
    .line 62
    if-ne v5, v6, :cond_40

    .line 63
    .line 64
    :cond_3f
    const/4 v5, 0x0

    .line 65
    :cond_40
    check-cast v5, Ljava/lang/ref/WeakReference;

    .line 66
    .line 67
    if-eqz v5, :cond_70

    .line 68
    .line 69
    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v5

    .line 73
    check-cast v5, Landroid/graphics/drawable/Drawable$ConstantState;

    .line 74
    .line 75
    if-eqz v5, :cond_59

    .line 76
    .line 77
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    invoke-virtual {v5, v3}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    .line 82
    .line 83
    .line 84
    move-result-object v4
    :try_end_54
    .catchall {:try_start_2d .. :try_end_54} :catchall_56

    .line 85
    monitor-exit p0

    .line 86
    goto :goto_71

    .line 87
    :catchall_56
    move-exception p1

    .line 88
    goto/16 :goto_f1

    .line 89
    .line 90
    :cond_59
    :try_start_59
    iget-object v5, v3, Ln/g;->f:[J

    .line 91
    .line 92
    iget v6, v3, Ln/g;->h:I

    .line 93
    .line 94
    invoke-static {v5, v6, v1, v2}, Lo/a;->b([JIJ)I

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    if-ltz v5, :cond_70

    .line 99
    .line 100
    iget-object v6, v3, Ln/g;->g:[Ljava/lang/Object;

    .line 101
    .line 102
    aget-object v7, v6, v5

    .line 103
    .line 104
    sget-object v8, Ln/h;->a:Ljava/lang/Object;

    .line 105
    .line 106
    if-eq v7, v8, :cond_70

    .line 107
    .line 108
    aput-object v8, v6, v5

    .line 109
    .line 110
    const/4 v5, 0x1

    .line 111
    iput-boolean v5, v3, Ln/g;->e:Z
    :try_end_70
    .catchall {:try_start_59 .. :try_end_70} :catchall_56

    .line 112
    .line 113
    :cond_70
    monitor-exit p0

    .line 114
    :goto_71
    if-eqz v4, :cond_74

    .line 115
    .line 116
    return-object v4

    .line 117
    :cond_74
    iget-object v3, p0, Lj/p0;->e:Lg1/s;

    .line 118
    .line 119
    const/4 v4, 0x0

    .line 120
    if-nez v3, :cond_7a

    .line 121
    .line 122
    goto :goto_bd

    .line 123
    :cond_7a
    const v3, 0x7f070010

    .line 124
    .line 125
    .line 126
    if-ne p2, v3, :cond_97

    .line 127
    .line 128
    new-instance v4, Landroid/graphics/drawable/LayerDrawable;

    .line 129
    .line 130
    const p2, 0x7f07000f

    .line 131
    .line 132
    .line 133
    invoke-virtual {p0, p1, p2}, Lj/p0;->c(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 134
    .line 135
    .line 136
    move-result-object p2

    .line 137
    const v3, 0x7f070011

    .line 138
    .line 139
    .line 140
    invoke-virtual {p0, p1, v3}, Lj/p0;->c(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 141
    .line 142
    .line 143
    move-result-object v3

    .line 144
    filled-new-array {p2, v3}, [Landroid/graphics/drawable/Drawable;

    .line 145
    .line 146
    .line 147
    move-result-object p2

    .line 148
    invoke-direct {v4, p2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 149
    .line 150
    .line 151
    goto :goto_bd

    .line 152
    :cond_97
    const v3, 0x7f070033

    .line 153
    .line 154
    .line 155
    if-ne p2, v3, :cond_a4

    .line 156
    .line 157
    const p2, 0x7f06003b

    .line 158
    .line 159
    .line 160
    invoke-static {p0, p1, p2}, Lg1/s;->l(Lj/p0;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    goto :goto_bd

    .line 165
    :cond_a4
    const v3, 0x7f070032

    .line 166
    .line 167
    .line 168
    if-ne p2, v3, :cond_b1

    .line 169
    .line 170
    const p2, 0x7f06003c

    .line 171
    .line 172
    .line 173
    invoke-static {p0, p1, p2}, Lg1/s;->l(Lj/p0;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;

    .line 174
    .line 175
    .line 176
    move-result-object v4

    .line 177
    goto :goto_bd

    .line 178
    :cond_b1
    const v3, 0x7f070034

    .line 179
    .line 180
    .line 181
    if-ne p2, v3, :cond_bd

    .line 182
    .line 183
    const p2, 0x7f06003d

    .line 184
    .line 185
    .line 186
    invoke-static {p0, p1, p2}, Lg1/s;->l(Lj/p0;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;

    .line 187
    .line 188
    .line 189
    move-result-object v4

    .line 190
    :cond_bd
    :goto_bd
    if-eqz v4, :cond_f0

    .line 191
    .line 192
    iget p2, v0, Landroid/util/TypedValue;->changingConfigurations:I

    .line 193
    .line 194
    invoke-virtual {v4, p2}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    .line 195
    .line 196
    .line 197
    monitor-enter p0

    .line 198
    :try_start_c5
    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    .line 199
    .line 200
    .line 201
    move-result-object p2

    .line 202
    if-eqz p2, :cond_ec

    .line 203
    .line 204
    iget-object v0, p0, Lj/p0;->b:Ljava/util/WeakHashMap;

    .line 205
    .line 206
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    check-cast v0, Ln/g;

    .line 211
    .line 212
    if-nez v0, :cond_e2

    .line 213
    .line 214
    new-instance v0, Ln/g;

    .line 215
    .line 216
    invoke-direct {v0}, Ln/g;-><init>()V

    .line 217
    .line 218
    .line 219
    iget-object v3, p0, Lj/p0;->b:Ljava/util/WeakHashMap;

    .line 220
    .line 221
    invoke-virtual {v3, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    goto :goto_e2

    .line 225
    :catchall_e0
    move-exception p1

    .line 226
    goto :goto_ee

    .line 227
    :cond_e2
    :goto_e2
    new-instance p1, Ljava/lang/ref/WeakReference;

    .line 228
    .line 229
    invoke-direct {p1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v0, v1, v2, p1}, Ln/g;->a(JLjava/lang/Object;)V
    :try_end_ea
    .catchall {:try_start_c5 .. :try_end_ea} :catchall_e0

    .line 233
    .line 234
    .line 235
    monitor-exit p0

    .line 236
    goto :goto_ed

    .line 237
    :cond_ec
    monitor-exit p0

    .line 238
    :goto_ed
    return-object v4

    .line 239
    :goto_ee
    :try_start_ee
    monitor-exit p0
    :try_end_ef
    .catchall {:try_start_ee .. :try_end_ef} :catchall_e0

    .line 240
    throw p1

    .line 241
    :cond_f0
    return-object v4

    .line 242
    :goto_f1
    :try_start_f1
    monitor-exit p0
    :try_end_f2
    .catchall {:try_start_f1 .. :try_end_f2} :catchall_56

    .line 243
    throw p1
.end method

.method public final declared-synchronized c(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .registers 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0, p1, p2}, Lj/p0;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 3
    .line 4
    .line 5
    move-result-object p1
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_7

    .line 6
    monitor-exit p0

    .line 7
    return-object p1

    .line 8
    :catchall_7
    move-exception p1

    .line 9
    :try_start_8
    monitor-exit p0
    :try_end_9
    .catchall {:try_start_8 .. :try_end_9} :catchall_7

    .line 10
    throw p1
.end method

.method public final declared-synchronized d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-boolean v0, p0, Lj/p0;->d:Z

    .line 3
    .line 4
    if-eqz v0, :cond_6

    .line 5
    .line 6
    goto :goto_26

    .line 7
    :cond_6
    const/4 v0, 0x1

    .line 8
    iput-boolean v0, p0, Lj/p0;->d:Z

    .line 9
    .line 10
    const v0, 0x7f07004e

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0, p1, v0}, Lj/p0;->c(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_40

    .line 18
    .line 19
    instance-of v1, v0, La0/a;

    .line 20
    .line 21
    if-nez v1, :cond_26

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    const-string v1, "android.graphics.drawable.VectorDrawable"

    .line 32
    .line 33
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_40

    .line 38
    .line 39
    :cond_26
    :goto_26
    invoke-virtual {p0, p1, p2}, Lj/p0;->a(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    if-nez v0, :cond_30

    .line 44
    .line 45
    invoke-virtual {p1, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    :cond_30
    if-eqz v0, :cond_39

    .line 50
    .line 51
    invoke-virtual {p0, p1, p2, v0}, Lj/p0;->g(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    goto :goto_39

    .line 56
    :catchall_37
    move-exception p1

    .line 57
    goto :goto_4b

    .line 58
    :cond_39
    :goto_39
    if-eqz v0, :cond_3e

    .line 59
    .line 60
    invoke-static {v0}, Lj/P;->a(Landroid/graphics/drawable/Drawable;)V
    :try_end_3e
    .catchall {:try_start_1 .. :try_end_3e} :catchall_37

    .line 61
    .line 62
    .line 63
    :cond_3e
    monitor-exit p0

    .line 64
    return-object v0

    .line 65
    :cond_40
    const/4 p1, 0x0

    .line 66
    :try_start_41
    iput-boolean p1, p0, Lj/p0;->d:Z

    .line 67
    .line 68
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 69
    .line 70
    const-string p2, "This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat."

    .line 71
    .line 72
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    throw p1

    .line 76
    :goto_4b
    monitor-exit p0
    :try_end_4c
    .catchall {:try_start_41 .. :try_end_4c} :catchall_37

    .line 77
    throw p1
.end method

.method public final declared-synchronized f(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .registers 9

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lj/p0;->a:Ljava/util/WeakHashMap;

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    if-eqz v0, :cond_24

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ln/k;

    .line 12
    .line 13
    if-eqz v0, :cond_24

    .line 14
    .line 15
    iget-object v2, v0, Ln/k;->e:[I

    .line 16
    .line 17
    iget v3, v0, Ln/k;->g:I

    .line 18
    .line 19
    invoke-static {v3, p2, v2}, Lo/a;->a(II[I)I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-ltz v2, :cond_20

    .line 24
    .line 25
    iget-object v0, v0, Ln/k;->f:[Ljava/lang/Object;

    .line 26
    .line 27
    aget-object v0, v0, v2

    .line 28
    .line 29
    sget-object v2, Ln/h;->b:Ljava/lang/Object;

    .line 30
    .line 31
    if-ne v0, v2, :cond_21

    .line 32
    .line 33
    :cond_20
    move-object v0, v1

    .line 34
    :cond_21
    check-cast v0, Landroid/content/res/ColorStateList;

    .line 35
    .line 36
    goto :goto_25

    .line 37
    :cond_24
    move-object v0, v1

    .line 38
    :goto_25
    if-nez v0, :cond_74

    .line 39
    .line 40
    iget-object v0, p0, Lj/p0;->e:Lg1/s;

    .line 41
    .line 42
    if-nez v0, :cond_2c

    .line 43
    .line 44
    goto :goto_30

    .line 45
    :cond_2c
    invoke-virtual {v0, p1, p2}, Lg1/s;->m(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    :goto_30
    if-eqz v1, :cond_70

    .line 50
    .line 51
    iget-object v0, p0, Lj/p0;->a:Ljava/util/WeakHashMap;

    .line 52
    .line 53
    if-nez v0, :cond_3d

    .line 54
    .line 55
    new-instance v0, Ljava/util/WeakHashMap;

    .line 56
    .line 57
    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    .line 58
    .line 59
    .line 60
    iput-object v0, p0, Lj/p0;->a:Ljava/util/WeakHashMap;

    .line 61
    .line 62
    :cond_3d
    iget-object v0, p0, Lj/p0;->a:Ljava/util/WeakHashMap;

    .line 63
    .line 64
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    check-cast v0, Ln/k;

    .line 69
    .line 70
    if-nez v0, :cond_6d

    .line 71
    .line 72
    new-instance v0, Ln/k;

    .line 73
    .line 74
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 75
    .line 76
    .line 77
    const/4 v2, 0x4

    .line 78
    move v3, v2

    .line 79
    :goto_4e
    const/16 v4, 0x20

    .line 80
    .line 81
    const/16 v5, 0x28

    .line 82
    .line 83
    if-ge v3, v4, :cond_5f

    .line 84
    .line 85
    const/4 v4, 0x1

    .line 86
    shl-int/2addr v4, v3

    .line 87
    add-int/lit8 v4, v4, -0xc

    .line 88
    .line 89
    if-gt v5, v4, :cond_5c

    .line 90
    .line 91
    move v5, v4

    .line 92
    goto :goto_5f

    .line 93
    :cond_5c
    add-int/lit8 v3, v3, 0x1

    .line 94
    .line 95
    goto :goto_4e

    .line 96
    :cond_5f
    :goto_5f
    div-int/2addr v5, v2

    .line 97
    new-array v2, v5, [I

    .line 98
    .line 99
    iput-object v2, v0, Ln/k;->e:[I

    .line 100
    .line 101
    new-array v2, v5, [Ljava/lang/Object;

    .line 102
    .line 103
    iput-object v2, v0, Ln/k;->f:[Ljava/lang/Object;

    .line 104
    .line 105
    iget-object v2, p0, Lj/p0;->a:Ljava/util/WeakHashMap;

    .line 106
    .line 107
    invoke-virtual {v2, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    :cond_6d
    invoke-virtual {v0, p2, v1}, Ln/k;->a(ILjava/lang/Object;)V
    :try_end_70
    .catchall {:try_start_1 .. :try_end_70} :catchall_72

    .line 111
    .line 112
    .line 113
    :cond_70
    move-object v0, v1

    .line 114
    goto :goto_74

    .line 115
    :catchall_72
    move-exception p1

    .line 116
    goto :goto_76

    .line 117
    :cond_74
    :goto_74
    monitor-exit p0

    .line 118
    return-object v0

    .line 119
    :goto_76
    :try_start_76
    monitor-exit p0
    :try_end_77
    .catchall {:try_start_76 .. :try_end_77} :catchall_72

    .line 120
    throw p1
.end method

.method public final g(Landroid/content/Context;ILandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .registers 12

    .line 1
    const v0, 0x7f030062

    .line 2
    .line 3
    .line 4
    const v1, 0x7f030060

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p1, p2}, Lj/p0;->f(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    if-eqz v2, :cond_28

    .line 12
    .line 13
    sget-object p1, Lj/P;->a:[I

    .line 14
    .line 15
    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    .line 20
    .line 21
    .line 22
    iget-object p3, p0, Lj/p0;->e:Lg1/s;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    if-nez p3, :cond_1b

    .line 26
    .line 27
    goto :goto_22

    .line 28
    :cond_1b
    const p3, 0x7f070041

    .line 29
    .line 30
    .line 31
    if-ne p2, p3, :cond_22

    .line 32
    .line 33
    sget-object v0, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    .line 34
    .line 35
    :cond_22
    :goto_22
    if-eqz v0, :cond_27

    .line 36
    .line 37
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    .line 38
    .line 39
    .line 40
    :cond_27
    return-object p1

    .line 41
    :cond_28
    iget-object v2, p0, Lj/p0;->e:Lg1/s;

    .line 42
    .line 43
    if-eqz v2, :cond_96

    .line 44
    .line 45
    const v2, 0x7f07003c

    .line 46
    .line 47
    .line 48
    const v3, 0x102000d

    .line 49
    .line 50
    .line 51
    const v4, 0x102000f

    .line 52
    .line 53
    .line 54
    const/high16 v5, 0x1020000

    .line 55
    .line 56
    if-ne p2, v2, :cond_60

    .line 57
    .line 58
    move-object p2, p3

    .line 59
    check-cast p2, Landroid/graphics/drawable/LayerDrawable;

    .line 60
    .line 61
    invoke-virtual {p2, v5}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-static {p1, v0}, Lj/J0;->c(Landroid/content/Context;I)I

    .line 66
    .line 67
    .line 68
    move-result v5

    .line 69
    sget-object v6, Lj/o;->b:Landroid/graphics/PorterDuff$Mode;

    .line 70
    .line 71
    invoke-static {v2, v5, v6}, Lg1/s;->o(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {p2, v4}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    invoke-static {p1, v0}, Lj/J0;->c(Landroid/content/Context;I)I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    invoke-static {v2, v0, v6}, Lg1/s;->o(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p2, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 86
    .line 87
    .line 88
    move-result-object p2

    .line 89
    invoke-static {p1, v1}, Lj/J0;->c(Landroid/content/Context;I)I

    .line 90
    .line 91
    .line 92
    move-result p1

    .line 93
    invoke-static {p2, p1, v6}, Lg1/s;->o(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 94
    .line 95
    .line 96
    return-object p3

    .line 97
    :cond_60
    const v2, 0x7f070033

    .line 98
    .line 99
    .line 100
    if-eq p2, v2, :cond_6f

    .line 101
    .line 102
    const v2, 0x7f070032

    .line 103
    .line 104
    .line 105
    if-eq p2, v2, :cond_6f

    .line 106
    .line 107
    const v2, 0x7f070034

    .line 108
    .line 109
    .line 110
    if-ne p2, v2, :cond_96

    .line 111
    .line 112
    :cond_6f
    move-object p2, p3

    .line 113
    check-cast p2, Landroid/graphics/drawable/LayerDrawable;

    .line 114
    .line 115
    invoke-virtual {p2, v5}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    invoke-static {p1, v0}, Lj/J0;->b(Landroid/content/Context;I)I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    sget-object v5, Lj/o;->b:Landroid/graphics/PorterDuff$Mode;

    .line 124
    .line 125
    invoke-static {v2, v0, v5}, Lg1/s;->o(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {p2, v4}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-static {p1, v1}, Lj/J0;->c(Landroid/content/Context;I)I

    .line 133
    .line 134
    .line 135
    move-result v2

    .line 136
    invoke-static {v0, v2, v5}, Lg1/s;->o(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {p2, v3}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    .line 140
    .line 141
    .line 142
    move-result-object p2

    .line 143
    invoke-static {p1, v1}, Lj/J0;->c(Landroid/content/Context;I)I

    .line 144
    .line 145
    .line 146
    move-result p1

    .line 147
    invoke-static {p2, p1, v5}, Lg1/s;->o(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    .line 148
    .line 149
    .line 150
    return-object p3

    .line 151
    :cond_96
    iget-object v2, p0, Lj/p0;->e:Lg1/s;

    .line 152
    .line 153
    const/4 v3, 0x0

    .line 154
    if-eqz v2, :cond_101

    .line 155
    .line 156
    sget-object v4, Lj/o;->b:Landroid/graphics/PorterDuff$Mode;

    .line 157
    .line 158
    iget-object v5, v2, Lg1/s;->a:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v5, [I

    .line 161
    .line 162
    invoke-static {v5, p2}, Lg1/s;->h([II)Z

    .line 163
    .line 164
    .line 165
    move-result v5

    .line 166
    const/4 v6, 0x1

    .line 167
    const/4 v7, -0x1

    .line 168
    if-eqz v5, :cond_ac

    .line 169
    .line 170
    :goto_a9
    move v3, v6

    .line 171
    :goto_aa
    move p2, v7

    .line 172
    goto :goto_e1

    .line 173
    :cond_ac
    iget-object v0, v2, Lg1/s;->c:Ljava/lang/Object;

    .line 174
    .line 175
    check-cast v0, [I

    .line 176
    .line 177
    invoke-static {v0, p2}, Lg1/s;->h([II)Z

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    if-eqz v0, :cond_b8

    .line 182
    .line 183
    :goto_b6
    move v0, v1

    .line 184
    goto :goto_a9

    .line 185
    :cond_b8
    iget-object v0, v2, Lg1/s;->d:Ljava/lang/Object;

    .line 186
    .line 187
    check-cast v0, [I

    .line 188
    .line 189
    invoke-static {v0, p2}, Lg1/s;->h([II)Z

    .line 190
    .line 191
    .line 192
    move-result v0

    .line 193
    const v1, 0x1010031

    .line 194
    .line 195
    .line 196
    if-eqz v0, :cond_c8

    .line 197
    .line 198
    sget-object v4, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    .line 199
    .line 200
    goto :goto_b6

    .line 201
    :cond_c8
    const v0, 0x7f070025

    .line 202
    .line 203
    .line 204
    if-ne p2, v0, :cond_d9

    .line 205
    .line 206
    const p2, 0x42233333    # 40.8f

    .line 207
    .line 208
    .line 209
    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    .line 210
    .line 211
    .line 212
    move-result p2

    .line 213
    const v0, 0x1010030

    .line 214
    .line 215
    .line 216
    move v3, v6

    .line 217
    goto :goto_e1

    .line 218
    :cond_d9
    const v0, 0x7f070013

    .line 219
    .line 220
    .line 221
    if-ne p2, v0, :cond_df

    .line 222
    .line 223
    goto :goto_b6

    .line 224
    :cond_df
    move v0, v3

    .line 225
    goto :goto_aa

    .line 226
    :goto_e1
    if-eqz v3, :cond_101

    .line 227
    .line 228
    sget-object v1, Lj/P;->a:[I

    .line 229
    .line 230
    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 231
    .line 232
    .line 233
    move-result-object v1

    .line 234
    invoke-static {p1, v0}, Lj/J0;->c(Landroid/content/Context;I)I

    .line 235
    .line 236
    .line 237
    move-result p1

    .line 238
    const-class v0, Lj/o;

    .line 239
    .line 240
    monitor-enter v0

    .line 241
    :try_start_f0
    invoke-static {p1, v4}, Lj/p0;->e(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    .line 242
    .line 243
    .line 244
    move-result-object p1
    :try_end_f4
    .catchall {:try_start_f0 .. :try_end_f4} :catchall_fe

    .line 245
    monitor-exit v0

    .line 246
    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    .line 247
    .line 248
    .line 249
    if-eq p2, v7, :cond_101

    .line 250
    .line 251
    invoke-virtual {v1, p2}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 252
    .line 253
    .line 254
    goto :goto_101

    .line 255
    :catchall_fe
    move-exception p1

    .line 256
    :try_start_ff
    monitor-exit v0
    :try_end_100
    .catchall {:try_start_ff .. :try_end_100} :catchall_fe

    .line 257
    throw p1

    .line 258
    :cond_101
    :goto_101
    return-object p3
.end method
