###### Class j.C0162k (j.k)
.class public final Lj/k;
.super Lj/Z;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:I

.field public c:I

.field public d:Z

.field public e:Z

.field public f:Z
