###### Class j.AbstractC0175q0 (j.q0)
.class public abstract Lj/q0;
.super Landroid/content/res/Resources;
.source "SourceFile"
