###### Class j.M (j.M)
.class public interface abstract Lj/M;
.super Ljava/lang/Object;
.source "SourceFile"
