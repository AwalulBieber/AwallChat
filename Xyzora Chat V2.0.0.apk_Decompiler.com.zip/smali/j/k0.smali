###### Class j.AbstractC0163k0 (j.k0)
.class public abstract Lj/k0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/widget/PopupWindow;Z)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setTouchModal(Z)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
