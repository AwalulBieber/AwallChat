###### Class j.R0 (j.R0)
.class public interface abstract Lj/R0;
.super Ljava/lang/Object;
.source "SourceFile"
