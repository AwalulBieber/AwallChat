###### Class j.C (j.C)
.class public final Lj/C;
.super Ld0/n;
.source "SourceFile"


# instance fields
.field public final synthetic h:Lj/D;


# direct methods
.method public constructor <init>(Lj/D;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lj/C;->h:Lj/D;

    .line 2
    .line 3
    const/4 v0, 0x7

    .line 4
    invoke-direct {p0, v0, p1}, Ld0/n;-><init>(ILjava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final b(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Lj/C;->h:Lj/D;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lj/D;->e(Lj/D;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final c(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Lj/C;->h:Lj/D;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lj/D;->d(Lj/D;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
