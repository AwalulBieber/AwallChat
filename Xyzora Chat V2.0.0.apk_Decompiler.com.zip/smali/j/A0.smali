###### Class j.A0 (j.A0)
.class public interface abstract Lj/A0;
.super Ljava/lang/Object;
.source "SourceFile"
