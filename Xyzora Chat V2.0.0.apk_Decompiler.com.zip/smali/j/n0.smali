###### Class j.C0169n0 (j.n0)
.class public final Lj/n0;
.super Lj/h0;
.source "SourceFile"

# interfaces
.implements Lj/i0;


# static fields
.field public static final D:Ljava/lang/reflect/Method;


# instance fields
.field public C:La2/k;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1c

    .line 4
    .line 5
    if-gt v0, v1, :cond_1e

    .line 6
    .line 7
    const-class v0, Landroid/widget/PopupWindow;

    .line 8
    .line 9
    const-string v1, "setTouchModal"

    .line 10
    .line 11
    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 12
    .line 13
    filled-new-array {v2}, [Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sput-object v0, Lj/n0;->D:Ljava/lang/reflect/Method;
    :try_end_16
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_16} :catch_17

    .line 22
    .line 23
    return-void

    .line 24
    :catch_17
    const-string v0, "MenuPopupWindow"

    .line 25
    .line 26
    const-string v1, "Could not find method setTouchModal() on PopupWindow. Oh well."

    .line 27
    .line 28
    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 29
    .line 30
    .line 31
    :cond_1e
    return-void
.end method


# virtual methods
.method public final b(Li/i;Li/j;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lj/n0;->C:La2/k;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, La2/k;->b(Li/i;Li/j;)V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public final d(Li/i;Li/j;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lj/n0;->C:La2/k;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, La2/k;->d(Li/i;Li/j;)V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method
