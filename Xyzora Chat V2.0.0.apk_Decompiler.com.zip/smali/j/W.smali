###### Class j.W (j.W)
.class public abstract Lj/W;
.super Landroid/widget/ListView;
.source "SourceFile"


# instance fields
.field public final e:Landroid/graphics/Rect;

.field public f:I

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:Lj/U;

.field public l:Z

.field public final m:Z

.field public n:Z

.field public o:LF/e;

.field public p:LF/b;


# direct methods
.method public constructor <init>(Landroid/content/Context;Z)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    const v1, 0x7f03008e

    .line 3
    .line 4
    .line 5
    invoke-direct {p0, p1, v0, v1}, Landroid/widget/ListView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 6
    .line 7
    .line 8
    new-instance p1, Landroid/graphics/Rect;

    .line 9
    .line 10
    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lj/W;->e:Landroid/graphics/Rect;

    .line 14
    .line 15
    const/4 p1, 0x0

    .line 16
    iput p1, p0, Lj/W;->f:I

    .line 17
    .line 18
    iput p1, p0, Lj/W;->g:I

    .line 19
    .line 20
    iput p1, p0, Lj/W;->h:I

    .line 21
    .line 22
    iput p1, p0, Lj/W;->i:I

    .line 23
    .line 24
    iput-boolean p2, p0, Lj/W;->m:Z

    .line 25
    .line 26
    invoke-virtual {p0, p1}, Landroid/widget/AbsListView;->setCacheColorHint(I)V

    .line 27
    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a(II)I
    .registers 14

    .line 1
    invoke-virtual {p0}, Landroid/widget/AbsListView;->getListPaddingTop()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroid/widget/AbsListView;->getListPaddingBottom()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {p0}, Landroid/widget/ListView;->getDividerHeight()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    invoke-virtual {p0}, Landroid/widget/ListView;->getDivider()Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-virtual {p0}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    if-nez v4, :cond_18

    .line 22
    .line 23
    add-int/2addr v0, v1

    .line 24
    return v0

    .line 25
    :cond_18
    add-int/2addr v0, v1

    .line 26
    const/4 v1, 0x0

    .line 27
    if-lez v2, :cond_1f

    .line 28
    .line 29
    if-eqz v3, :cond_1f

    .line 30
    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v2, v1

    .line 33
    :goto_20
    invoke-interface {v4}, Landroid/widget/Adapter;->getCount()I

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    const/4 v5, 0x0

    .line 38
    move v6, v1

    .line 39
    move v7, v6

    .line 40
    move-object v8, v5

    .line 41
    :goto_28
    if-ge v6, v3, :cond_66

    .line 42
    .line 43
    invoke-interface {v4, v6}, Landroid/widget/Adapter;->getItemViewType(I)I

    .line 44
    .line 45
    .line 46
    move-result v9

    .line 47
    if-eq v9, v7, :cond_32

    .line 48
    .line 49
    move-object v8, v5

    .line 50
    move v7, v9

    .line 51
    :cond_32
    invoke-interface {v4, v6, v8, p0}, Landroid/widget/Adapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object v8

    .line 55
    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 56
    .line 57
    .line 58
    move-result-object v9

    .line 59
    if-nez v9, :cond_43

    .line 60
    .line 61
    invoke-virtual {p0}, Landroid/view/ViewGroup;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 62
    .line 63
    .line 64
    move-result-object v9

    .line 65
    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 66
    .line 67
    .line 68
    :cond_43
    iget v9, v9, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 69
    .line 70
    if-lez v9, :cond_4e

    .line 71
    .line 72
    const/high16 v10, 0x40000000    # 2.0f

    .line 73
    .line 74
    invoke-static {v9, v10}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 75
    .line 76
    .line 77
    move-result v9

    .line 78
    goto :goto_52

    .line 79
    :cond_4e
    invoke-static {v1, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 80
    .line 81
    .line 82
    move-result v9

    .line 83
    :goto_52
    invoke-virtual {v8, p1, v9}, Landroid/view/View;->measure(II)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v8}, Landroid/view/View;->forceLayout()V

    .line 87
    .line 88
    .line 89
    if-lez v6, :cond_5b

    .line 90
    .line 91
    add-int/2addr v0, v2

    .line 92
    :cond_5b
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredHeight()I

    .line 93
    .line 94
    .line 95
    move-result v9

    .line 96
    add-int/2addr v0, v9

    .line 97
    if-lt v0, p2, :cond_63

    .line 98
    .line 99
    return p2

    .line 100
    :cond_63
    add-int/lit8 v6, v6, 0x1

    .line 101
    .line 102
    goto :goto_28

    .line 103
    :cond_66
    return v0
.end method

.method public final b(ILandroid/view/MotionEvent;)Z
    .registers 20

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p2

    .line 4
    .line 5
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 6
    .line 7
    .line 8
    move-result v3

    .line 9
    const/4 v4, 0x1

    .line 10
    const/4 v5, 0x0

    .line 11
    if-eq v3, v4, :cond_1e

    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    if-eq v3, v0, :cond_1a

    .line 15
    .line 16
    const/4 v0, 0x3

    .line 17
    if-eq v3, v0, :cond_16

    .line 18
    .line 19
    move v6, v4

    .line 20
    move v4, v5

    .line 21
    goto/16 :goto_14b

    .line 22
    .line 23
    :cond_16
    :goto_16
    move v4, v5

    .line 24
    move v6, v4

    .line 25
    goto/16 :goto_14b

    .line 26
    .line 27
    :cond_1a
    move v6, v4

    .line 28
    :goto_1b
    move/from16 v0, p1

    .line 29
    .line 30
    goto :goto_20

    .line 31
    :cond_1e
    move v6, v5

    .line 32
    goto :goto_1b

    .line 33
    :goto_20
    invoke-virtual {v2, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-gez v0, :cond_27

    .line 38
    .line 39
    goto :goto_16

    .line 40
    :cond_27
    invoke-virtual {v2, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 41
    .line 42
    .line 43
    move-result v7

    .line 44
    float-to-int v7, v7

    .line 45
    invoke-virtual {v2, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    float-to-int v0, v0

    .line 50
    invoke-virtual {v1, v7, v0}, Landroid/widget/AbsListView;->pointToPosition(II)I

    .line 51
    .line 52
    .line 53
    move-result v8

    .line 54
    const/4 v9, -0x1

    .line 55
    if-ne v8, v9, :cond_3a

    .line 56
    .line 57
    goto/16 :goto_14b

    .line 58
    .line 59
    :cond_3a
    invoke-virtual {v1}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    .line 60
    .line 61
    .line 62
    move-result v6

    .line 63
    sub-int v6, v8, v6

    .line 64
    .line 65
    invoke-virtual {v1, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    int-to-float v7, v7

    .line 70
    int-to-float v10, v0

    .line 71
    iput-boolean v4, v1, Lj/W;->n:Z

    .line 72
    .line 73
    invoke-static {v1, v7, v10}, Lj/Q;->a(Landroid/view/View;FF)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v1}, Landroid/view/View;->isPressed()Z

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    if-nez v0, :cond_54

    .line 81
    .line 82
    invoke-virtual {v1, v4}, Landroid/view/View;->setPressed(Z)V

    .line 83
    .line 84
    .line 85
    :cond_54
    invoke-virtual {v1}, Landroid/widget/AbsListView;->layoutChildren()V

    .line 86
    .line 87
    .line 88
    iget v0, v1, Lj/W;->j:I

    .line 89
    .line 90
    if-eq v0, v9, :cond_71

    .line 91
    .line 92
    invoke-virtual {v1}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    .line 93
    .line 94
    .line 95
    move-result v11

    .line 96
    sub-int/2addr v0, v11

    .line 97
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    if-eqz v0, :cond_71

    .line 102
    .line 103
    if-eq v0, v6, :cond_71

    .line 104
    .line 105
    invoke-virtual {v0}, Landroid/view/View;->isPressed()Z

    .line 106
    .line 107
    .line 108
    move-result v11

    .line 109
    if-eqz v11, :cond_71

    .line 110
    .line 111
    invoke-virtual {v0, v5}, Landroid/view/View;->setPressed(Z)V

    .line 112
    .line 113
    .line 114
    :cond_71
    iput v8, v1, Lj/W;->j:I

    .line 115
    .line 116
    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    int-to-float v0, v0

    .line 121
    sub-float v0, v7, v0

    .line 122
    .line 123
    invoke-virtual {v6}, Landroid/view/View;->getTop()I

    .line 124
    .line 125
    .line 126
    move-result v11

    .line 127
    int-to-float v11, v11

    .line 128
    sub-float v11, v10, v11

    .line 129
    .line 130
    invoke-static {v6, v0, v11}, Lj/Q;->a(Landroid/view/View;FF)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v6}, Landroid/view/View;->isPressed()Z

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    if-nez v0, :cond_8d

    .line 138
    .line 139
    invoke-virtual {v6, v4}, Landroid/view/View;->setPressed(Z)V

    .line 140
    .line 141
    .line 142
    :cond_8d
    invoke-virtual {v1}, Landroid/widget/AbsListView;->getSelector()Landroid/graphics/drawable/Drawable;

    .line 143
    .line 144
    .line 145
    move-result-object v11

    .line 146
    if-eqz v11, :cond_97

    .line 147
    .line 148
    if-eq v8, v9, :cond_97

    .line 149
    .line 150
    move v12, v4

    .line 151
    goto :goto_98

    .line 152
    :cond_97
    move v12, v5

    .line 153
    :goto_98
    if-eqz v12, :cond_9d

    .line 154
    .line 155
    invoke-virtual {v11, v5, v5}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 156
    .line 157
    .line 158
    :cond_9d
    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    .line 159
    .line 160
    .line 161
    move-result v0

    .line 162
    invoke-virtual {v6}, Landroid/view/View;->getTop()I

    .line 163
    .line 164
    .line 165
    move-result v13

    .line 166
    invoke-virtual {v6}, Landroid/view/View;->getRight()I

    .line 167
    .line 168
    .line 169
    move-result v14

    .line 170
    invoke-virtual {v6}, Landroid/view/View;->getBottom()I

    .line 171
    .line 172
    .line 173
    move-result v15

    .line 174
    move/from16 v16, v4

    .line 175
    .line 176
    iget-object v4, v1, Lj/W;->e:Landroid/graphics/Rect;

    .line 177
    .line 178
    invoke-virtual {v4, v0, v13, v14, v15}, Landroid/graphics/Rect;->set(IIII)V

    .line 179
    .line 180
    .line 181
    iget v0, v4, Landroid/graphics/Rect;->left:I

    .line 182
    .line 183
    iget v13, v1, Lj/W;->f:I

    .line 184
    .line 185
    sub-int/2addr v0, v13

    .line 186
    iput v0, v4, Landroid/graphics/Rect;->left:I

    .line 187
    .line 188
    iget v0, v4, Landroid/graphics/Rect;->top:I

    .line 189
    .line 190
    iget v13, v1, Lj/W;->g:I

    .line 191
    .line 192
    sub-int/2addr v0, v13

    .line 193
    iput v0, v4, Landroid/graphics/Rect;->top:I

    .line 194
    .line 195
    iget v0, v4, Landroid/graphics/Rect;->right:I

    .line 196
    .line 197
    iget v13, v1, Lj/W;->h:I

    .line 198
    .line 199
    add-int/2addr v0, v13

    .line 200
    iput v0, v4, Landroid/graphics/Rect;->right:I

    .line 201
    .line 202
    iget v0, v4, Landroid/graphics/Rect;->bottom:I

    .line 203
    .line 204
    iget v13, v1, Lj/W;->i:I

    .line 205
    .line 206
    add-int/2addr v0, v13

    .line 207
    iput v0, v4, Landroid/graphics/Rect;->bottom:I

    .line 208
    .line 209
    invoke-static {}, Ly/a;->a()Z

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    if-eqz v0, :cond_db

    .line 214
    .line 215
    invoke-static {v1}, Lj/T;->a(Landroid/widget/AbsListView;)Z

    .line 216
    .line 217
    .line 218
    move-result v0

    .line 219
    goto :goto_e9

    .line 220
    :cond_db
    sget-object v0, Lj/V;->a:Ljava/lang/reflect/Field;

    .line 221
    .line 222
    if-eqz v0, :cond_e8

    .line 223
    .line 224
    :try_start_df
    invoke-virtual {v0, v1}, Ljava/lang/reflect/Field;->getBoolean(Ljava/lang/Object;)Z

    .line 225
    .line 226
    .line 227
    move-result v0
    :try_end_e3
    .catch Ljava/lang/IllegalAccessException; {:try_start_df .. :try_end_e3} :catch_e4

    .line 228
    goto :goto_e9

    .line 229
    :catch_e4
    move-exception v0

    .line 230
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 231
    .line 232
    .line 233
    :cond_e8
    move v0, v5

    .line 234
    :goto_e9
    invoke-virtual {v6}, Landroid/view/View;->isEnabled()Z

    .line 235
    .line 236
    .line 237
    move-result v13

    .line 238
    if-eq v13, v0, :cond_110

    .line 239
    .line 240
    xor-int/lit8 v0, v0, 0x1

    .line 241
    .line 242
    invoke-static {}, Ly/a;->a()Z

    .line 243
    .line 244
    .line 245
    move-result v13

    .line 246
    if-eqz v13, :cond_fb

    .line 247
    .line 248
    invoke-static {v1, v0}, Lj/T;->b(Landroid/widget/AbsListView;Z)V

    .line 249
    .line 250
    .line 251
    goto :goto_10b

    .line 252
    :cond_fb
    sget-object v13, Lj/V;->a:Ljava/lang/reflect/Field;

    .line 253
    .line 254
    if-eqz v13, :cond_10b

    .line 255
    .line 256
    :try_start_ff
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 257
    .line 258
    .line 259
    move-result-object v0

    .line 260
    invoke-virtual {v13, v1, v0}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_106
    .catch Ljava/lang/IllegalAccessException; {:try_start_ff .. :try_end_106} :catch_107

    .line 261
    .line 262
    .line 263
    goto :goto_10b

    .line 264
    :catch_107
    move-exception v0

    .line 265
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 266
    .line 267
    .line 268
    :cond_10b
    :goto_10b
    if-eq v8, v9, :cond_110

    .line 269
    .line 270
    invoke-virtual {v1}, Landroid/view/View;->refreshDrawableState()V

    .line 271
    .line 272
    .line 273
    :cond_110
    if-eqz v12, :cond_12a

    .line 274
    .line 275
    invoke-virtual {v4}, Landroid/graphics/Rect;->exactCenterX()F

    .line 276
    .line 277
    .line 278
    move-result v0

    .line 279
    invoke-virtual {v4}, Landroid/graphics/Rect;->exactCenterY()F

    .line 280
    .line 281
    .line 282
    move-result v4

    .line 283
    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    .line 284
    .line 285
    .line 286
    move-result v12

    .line 287
    if-nez v12, :cond_123

    .line 288
    .line 289
    move/from16 v12, v16

    .line 290
    .line 291
    goto :goto_124

    .line 292
    :cond_123
    move v12, v5

    .line 293
    :goto_124
    invoke-virtual {v11, v12, v5}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    .line 294
    .line 295
    .line 296
    invoke-virtual {v11, v0, v4}, Landroid/graphics/drawable/Drawable;->setHotspot(FF)V

    .line 297
    .line 298
    .line 299
    :cond_12a
    invoke-virtual {v1}, Landroid/widget/AbsListView;->getSelector()Landroid/graphics/drawable/Drawable;

    .line 300
    .line 301
    .line 302
    move-result-object v0

    .line 303
    if-eqz v0, :cond_135

    .line 304
    .line 305
    if-eq v8, v9, :cond_135

    .line 306
    .line 307
    invoke-virtual {v0, v7, v10}, Landroid/graphics/drawable/Drawable;->setHotspot(FF)V

    .line 308
    .line 309
    .line 310
    :cond_135
    iget-object v0, v1, Lj/W;->k:Lj/U;

    .line 311
    .line 312
    if-eqz v0, :cond_13b

    .line 313
    .line 314
    iput-boolean v5, v0, Lj/U;->f:Z

    .line 315
    .line 316
    :cond_13b
    invoke-virtual {v1}, Landroid/view/View;->refreshDrawableState()V

    .line 317
    .line 318
    .line 319
    move/from16 v4, v16

    .line 320
    .line 321
    if-ne v3, v4, :cond_149

    .line 322
    .line 323
    invoke-virtual {v1, v8}, Landroid/widget/AdapterView;->getItemIdAtPosition(I)J

    .line 324
    .line 325
    .line 326
    move-result-wide v3

    .line 327
    invoke-virtual {v1, v6, v8, v3, v4}, Landroid/widget/AdapterView;->performItemClick(Landroid/view/View;IJ)Z

    .line 328
    .line 329
    .line 330
    :cond_149
    move v4, v5

    .line 331
    const/4 v6, 0x1

    .line 332
    :goto_14b
    if-eqz v6, :cond_14f

    .line 333
    .line 334
    if-eqz v4, :cond_167

    .line 335
    .line 336
    :cond_14f
    iput-boolean v5, v1, Lj/W;->n:Z

    .line 337
    .line 338
    invoke-virtual {v1, v5}, Landroid/view/View;->setPressed(Z)V

    .line 339
    .line 340
    .line 341
    invoke-virtual {v1}, Lj/W;->drawableStateChanged()V

    .line 342
    .line 343
    .line 344
    iget v0, v1, Lj/W;->j:I

    .line 345
    .line 346
    invoke-virtual {v1}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    .line 347
    .line 348
    .line 349
    move-result v3

    .line 350
    sub-int/2addr v0, v3

    .line 351
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    if-eqz v0, :cond_167

    .line 356
    .line 357
    invoke-virtual {v0, v5}, Landroid/view/View;->setPressed(Z)V

    .line 358
    .line 359
    .line 360
    :cond_167
    if-eqz v6, :cond_17f

    .line 361
    .line 362
    iget-object v0, v1, Lj/W;->o:LF/e;

    .line 363
    .line 364
    if-nez v0, :cond_174

    .line 365
    .line 366
    new-instance v0, LF/e;

    .line 367
    .line 368
    invoke-direct {v0, v1}, LF/e;-><init>(Lj/W;)V

    .line 369
    .line 370
    .line 371
    iput-object v0, v1, Lj/W;->o:LF/e;

    .line 372
    .line 373
    :cond_174
    iget-object v0, v1, Lj/W;->o:LF/e;

    .line 374
    .line 375
    iget-boolean v3, v0, LF/e;->t:Z

    .line 376
    .line 377
    const/4 v4, 0x1

    .line 378
    iput-boolean v4, v0, LF/e;->t:Z

    .line 379
    .line 380
    invoke-virtual {v0, v1, v2}, LF/e;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z

    .line 381
    .line 382
    .line 383
    goto :goto_18c

    .line 384
    :cond_17f
    iget-object v0, v1, Lj/W;->o:LF/e;

    .line 385
    .line 386
    if-eqz v0, :cond_18c

    .line 387
    .line 388
    iget-boolean v2, v0, LF/e;->t:Z

    .line 389
    .line 390
    if-eqz v2, :cond_18a

    .line 391
    .line 392
    invoke-virtual {v0}, LF/e;->d()V

    .line 393
    .line 394
    .line 395
    :cond_18a
    iput-boolean v5, v0, LF/e;->t:Z

    .line 396
    .line 397
    :cond_18c
    :goto_18c
    return v6
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lj/W;->e:Landroid/graphics/Rect;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_14

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/widget/AbsListView;->getSelector()Landroid/graphics/drawable/Drawable;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-eqz v1, :cond_14

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 19
    .line 20
    .line 21
    :cond_14
    invoke-super {p0, p1}, Landroid/widget/ListView;->dispatchDraw(Landroid/graphics/Canvas;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final drawableStateChanged()V
    .registers 3

    .line 1
    iget-object v0, p0, Lj/W;->p:LF/b;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    goto :goto_26

    .line 6
    :cond_5
    invoke-super {p0}, Landroid/view/View;->drawableStateChanged()V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Lj/W;->k:Lj/U;

    .line 10
    .line 11
    if-eqz v0, :cond_f

    .line 12
    .line 13
    const/4 v1, 0x1

    .line 14
    iput-boolean v1, v0, Lj/U;->f:Z

    .line 15
    .line 16
    :cond_f
    invoke-virtual {p0}, Landroid/widget/AbsListView;->getSelector()Landroid/graphics/drawable/Drawable;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    if-eqz v0, :cond_26

    .line 21
    .line 22
    iget-boolean v1, p0, Lj/W;->n:Z

    .line 23
    .line 24
    if-eqz v1, :cond_26

    .line 25
    .line 26
    invoke-virtual {p0}, Landroid/view/View;->isPressed()Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_26

    .line 31
    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 37
    .line 38
    .line 39
    :cond_26
    :goto_26
    return-void
.end method

.method public final hasFocus()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lj/W;->m:Z

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    invoke-super {p0}, Landroid/view/View;->hasFocus()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    goto :goto_d

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    return v0

    .line 14
    :cond_d
    :goto_d
    const/4 v0, 0x1

    .line 15
    return v0
.end method

.method public final hasWindowFocus()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lj/W;->m:Z

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    invoke-super {p0}, Landroid/view/View;->hasWindowFocus()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    goto :goto_d

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    return v0

    .line 14
    :cond_d
    :goto_d
    const/4 v0, 0x1

    .line 15
    return v0
.end method

.method public final isFocused()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lj/W;->m:Z

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    invoke-super {p0}, Landroid/view/View;->isFocused()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    goto :goto_d

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    return v0

    .line 14
    :cond_d
    :goto_d
    const/4 v0, 0x1

    .line 15
    return v0
.end method

.method public final isInTouchMode()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Lj/W;->m:Z

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    iget-boolean v0, p0, Lj/W;->l:Z

    .line 6
    .line 7
    if-nez v0, :cond_e

    .line 8
    .line 9
    :cond_8
    invoke-super {p0}, Landroid/view/View;->isInTouchMode()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_10

    .line 14
    .line 15
    :cond_e
    const/4 v0, 0x1

    .line 16
    return v0

    .line 17
    :cond_10
    const/4 v0, 0x0

    .line 18
    return v0
.end method

.method public final onDetachedFromWindow()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lj/W;->p:LF/b;

    .line 3
    .line 4
    invoke-super {p0}, Landroid/widget/ListView;->onDetachedFromWindow()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public onHoverEvent(Landroid/view/MotionEvent;)Z
    .registers 9

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1a

    .line 4
    .line 5
    if-ge v0, v1, :cond_b

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/view/View;->onHoverEvent(Landroid/view/MotionEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1

    .line 12
    :cond_b
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/16 v2, 0xa

    .line 17
    .line 18
    if-ne v1, v2, :cond_23

    .line 19
    .line 20
    iget-object v2, p0, Lj/W;->p:LF/b;

    .line 21
    .line 22
    if-nez v2, :cond_23

    .line 23
    .line 24
    new-instance v2, LF/b;

    .line 25
    .line 26
    const/16 v3, 0xe

    .line 27
    .line 28
    invoke-direct {v2, v3, p0}, LF/b;-><init>(ILjava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iput-object v2, p0, Lj/W;->p:LF/b;

    .line 32
    .line 33
    invoke-virtual {p0, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 34
    .line 35
    .line 36
    :cond_23
    invoke-super {p0, p1}, Landroid/view/View;->onHoverEvent(Landroid/view/MotionEvent;)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    const/16 v3, 0x9

    .line 41
    .line 42
    const/4 v4, -0x1

    .line 43
    if-eq v1, v3, :cond_34

    .line 44
    .line 45
    const/4 v3, 0x7

    .line 46
    if-ne v1, v3, :cond_30

    .line 47
    .line 48
    goto :goto_34

    .line 49
    :cond_30
    invoke-virtual {p0, v4}, Landroid/widget/AdapterView;->setSelection(I)V

    .line 50
    .line 51
    .line 52
    return v2

    .line 53
    :cond_34
    :goto_34
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    float-to-int v1, v1

    .line 58
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 59
    .line 60
    .line 61
    move-result p1

    .line 62
    float-to-int p1, p1

    .line 63
    invoke-virtual {p0, v1, p1}, Landroid/widget/AbsListView;->pointToPosition(II)I

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    if-eq p1, v4, :cond_c6

    .line 68
    .line 69
    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    if-eq p1, v1, :cond_c6

    .line 74
    .line 75
    invoke-virtual {p0}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    sub-int v1, p1, v1

    .line 80
    .line 81
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    invoke-virtual {v1}, Landroid/view/View;->isEnabled()Z

    .line 86
    .line 87
    .line 88
    move-result v3

    .line 89
    if-eqz v3, :cond_af

    .line 90
    .line 91
    invoke-virtual {p0}, Landroid/view/View;->requestFocus()Z

    .line 92
    .line 93
    .line 94
    const/16 v3, 0x1e

    .line 95
    .line 96
    if-lt v0, v3, :cond_a3

    .line 97
    .line 98
    sget-boolean v0, Lj/S;->d:Z

    .line 99
    .line 100
    if-eqz v0, :cond_a3

    .line 101
    .line 102
    :try_start_65
    sget-object v0, Lj/S;->a:Ljava/lang/reflect/Method;

    .line 103
    .line 104
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 109
    .line 110
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 111
    .line 112
    .line 113
    move-result-object v6

    .line 114
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 115
    .line 116
    .line 117
    move-result-object v4

    .line 118
    filled-new-array {v3, v1, v5, v6, v4}, [Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    sget-object v0, Lj/S;->b:Ljava/lang/reflect/Method;

    .line 126
    .line 127
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    sget-object v0, Lj/S;->c:Ljava/lang/reflect/Method;

    .line 139
    .line 140
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    invoke-virtual {v0, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_96
    .catch Ljava/lang/IllegalAccessException; {:try_start_65 .. :try_end_96} :catch_99
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_65 .. :try_end_96} :catch_97

    .line 149
    .line 150
    .line 151
    goto :goto_af

    .line 152
    :catch_97
    move-exception p1

    .line 153
    goto :goto_9b

    .line 154
    :catch_99
    move-exception p1

    .line 155
    goto :goto_9f

    .line 156
    :goto_9b
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 157
    .line 158
    .line 159
    goto :goto_af

    .line 160
    :goto_9f
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 161
    .line 162
    .line 163
    goto :goto_af

    .line 164
    :cond_a3
    invoke-virtual {v1}, Landroid/view/View;->getTop()I

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    .line 169
    .line 170
    .line 171
    move-result v1

    .line 172
    sub-int/2addr v0, v1

    .line 173
    invoke-virtual {p0, p1, v0}, Landroid/widget/AbsListView;->setSelectionFromTop(II)V

    .line 174
    .line 175
    .line 176
    :cond_af
    :goto_af
    invoke-virtual {p0}, Landroid/widget/AbsListView;->getSelector()Landroid/graphics/drawable/Drawable;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    if-eqz p1, :cond_c6

    .line 181
    .line 182
    iget-boolean v0, p0, Lj/W;->n:Z

    .line 183
    .line 184
    if-eqz v0, :cond_c6

    .line 185
    .line 186
    invoke-virtual {p0}, Landroid/view/View;->isPressed()Z

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    if-eqz v0, :cond_c6

    .line 191
    .line 192
    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    .line 193
    .line 194
    .line 195
    move-result-object v0

    .line 196
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 197
    .line 198
    .line 199
    :cond_c6
    return v2
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 5

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    goto :goto_17

    .line 8
    :cond_7
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    float-to-int v0, v0

    .line 13
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    float-to-int v1, v1

    .line 18
    invoke-virtual {p0, v0, v1}, Landroid/widget/AbsListView;->pointToPosition(II)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iput v0, p0, Lj/W;->j:I

    .line 23
    .line 24
    :goto_17
    iget-object v0, p0, Lj/W;->p:LF/b;

    .line 25
    .line 26
    if-eqz v0, :cond_25

    .line 27
    .line 28
    iget-object v1, v0, LF/b;->f:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v1, Lj/W;

    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    iput-object v2, v1, Lj/W;->p:LF/b;

    .line 34
    .line 35
    invoke-virtual {v1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 36
    .line 37
    .line 38
    :cond_25
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    return p1
.end method

.method public setListSelectionHidden(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lj/W;->l:Z

    .line 2
    .line 3
    return-void
.end method

.method public setSelector(Landroid/graphics/drawable/Drawable;)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_18

    .line 3
    .line 4
    new-instance v1, Lj/U;

    .line 5
    .line 6
    invoke-direct {v1}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 7
    .line 8
    .line 9
    iget-object v2, v1, Lj/U;->e:Landroid/graphics/drawable/Drawable;

    .line 10
    .line 11
    if-eqz v2, :cond_f

    .line 12
    .line 13
    invoke-virtual {v2, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 14
    .line 15
    .line 16
    :cond_f
    iput-object p1, v1, Lj/U;->e:Landroid/graphics/drawable/Drawable;

    .line 17
    .line 18
    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 19
    .line 20
    .line 21
    const/4 v0, 0x1

    .line 22
    iput-boolean v0, v1, Lj/U;->f:Z

    .line 23
    .line 24
    move-object v0, v1

    .line 25
    :cond_18
    iput-object v0, p0, Lj/W;->k:Lj/U;

    .line 26
    .line 27
    invoke-super {p0, v0}, Landroid/widget/AbsListView;->setSelector(Landroid/graphics/drawable/Drawable;)V

    .line 28
    .line 29
    .line 30
    new-instance v0, Landroid/graphics/Rect;

    .line 31
    .line 32
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 33
    .line 34
    .line 35
    if-eqz p1, :cond_27

    .line 36
    .line 37
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    .line 38
    .line 39
    .line 40
    :cond_27
    iget p1, v0, Landroid/graphics/Rect;->left:I

    .line 41
    .line 42
    iput p1, p0, Lj/W;->f:I

    .line 43
    .line 44
    iget p1, v0, Landroid/graphics/Rect;->top:I

    .line 45
    .line 46
    iput p1, p0, Lj/W;->g:I

    .line 47
    .line 48
    iget p1, v0, Landroid/graphics/Rect;->right:I

    .line 49
    .line 50
    iput p1, p0, Lj/W;->h:I

    .line 51
    .line 52
    iget p1, v0, Landroid/graphics/Rect;->bottom:I

    .line 53
    .line 54
    iput p1, p0, Lj/W;->i:I

    .line 55
    .line 56
    return-void
.end method
