###### Class j.L0 (j.L0)
.class public abstract Lj/L0;
.super Lj/q0;
.source "SourceFile"
