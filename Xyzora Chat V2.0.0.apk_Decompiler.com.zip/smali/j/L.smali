###### Class j.L (j.L)
.class public interface abstract Lj/L;
.super Ljava/lang/Object;
.source "SourceFile"
