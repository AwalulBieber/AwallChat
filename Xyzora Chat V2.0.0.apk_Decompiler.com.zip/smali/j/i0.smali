###### Class j.InterfaceC0159i0 (j.i0)
.class public interface abstract Lj/i0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Li/i;Li/j;)V
.end method

.method public abstract d(Li/i;Li/j;)V
.end method
