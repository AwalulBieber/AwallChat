###### Class j.InterfaceC0160j (j.j)
.class public interface abstract Lj/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b()Z
.end method
