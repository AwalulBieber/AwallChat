###### Class j.I0 (j.I0)
.class public abstract Lj/I0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/animation/ObjectAnimator;Z)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroid/animation/ObjectAnimator;->setAutoCancel(Z)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
