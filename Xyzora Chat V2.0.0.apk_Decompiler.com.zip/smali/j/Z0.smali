###### Class j.Z0 (j.Z0)
.class public interface abstract Lj/Z0;
.super Ljava/lang/Object;
.source "SourceFile"
