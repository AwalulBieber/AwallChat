###### Class j.C0152f (j.f)
.class public final Lj/f;
.super Li/n;
.source "SourceFile"


# instance fields
.field public final synthetic l:I

.field public final synthetic m:Lj/i;


# direct methods
.method public constructor <init>(Lj/i;Landroid/content/Context;Li/i;Landroid/view/View;)V
    .registers 12

    const/4 v0, 0x1

    iput v0, p0, Lj/f;->l:I

    .line 1
    iput-object p1, p0, Lj/f;->m:Lj/i;

    const v2, 0x7f030020

    const/4 v6, 0x1

    move-object v1, p0

    move-object v3, p2

    move-object v5, p3

    move-object v4, p4

    .line 2
    invoke-direct/range {v1 .. v6}, Li/n;-><init>(ILandroid/content/Context;Landroid/view/View;Li/i;Z)V

    const p2, 0x800005

    .line 3
    iput p2, v1, Li/n;->f:I

    .line 4
    iget-object p1, p1, Lj/i;->z:La2/k;

    .line 5
    iput-object p1, v1, Li/n;->h:Li/o;

    .line 6
    iget-object p2, v1, Li/n;->i:Li/k;

    if-eqz p2, :cond_20

    .line 7
    invoke-interface {p2, p1}, Li/p;->f(Li/o;)V

    :cond_20
    return-void
.end method

.method public constructor <init>(Lj/i;Landroid/content/Context;Li/t;Landroid/view/View;)V
    .registers 12

    const/4 v0, 0x0

    iput v0, p0, Lj/f;->l:I

    .line 8
    iput-object p1, p0, Lj/f;->m:Lj/i;

    const/4 v6, 0x0

    const v2, 0x7f030020

    move-object v1, p0

    move-object v3, p2

    move-object v5, p3

    move-object v4, p4

    .line 9
    invoke-direct/range {v1 .. v6}, Li/n;-><init>(ILandroid/content/Context;Landroid/view/View;Li/i;Z)V

    .line 10
    iget-object p2, v5, Li/t;->w:Li/j;

    .line 11
    iget p2, p2, Li/j;->x:I

    const/16 p3, 0x20

    and-int/2addr p2, p3

    if-ne p2, p3, :cond_1a

    goto :goto_22

    .line 12
    :cond_1a
    iget-object p2, p1, Lj/i;->l:Lj/h;

    if-nez p2, :cond_20

    .line 13
    iget-object p2, p1, Lj/i;->k:Landroidx/appcompat/widget/ActionMenuView;

    .line 14
    :cond_20
    iput-object p2, v1, Li/n;->e:Landroid/view/View;

    .line 15
    :goto_22
    iget-object p1, p1, Lj/i;->z:La2/k;

    .line 16
    iput-object p1, v1, Li/n;->h:Li/o;

    .line 17
    iget-object p2, v1, Li/n;->i:Li/k;

    if-eqz p2, :cond_2d

    .line 18
    invoke-interface {p2, p1}, Li/p;->f(Li/o;)V

    :cond_2d
    return-void
.end method


# virtual methods
.method public final c()V
    .registers 4

    .line 1
    iget v0, p0, Lj/f;->l:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_22

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lj/f;->m:Lj/i;

    .line 7
    .line 8
    iget-object v1, v0, Lj/i;->g:Li/i;

    .line 9
    .line 10
    if-eqz v1, :cond_f

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    invoke-virtual {v1, v2}, Li/i;->c(Z)V

    .line 14
    .line 15
    .line 16
    :cond_f
    const/4 v1, 0x0

    .line 17
    iput-object v1, v0, Lj/i;->v:Lj/f;

    .line 18
    .line 19
    invoke-super {p0}, Li/n;->c()V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :pswitch_16
    const/4 v0, 0x0

    .line 24
    iget-object v1, p0, Lj/f;->m:Lj/i;

    .line 25
    .line 26
    iput-object v0, v1, Lj/i;->w:Lj/f;

    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    invoke-super {p0}, Li/n;->c()V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_16
    .end packed-switch
.end method
