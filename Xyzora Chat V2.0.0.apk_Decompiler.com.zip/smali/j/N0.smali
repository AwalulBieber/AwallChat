###### Class j.N0 (j.N0)
.class public final Lj/N0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/Toolbar;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lj/N0;->e:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj/N0;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lj/T0;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, Lj/N0;->e:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj/N0;->f:Ljava/lang/Object;

    .line 2
    iget-object p1, p1, Lj/T0;->a:Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .line 1
    iget p1, p0, Lj/N0;->e:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_24

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lj/N0;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p1, Lj/T0;

    .line 9
    .line 10
    iget-object v0, p1, Lj/T0;->k:Landroid/view/Window$Callback;

    .line 11
    .line 12
    if-eqz v0, :cond_10

    .line 13
    .line 14
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void

    .line 18
    :pswitch_11
    iget-object p1, p0, Lj/N0;->f:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Landroidx/appcompat/widget/Toolbar;

    .line 21
    .line 22
    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->O:Lj/P0;

    .line 23
    .line 24
    if-nez p1, :cond_1b

    .line 25
    .line 26
    const/4 p1, 0x0

    .line 27
    goto :goto_1d

    .line 28
    :cond_1b
    iget-object p1, p1, Lj/P0;->f:Li/j;

    .line 29
    .line 30
    :goto_1d
    if-eqz p1, :cond_22

    .line 31
    .line 32
    invoke-virtual {p1}, Li/j;->collapseActionView()Z

    .line 33
    .line 34
    .line 35
    :cond_22
    return-void

    .line 36
    nop

    .line 37
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method
