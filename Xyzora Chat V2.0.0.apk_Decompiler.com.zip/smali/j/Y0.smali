###### Class j.Y0 (j.Y0)
.class public abstract Lj/Y0;
.super Lj/q0;
.source "SourceFile"


# static fields
.field public static final synthetic a:I
