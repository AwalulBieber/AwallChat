###### Class j.X (j.X)
.class public interface abstract Lj/X;
.super Ljava/lang/Object;
.source "SourceFile"
