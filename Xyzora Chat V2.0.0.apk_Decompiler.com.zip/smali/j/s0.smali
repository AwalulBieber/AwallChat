###### Class j.AbstractC0178s0 (j.s0)
.class public abstract Lj/s0;
.super Landroid/widget/HorizontalScrollView;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;
