###### Class j.InterfaceC0192z0 (j.z0)
.class public interface abstract Lj/z0;
.super Ljava/lang/Object;
.source "SourceFile"
