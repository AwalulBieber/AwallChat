###### Class C.N (C.N)
.class public abstract LC/N;
.super LC/V;
.source "SourceFile"


# static fields
.field public static i:Z = false

.field public static j:Ljava/lang/reflect/Method;

.field public static k:Ljava/lang/Class;

.field public static l:Ljava/lang/reflect/Field;

.field public static m:Ljava/lang/reflect/Field;


# instance fields
.field public final c:Landroid/view/WindowInsets;

.field public d:[Lv/b;

.field public e:Lv/b;

.field public f:LC/Z;

.field public g:Lv/b;

.field public h:I


# direct methods
.method public constructor <init>(LC/Z;Landroid/view/WindowInsets;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, LC/V;-><init>(LC/Z;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, LC/N;->e:Lv/b;

    .line 6
    .line 7
    iput-object p2, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 8
    .line 9
    return-void
.end method

.method public static A(II)Z
    .registers 2

    .line 1
    and-int/lit8 p0, p0, 0x6

    .line 2
    .line 3
    and-int/lit8 p1, p1, 0x6

    .line 4
    .line 5
    if-ne p0, p1, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_8
    const/4 p0, 0x0

    .line 10
    return p0
.end method

.method private t(IZ)Lv/b;
    .registers 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    .line 1
    sget-object v0, Lv/b;->e:Lv/b;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    :goto_3
    const/16 v2, 0x200

    .line 5
    .line 6
    if-gt v1, v2, :cond_17

    .line 7
    .line 8
    and-int v2, p1, v1

    .line 9
    .line 10
    if-nez v2, :cond_c

    .line 11
    .line 12
    goto :goto_14

    .line 13
    :cond_c
    invoke-virtual {p0, v1, p2}, LC/N;->u(IZ)Lv/b;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-static {v0, v2}, Lv/b;->a(Lv/b;Lv/b;)Lv/b;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    :goto_14
    shl-int/lit8 v1, v1, 0x1

    .line 22
    .line 23
    goto :goto_3

    .line 24
    :cond_17
    return-object v0
.end method

.method private v()Lv/b;
    .registers 2

    .line 1
    iget-object v0, p0, LC/N;->f:LC/Z;

    .line 2
    .line 3
    if-eqz v0, :cond_b

    .line 4
    .line 5
    iget-object v0, v0, LC/Z;->a:LC/V;

    .line 6
    .line 7
    invoke-virtual {v0}, LC/V;->h()Lv/b;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0

    .line 12
    :cond_b
    sget-object v0, Lv/b;->e:Lv/b;

    .line 13
    .line 14
    return-object v0
.end method

.method private w(Landroid/view/View;)Lv/b;
    .registers 7

    .line 1
    const-string v0, "WindowInsetsCompat"

    .line 2
    .line 3
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 4
    .line 5
    const/16 v2, 0x1e

    .line 6
    .line 7
    if-ge v1, v2, :cond_66

    .line 8
    .line 9
    sget-boolean v1, LC/N;->i:Z

    .line 10
    .line 11
    if-nez v1, :cond_f

    .line 12
    .line 13
    invoke-static {}, LC/N;->y()V

    .line 14
    .line 15
    .line 16
    :cond_f
    sget-object v1, LC/N;->j:Ljava/lang/reflect/Method;

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    if-eqz v1, :cond_65

    .line 20
    .line 21
    sget-object v3, LC/N;->k:Ljava/lang/Class;

    .line 22
    .line 23
    if-eqz v3, :cond_65

    .line 24
    .line 25
    sget-object v3, LC/N;->l:Ljava/lang/reflect/Field;

    .line 26
    .line 27
    if-nez v3, :cond_1d

    .line 28
    .line 29
    goto :goto_65

    .line 30
    :cond_1d
    const/4 v3, 0x0

    .line 31
    :try_start_1e
    new-array v3, v3, [Ljava/lang/Object;

    .line 32
    .line 33
    invoke-virtual {v1, p1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    if-nez p1, :cond_33

    .line 38
    .line 39
    const-string p1, "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden"

    .line 40
    .line 41
    new-instance v1, Ljava/lang/NullPointerException;

    .line 42
    .line 43
    invoke-direct {v1}, Ljava/lang/NullPointerException;-><init>()V

    .line 44
    .line 45
    .line 46
    invoke-static {v0, p1, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 47
    .line 48
    .line 49
    return-object v2

    .line 50
    :catch_31
    move-exception p1

    .line 51
    goto :goto_50

    .line 52
    :cond_33
    sget-object v1, LC/N;->m:Ljava/lang/reflect/Field;

    .line 53
    .line 54
    invoke-virtual {v1, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    sget-object v1, LC/N;->l:Ljava/lang/reflect/Field;

    .line 59
    .line 60
    invoke-virtual {v1, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    check-cast p1, Landroid/graphics/Rect;

    .line 65
    .line 66
    if-eqz p1, :cond_65

    .line 67
    .line 68
    iget v1, p1, Landroid/graphics/Rect;->left:I

    .line 69
    .line 70
    iget v3, p1, Landroid/graphics/Rect;->top:I

    .line 71
    .line 72
    iget v4, p1, Landroid/graphics/Rect;->right:I

    .line 73
    .line 74
    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    .line 75
    .line 76
    invoke-static {v1, v3, v4, p1}, Lv/b;->b(IIII)Lv/b;

    .line 77
    .line 78
    .line 79
    move-result-object p1
    :try_end_4f
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_1e .. :try_end_4f} :catch_31

    .line 80
    return-object p1

    .line 81
    :goto_50
    new-instance v1, Ljava/lang/StringBuilder;

    .line 82
    .line 83
    const-string v3, "Failed to get visible insets. (Reflection error). "

    .line 84
    .line 85
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 100
    .line 101
    .line 102
    :cond_65
    :goto_65
    return-object v2

    .line 103
    :cond_66
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 104
    .line 105
    const-string v0, "getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead."

    .line 106
    .line 107
    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    throw p1
.end method

.method private static y()V
    .registers 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PrivateApi"
        }
    .end annotation

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_1
    const-class v1, Landroid/view/View;

    .line 3
    .line 4
    const-string v2, "getViewRootImpl"

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    new-array v3, v3, [Ljava/lang/Class;

    .line 8
    .line 9
    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    sput-object v1, LC/N;->j:Ljava/lang/reflect/Method;

    .line 14
    .line 15
    const-string v1, "android.view.View$AttachInfo"

    .line 16
    .line 17
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    sput-object v1, LC/N;->k:Ljava/lang/Class;

    .line 22
    .line 23
    const-string v2, "mVisibleInsets"

    .line 24
    .line 25
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    sput-object v1, LC/N;->l:Ljava/lang/reflect/Field;

    .line 30
    .line 31
    const-string v1, "android.view.ViewRootImpl"

    .line 32
    .line 33
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    const-string v2, "mAttachInfo"

    .line 38
    .line 39
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    sput-object v1, LC/N;->m:Ljava/lang/reflect/Field;

    .line 44
    .line 45
    sget-object v1, LC/N;->l:Ljava/lang/reflect/Field;

    .line 46
    .line 47
    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 48
    .line 49
    .line 50
    sget-object v1, LC/N;->m:Ljava/lang/reflect/Field;

    .line 51
    .line 52
    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_36
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_1 .. :try_end_36} :catch_37

    .line 53
    .line 54
    .line 55
    goto :goto_4f

    .line 56
    :catch_37
    move-exception v1

    .line 57
    new-instance v2, Ljava/lang/StringBuilder;

    .line 58
    .line 59
    const-string v3, "Failed to get visible insets. (Reflection error). "

    .line 60
    .line 61
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    const-string v3, "WindowInsetsCompat"

    .line 76
    .line 77
    invoke-static {v3, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 78
    .line 79
    .line 80
    :goto_4f
    sput-boolean v0, LC/N;->i:Z

    .line 81
    .line 82
    return-void
.end method


# virtual methods
.method public d(Landroid/view/View;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, LC/N;->w(Landroid/view/View;)Lv/b;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    if-nez p1, :cond_8

    .line 6
    .line 7
    sget-object p1, Lv/b;->e:Lv/b;

    .line 8
    .line 9
    :cond_8
    invoke-virtual {p0, p1}, LC/N;->z(Lv/b;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    invoke-super {p0, p1}, LC/V;->equals(Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_8

    .line 7
    .line 8
    return v1

    .line 9
    :cond_8
    check-cast p1, LC/N;

    .line 10
    .line 11
    iget-object v0, p0, LC/N;->g:Lv/b;

    .line 12
    .line 13
    iget-object v2, p1, LC/N;->g:Lv/b;

    .line 14
    .line 15
    invoke-static {v0, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_20

    .line 20
    .line 21
    iget v0, p0, LC/N;->h:I

    .line 22
    .line 23
    iget p1, p1, LC/N;->h:I

    .line 24
    .line 25
    invoke-static {v0, p1}, LC/N;->A(II)Z

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    if-eqz p1, :cond_20

    .line 30
    .line 31
    const/4 p1, 0x1

    .line 32
    return p1

    .line 33
    :cond_20
    return v1
.end method

.method public f(I)Lv/b;
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, v0}, LC/N;->t(IZ)Lv/b;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    return-object p1
.end method

.method public final j()Lv/b;
    .registers 5

    .line 1
    iget-object v0, p0, LC/N;->e:Lv/b;

    .line 2
    .line 3
    if-nez v0, :cond_1c

    .line 4
    .line 5
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetLeft()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetTop()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetRight()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v1, v2, v3, v0}, Lv/b;->b(IIII)Lv/b;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, LC/N;->e:Lv/b;

    .line 28
    .line 29
    :cond_1c
    iget-object v0, p0, LC/N;->e:Lv/b;

    .line 30
    .line 31
    return-object v0
.end method

.method public l(IIII)LC/Z;
    .registers 8

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 3
    .line 4
    invoke-static {v1, v0}, LC/Z;->c(Landroid/view/WindowInsets;Landroid/view/View;)LC/Z;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 v2, 0x22

    .line 11
    .line 12
    if-lt v1, v2, :cond_13

    .line 13
    .line 14
    new-instance v1, LC/L;

    .line 15
    .line 16
    invoke-direct {v1, v0}, LC/L;-><init>(LC/Z;)V

    .line 17
    .line 18
    .line 19
    goto :goto_36

    .line 20
    :cond_13
    const/16 v2, 0x1f

    .line 21
    .line 22
    if-lt v1, v2, :cond_1d

    .line 23
    .line 24
    new-instance v1, LC/K;

    .line 25
    .line 26
    invoke-direct {v1, v0}, LC/K;-><init>(LC/Z;)V

    .line 27
    .line 28
    .line 29
    goto :goto_36

    .line 30
    :cond_1d
    const/16 v2, 0x1e

    .line 31
    .line 32
    if-lt v1, v2, :cond_27

    .line 33
    .line 34
    new-instance v1, LC/J;

    .line 35
    .line 36
    invoke-direct {v1, v0}, LC/J;-><init>(LC/Z;)V

    .line 37
    .line 38
    .line 39
    goto :goto_36

    .line 40
    :cond_27
    const/16 v2, 0x1d

    .line 41
    .line 42
    if-lt v1, v2, :cond_31

    .line 43
    .line 44
    new-instance v1, LC/H;

    .line 45
    .line 46
    invoke-direct {v1, v0}, LC/H;-><init>(LC/Z;)V

    .line 47
    .line 48
    .line 49
    goto :goto_36

    .line 50
    :cond_31
    new-instance v1, LC/F;

    .line 51
    .line 52
    invoke-direct {v1, v0}, LC/F;-><init>(LC/Z;)V

    .line 53
    .line 54
    .line 55
    :goto_36
    invoke-virtual {p0}, LC/N;->j()Lv/b;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-static {v0, p1, p2, p3, p4}, LC/Z;->a(Lv/b;IIII)Lv/b;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-virtual {v1, v0}, LC/M;->g(Lv/b;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {p0}, LC/V;->h()Lv/b;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-static {v0, p1, p2, p3, p4}, LC/Z;->a(Lv/b;IIII)Lv/b;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-virtual {v1, p1}, LC/M;->e(Lv/b;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v1}, LC/M;->b()LC/Z;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    return-object p1
.end method

.method public n()Z
    .registers 2

    .line 1
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/WindowInsets;->isRound()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public o(I)Z
    .registers 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    .line 1
    const/4 v0, 0x1

    .line 2
    move v1, v0

    .line 3
    :goto_2
    const/16 v2, 0x200

    .line 4
    .line 5
    if-gt v1, v2, :cond_16

    .line 6
    .line 7
    and-int v2, p1, v1

    .line 8
    .line 9
    if-nez v2, :cond_b

    .line 10
    .line 11
    goto :goto_13

    .line 12
    :cond_b
    invoke-virtual {p0, v1}, LC/N;->x(I)Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-nez v2, :cond_13

    .line 17
    .line 18
    const/4 p1, 0x0

    .line 19
    return p1

    .line 20
    :cond_13
    :goto_13
    shl-int/lit8 v1, v1, 0x1

    .line 21
    .line 22
    goto :goto_2

    .line 23
    :cond_16
    return v0
.end method

.method public p([Lv/b;)V
    .registers 2

    .line 1
    iput-object p1, p0, LC/N;->d:[Lv/b;

    .line 2
    .line 3
    return-void
.end method

.method public q(LC/Z;)V
    .registers 2

    .line 1
    iput-object p1, p0, LC/N;->f:LC/Z;

    .line 2
    .line 3
    return-void
.end method

.method public s(I)V
    .registers 2

    .line 1
    iput p1, p0, LC/N;->h:I

    .line 2
    .line 3
    return-void
.end method

.method public u(IZ)Lv/b;
    .registers 8

    .line 1
    sget-object v0, Lv/b;->e:Lv/b;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eq p1, v1, :cond_f4

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v3, 0x2

    .line 9
    if-eq p1, v3, :cond_a6

    .line 10
    .line 11
    const/16 p2, 0x8

    .line 12
    .line 13
    if-eq p1, p2, :cond_6f

    .line 14
    .line 15
    const/16 p2, 0x10

    .line 16
    .line 17
    if-eq p1, p2, :cond_6a

    .line 18
    .line 19
    const/16 p2, 0x20

    .line 20
    .line 21
    if-eq p1, p2, :cond_65

    .line 22
    .line 23
    const/16 p2, 0x40

    .line 24
    .line 25
    if-eq p1, p2, :cond_60

    .line 26
    .line 27
    const/16 p2, 0x80

    .line 28
    .line 29
    if-eq p1, p2, :cond_20

    .line 30
    .line 31
    goto/16 :goto_111

    .line 32
    .line 33
    :cond_20
    iget-object p1, p0, LC/N;->f:LC/Z;

    .line 34
    .line 35
    if-eqz p1, :cond_2b

    .line 36
    .line 37
    iget-object p1, p1, LC/Z;->a:LC/V;

    .line 38
    .line 39
    invoke-virtual {p1}, LC/V;->e()LC/e;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    goto :goto_2f

    .line 44
    :cond_2b
    invoke-virtual {p0}, LC/V;->e()LC/e;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    :goto_2f
    if-eqz p1, :cond_111

    .line 49
    .line 50
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 51
    .line 52
    const/16 v0, 0x1c

    .line 53
    .line 54
    if-lt p2, v0, :cond_3e

    .line 55
    .line 56
    iget-object v1, p1, LC/e;->a:Landroid/view/DisplayCutout;

    .line 57
    .line 58
    invoke-static {v1}, LC/d;->i(Landroid/view/DisplayCutout;)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    goto :goto_3f

    .line 63
    :cond_3e
    move v1, v2

    .line 64
    :goto_3f
    if-lt p2, v0, :cond_48

    .line 65
    .line 66
    iget-object v3, p1, LC/e;->a:Landroid/view/DisplayCutout;

    .line 67
    .line 68
    invoke-static {v3}, LC/d;->k(Landroid/view/DisplayCutout;)I

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    goto :goto_49

    .line 73
    :cond_48
    move v3, v2

    .line 74
    :goto_49
    if-lt p2, v0, :cond_52

    .line 75
    .line 76
    iget-object v4, p1, LC/e;->a:Landroid/view/DisplayCutout;

    .line 77
    .line 78
    invoke-static {v4}, LC/d;->j(Landroid/view/DisplayCutout;)I

    .line 79
    .line 80
    .line 81
    move-result v4

    .line 82
    goto :goto_53

    .line 83
    :cond_52
    move v4, v2

    .line 84
    :goto_53
    if-lt p2, v0, :cond_5b

    .line 85
    .line 86
    iget-object p1, p1, LC/e;->a:Landroid/view/DisplayCutout;

    .line 87
    .line 88
    invoke-static {p1}, LC/d;->h(Landroid/view/DisplayCutout;)I

    .line 89
    .line 90
    .line 91
    move-result v2

    .line 92
    :cond_5b
    invoke-static {v1, v3, v4, v2}, Lv/b;->b(IIII)Lv/b;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    return-object p1

    .line 97
    :cond_60
    invoke-virtual {p0}, LC/V;->k()Lv/b;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    return-object p1

    .line 102
    :cond_65
    invoke-virtual {p0}, LC/V;->g()Lv/b;

    .line 103
    .line 104
    .line 105
    move-result-object p1

    .line 106
    return-object p1

    .line 107
    :cond_6a
    invoke-virtual {p0}, LC/V;->i()Lv/b;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    return-object p1

    .line 112
    :cond_6f
    iget-object p1, p0, LC/N;->d:[Lv/b;

    .line 113
    .line 114
    if-eqz p1, :cond_79

    .line 115
    .line 116
    invoke-static {p2}, Landroid/support/v4/media/session/a;->w(I)I

    .line 117
    .line 118
    .line 119
    move-result p2

    .line 120
    aget-object v1, p1, p2

    .line 121
    .line 122
    :cond_79
    if-eqz v1, :cond_7c

    .line 123
    .line 124
    return-object v1

    .line 125
    :cond_7c
    invoke-virtual {p0}, LC/N;->j()Lv/b;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    invoke-direct {p0}, LC/N;->v()Lv/b;

    .line 130
    .line 131
    .line 132
    move-result-object p2

    .line 133
    iget p1, p1, Lv/b;->d:I

    .line 134
    .line 135
    iget v1, p2, Lv/b;->d:I

    .line 136
    .line 137
    if-le p1, v1, :cond_8f

    .line 138
    .line 139
    invoke-static {v2, v2, v2, p1}, Lv/b;->b(IIII)Lv/b;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    return-object p1

    .line 144
    :cond_8f
    iget-object p1, p0, LC/N;->g:Lv/b;

    .line 145
    .line 146
    if-eqz p1, :cond_111

    .line 147
    .line 148
    invoke-virtual {p1, v0}, Lv/b;->equals(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result p1

    .line 152
    if-nez p1, :cond_111

    .line 153
    .line 154
    iget-object p1, p0, LC/N;->g:Lv/b;

    .line 155
    .line 156
    iget p1, p1, Lv/b;->d:I

    .line 157
    .line 158
    iget p2, p2, Lv/b;->d:I

    .line 159
    .line 160
    if-le p1, p2, :cond_111

    .line 161
    .line 162
    invoke-static {v2, v2, v2, p1}, Lv/b;->b(IIII)Lv/b;

    .line 163
    .line 164
    .line 165
    move-result-object p1

    .line 166
    return-object p1

    .line 167
    :cond_a6
    if-eqz p2, :cond_cd

    .line 168
    .line 169
    invoke-direct {p0}, LC/N;->v()Lv/b;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    invoke-virtual {p0}, LC/V;->h()Lv/b;

    .line 174
    .line 175
    .line 176
    move-result-object p2

    .line 177
    iget v0, p1, Lv/b;->a:I

    .line 178
    .line 179
    iget v1, p2, Lv/b;->a:I

    .line 180
    .line 181
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 182
    .line 183
    .line 184
    move-result v0

    .line 185
    iget v1, p1, Lv/b;->c:I

    .line 186
    .line 187
    iget v3, p2, Lv/b;->c:I

    .line 188
    .line 189
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 190
    .line 191
    .line 192
    move-result v1

    .line 193
    iget p1, p1, Lv/b;->d:I

    .line 194
    .line 195
    iget p2, p2, Lv/b;->d:I

    .line 196
    .line 197
    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    .line 198
    .line 199
    .line 200
    move-result p1

    .line 201
    invoke-static {v0, v2, v1, p1}, Lv/b;->b(IIII)Lv/b;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    return-object p1

    .line 206
    :cond_cd
    iget p1, p0, LC/N;->h:I

    .line 207
    .line 208
    and-int/2addr p1, v3

    .line 209
    if-eqz p1, :cond_d3

    .line 210
    .line 211
    goto :goto_111

    .line 212
    :cond_d3
    invoke-virtual {p0}, LC/N;->j()Lv/b;

    .line 213
    .line 214
    .line 215
    move-result-object p1

    .line 216
    iget-object p2, p0, LC/N;->f:LC/Z;

    .line 217
    .line 218
    if-eqz p2, :cond_e1

    .line 219
    .line 220
    iget-object p2, p2, LC/Z;->a:LC/V;

    .line 221
    .line 222
    invoke-virtual {p2}, LC/V;->h()Lv/b;

    .line 223
    .line 224
    .line 225
    move-result-object v1

    .line 226
    :cond_e1
    iget p2, p1, Lv/b;->d:I

    .line 227
    .line 228
    if-eqz v1, :cond_eb

    .line 229
    .line 230
    iget v0, v1, Lv/b;->d:I

    .line 231
    .line 232
    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    .line 233
    .line 234
    .line 235
    move-result p2

    .line 236
    :cond_eb
    iget v0, p1, Lv/b;->a:I

    .line 237
    .line 238
    iget p1, p1, Lv/b;->c:I

    .line 239
    .line 240
    invoke-static {v0, v2, p1, p2}, Lv/b;->b(IIII)Lv/b;

    .line 241
    .line 242
    .line 243
    move-result-object p1

    .line 244
    return-object p1

    .line 245
    :cond_f4
    if-eqz p2, :cond_10b

    .line 246
    .line 247
    invoke-direct {p0}, LC/N;->v()Lv/b;

    .line 248
    .line 249
    .line 250
    move-result-object p1

    .line 251
    iget p1, p1, Lv/b;->b:I

    .line 252
    .line 253
    invoke-virtual {p0}, LC/N;->j()Lv/b;

    .line 254
    .line 255
    .line 256
    move-result-object p2

    .line 257
    iget p2, p2, Lv/b;->b:I

    .line 258
    .line 259
    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    .line 260
    .line 261
    .line 262
    move-result p1

    .line 263
    invoke-static {v2, p1, v2, v2}, Lv/b;->b(IIII)Lv/b;

    .line 264
    .line 265
    .line 266
    move-result-object p1

    .line 267
    return-object p1

    .line 268
    :cond_10b
    iget p1, p0, LC/N;->h:I

    .line 269
    .line 270
    and-int/lit8 p1, p1, 0x4

    .line 271
    .line 272
    if-eqz p1, :cond_112

    .line 273
    .line 274
    :cond_111
    :goto_111
    return-object v0

    .line 275
    :cond_112
    invoke-virtual {p0}, LC/N;->j()Lv/b;

    .line 276
    .line 277
    .line 278
    move-result-object p1

    .line 279
    iget p1, p1, Lv/b;->b:I

    .line 280
    .line 281
    invoke-static {v2, p1, v2, v2}, Lv/b;->b(IIII)Lv/b;

    .line 282
    .line 283
    .line 284
    move-result-object p1

    .line 285
    return-object p1
.end method

.method public x(I)Z
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    if-eq p1, v1, :cond_14

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    if-eq p1, v2, :cond_14

    .line 7
    .line 8
    const/4 v2, 0x4

    .line 9
    if-eq p1, v2, :cond_13

    .line 10
    .line 11
    const/16 v2, 0x8

    .line 12
    .line 13
    if-eq p1, v2, :cond_14

    .line 14
    .line 15
    const/16 v2, 0x80

    .line 16
    .line 17
    if-eq p1, v2, :cond_14

    .line 18
    .line 19
    return v1

    .line 20
    :cond_13
    return v0

    .line 21
    :cond_14
    invoke-virtual {p0, p1, v0}, LC/N;->u(IZ)Lv/b;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    sget-object v0, Lv/b;->e:Lv/b;

    .line 26
    .line 27
    invoke-virtual {p1, v0}, Lv/b;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    xor-int/2addr p1, v1

    .line 32
    return p1
.end method

.method public z(Lv/b;)V
    .registers 2

    .line 1
    iput-object p1, p0, LC/N;->g:Lv/b;

    .line 2
    .line 3
    return-void
.end method
