###### Class C.InterfaceC0008i (C.i)
.class public interface abstract LC/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC/h;


# virtual methods
.method public abstract e(Landroid/view/ViewGroup;IIIII[I)V
.end method
