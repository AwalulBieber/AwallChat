###### Class C.InterfaceC0010k (C.k)
.class public interface abstract LC/k;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f(LC/Z;)LC/Z;
.end method
