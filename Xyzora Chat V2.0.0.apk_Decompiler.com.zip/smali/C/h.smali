###### Class C.InterfaceC0007h (C.h)
.class public interface abstract LC/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/view/View;Landroid/view/View;II)V
.end method

.method public abstract b(Landroid/view/ViewGroup;IIIII)V
.end method

.method public abstract c(Landroid/view/View;I)V
.end method

.method public abstract d(II[II)V
.end method

.method public abstract f(Landroid/view/View;Landroid/view/View;II)Z
.end method
