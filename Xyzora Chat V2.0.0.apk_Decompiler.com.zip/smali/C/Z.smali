###### Class C.Z (C.Z)
.class public final LC/Z;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:LC/Z;


# instance fields
.field public final a:LC/V;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x22

    .line 4
    .line 5
    if-lt v0, v1, :cond_b

    .line 6
    .line 7
    sget-object v0, LC/U;->s:LC/Z;

    .line 8
    .line 9
    sput-object v0, LC/Z;->b:LC/Z;

    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    const/16 v1, 0x1e

    .line 13
    .line 14
    if-lt v0, v1, :cond_14

    .line 15
    .line 16
    sget-object v0, LC/S;->r:LC/Z;

    .line 17
    .line 18
    sput-object v0, LC/Z;->b:LC/Z;

    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    sget-object v0, LC/V;->b:LC/Z;

    .line 22
    .line 23
    sput-object v0, LC/Z;->b:LC/Z;

    .line 24
    .line 25
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    new-instance v0, LC/V;

    invoke-direct {v0, p0}, LC/V;-><init>(LC/Z;)V

    iput-object v0, p0, LC/Z;->a:LC/V;

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsets;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_11

    .line 3
    new-instance v0, LC/U;

    invoke-direct {v0, p0, p1}, LC/U;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LC/Z;->a:LC/V;

    return-void

    :cond_11
    const/16 v1, 0x1f

    if-lt v0, v1, :cond_1d

    .line 4
    new-instance v0, LC/T;

    invoke-direct {v0, p0, p1}, LC/T;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LC/Z;->a:LC/V;

    return-void

    :cond_1d
    const/16 v1, 0x1e

    if-lt v0, v1, :cond_29

    .line 5
    new-instance v0, LC/S;

    invoke-direct {v0, p0, p1}, LC/S;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LC/Z;->a:LC/V;

    return-void

    :cond_29
    const/16 v1, 0x1d

    if-lt v0, v1, :cond_35

    .line 6
    new-instance v0, LC/Q;

    invoke-direct {v0, p0, p1}, LC/Q;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LC/Z;->a:LC/V;

    return-void

    :cond_35
    const/16 v1, 0x1c

    if-lt v0, v1, :cond_41

    .line 7
    new-instance v0, LC/P;

    invoke-direct {v0, p0, p1}, LC/P;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LC/Z;->a:LC/V;

    return-void

    .line 8
    :cond_41
    new-instance v0, LC/O;

    invoke-direct {v0, p0, p1}, LC/O;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    iput-object v0, p0, LC/Z;->a:LC/V;

    return-void
.end method

.method public static a(Lv/b;IIII)Lv/b;
    .registers 10

    .line 1
    iget v0, p0, Lv/b;->a:I

    .line 2
    .line 3
    sub-int/2addr v0, p1

    .line 4
    const/4 v1, 0x0

    .line 5
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iget v2, p0, Lv/b;->b:I

    .line 10
    .line 11
    sub-int/2addr v2, p2

    .line 12
    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    iget v3, p0, Lv/b;->c:I

    .line 17
    .line 18
    sub-int/2addr v3, p3

    .line 19
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    iget v4, p0, Lv/b;->d:I

    .line 24
    .line 25
    sub-int/2addr v4, p4

    .line 26
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-ne v0, p1, :cond_26

    .line 31
    .line 32
    if-ne v2, p2, :cond_26

    .line 33
    .line 34
    if-ne v3, p3, :cond_26

    .line 35
    .line 36
    if-ne v1, p4, :cond_26

    .line 37
    .line 38
    return-object p0

    .line 39
    :cond_26
    invoke-static {v0, v2, v3, v1}, Lv/b;->b(IIII)Lv/b;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method

.method public static c(Landroid/view/WindowInsets;Landroid/view/View;)LC/Z;
    .registers 4

    .line 1
    new-instance v0, LC/Z;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-direct {v0, p0}, LC/Z;-><init>(Landroid/view/WindowInsets;)V

    .line 7
    .line 8
    .line 9
    if-eqz p1, :cond_29

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/View;->isAttachedToWindow()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-eqz p0, :cond_29

    .line 16
    .line 17
    sget-object p0, LC/C;->a:Ljava/lang/reflect/Field;

    .line 18
    .line 19
    invoke-static {p1}, LC/x;->a(Landroid/view/View;)LC/Z;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    iget-object v1, v0, LC/Z;->a:LC/V;

    .line 24
    .line 25
    invoke-virtual {v1, p0}, LC/V;->q(LC/Z;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p1}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-virtual {v1, p0}, LC/V;->d(Landroid/view/View;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p1}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    invoke-virtual {v1, p0}, LC/V;->s(I)V

    .line 40
    .line 41
    .line 42
    :cond_29
    return-object v0
.end method


# virtual methods
.method public final b()Landroid/view/WindowInsets;
    .registers 3

    .line 1
    iget-object v0, p0, LC/Z;->a:LC/V;

    .line 2
    .line 3
    instance-of v1, v0, LC/N;

    .line 4
    .line 5
    if-eqz v1, :cond_b

    .line 6
    .line 7
    check-cast v0, LC/N;

    .line 8
    .line 9
    iget-object v0, v0, LC/N;->c:Landroid/view/WindowInsets;

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    if-ne p0, p1, :cond_4

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    return p1

    .line 5
    :cond_4
    instance-of v0, p1, LC/Z;

    .line 6
    .line 7
    if-nez v0, :cond_a

    .line 8
    .line 9
    const/4 p1, 0x0

    .line 10
    return p1

    .line 11
    :cond_a
    check-cast p1, LC/Z;

    .line 12
    .line 13
    iget-object p1, p1, LC/Z;->a:LC/V;

    .line 14
    .line 15
    iget-object v0, p0, LC/Z;->a:LC/V;

    .line 16
    .line 17
    invoke-static {v0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    return p1
.end method

.method public final hashCode()I
    .registers 2

    .line 1
    iget-object v0, p0, LC/Z;->a:LC/V;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    return v0

    .line 7
    :cond_6
    invoke-virtual {v0}, LC/V;->hashCode()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    return v0
.end method
