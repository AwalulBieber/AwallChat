###### Class C.C0006g (C.g)
.class public final LC/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/view/ViewParent;

.field public b:Landroid/view/ViewParent;

.field public final c:Landroid/view/ViewGroup;

.field public d:Z

.field public e:[I


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LC/g;->c:Landroid/view/ViewGroup;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(FFZ)Z
    .registers 7

    .line 1
    iget-boolean v0, p0, LC/g;->d:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2b

    .line 5
    .line 6
    invoke-virtual {p0, v1}, LC/g;->e(I)Landroid/view/ViewParent;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_2b

    .line 11
    .line 12
    iget-object v2, p0, LC/g;->c:Landroid/view/ViewGroup;

    .line 13
    .line 14
    :try_start_d
    invoke-interface {v0, v2, p1, p2, p3}, Landroid/view/ViewParent;->onNestedFling(Landroid/view/View;FFZ)Z

    .line 15
    .line 16
    .line 17
    move-result p1
    :try_end_11
    .catch Ljava/lang/AbstractMethodError; {:try_start_d .. :try_end_11} :catch_12

    .line 18
    return p1

    .line 19
    :catch_12
    move-exception p1

    .line 20
    new-instance p2, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string p3, "ViewParent "

    .line 23
    .line 24
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-string p3, " does not implement interface method onNestedFling"

    .line 31
    .line 32
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    const-string p3, "ViewParentCompat"

    .line 40
    .line 41
    invoke-static {p3, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 42
    .line 43
    .line 44
    :cond_2b
    return v1
.end method

.method public final b(FF)Z
    .registers 6

    .line 1
    iget-boolean v0, p0, LC/g;->d:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2b

    .line 5
    .line 6
    invoke-virtual {p0, v1}, LC/g;->e(I)Landroid/view/ViewParent;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_2b

    .line 11
    .line 12
    iget-object v2, p0, LC/g;->c:Landroid/view/ViewGroup;

    .line 13
    .line 14
    :try_start_d
    invoke-interface {v0, v2, p1, p2}, Landroid/view/ViewParent;->onNestedPreFling(Landroid/view/View;FF)Z

    .line 15
    .line 16
    .line 17
    move-result p1
    :try_end_11
    .catch Ljava/lang/AbstractMethodError; {:try_start_d .. :try_end_11} :catch_12

    .line 18
    return p1

    .line 19
    :catch_12
    move-exception p1

    .line 20
    new-instance p2, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string v2, "ViewParent "

    .line 23
    .line 24
    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-string v0, " does not implement interface method onNestedPreFling"

    .line 31
    .line 32
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    const-string v0, "ViewParentCompat"

    .line 40
    .line 41
    invoke-static {v0, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 42
    .line 43
    .line 44
    :cond_2b
    return v1
.end method

.method public final c(III[I[I)Z
    .registers 13

    .line 1
    iget-boolean v0, p0, LC/g;->d:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_7a

    .line 5
    .line 6
    invoke-virtual {p0, p3}, LC/g;->e(I)Landroid/view/ViewParent;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-nez v0, :cond_d

    .line 11
    .line 12
    goto/16 :goto_7a

    .line 13
    .line 14
    :cond_d
    const/4 v2, 0x1

    .line 15
    if-nez p1, :cond_1a

    .line 16
    .line 17
    if-eqz p2, :cond_13

    .line 18
    .line 19
    goto :goto_1a

    .line 20
    :cond_13
    if-eqz p5, :cond_7a

    .line 21
    .line 22
    aput v1, p5, v1

    .line 23
    .line 24
    aput v1, p5, v2

    .line 25
    .line 26
    return v1

    .line 27
    :cond_1a
    :goto_1a
    iget-object v3, p0, LC/g;->c:Landroid/view/ViewGroup;

    .line 28
    .line 29
    if-eqz p5, :cond_26

    .line 30
    .line 31
    invoke-virtual {v3, p5}, Landroid/view/View;->getLocationInWindow([I)V

    .line 32
    .line 33
    .line 34
    aget v4, p5, v1

    .line 35
    .line 36
    aget v5, p5, v2

    .line 37
    .line 38
    goto :goto_28

    .line 39
    :cond_26
    move v4, v1

    .line 40
    move v5, v4

    .line 41
    :goto_28
    if-nez p4, :cond_35

    .line 42
    .line 43
    iget-object p4, p0, LC/g;->e:[I

    .line 44
    .line 45
    if-nez p4, :cond_33

    .line 46
    .line 47
    const/4 p4, 0x2

    .line 48
    new-array p4, p4, [I

    .line 49
    .line 50
    iput-object p4, p0, LC/g;->e:[I

    .line 51
    .line 52
    :cond_33
    iget-object p4, p0, LC/g;->e:[I

    .line 53
    .line 54
    :cond_35
    aput v1, p4, v1

    .line 55
    .line 56
    aput v1, p4, v2

    .line 57
    .line 58
    instance-of v6, v0, LC/h;

    .line 59
    .line 60
    if-eqz v6, :cond_43

    .line 61
    .line 62
    check-cast v0, LC/h;

    .line 63
    .line 64
    invoke-interface {v0, p1, p2, p4, p3}, LC/h;->d(II[II)V

    .line 65
    .line 66
    .line 67
    goto :goto_62

    .line 68
    :cond_43
    if-nez p3, :cond_62

    .line 69
    .line 70
    :try_start_45
    invoke-interface {v0, v3, p1, p2, p4}, Landroid/view/ViewParent;->onNestedPreScroll(Landroid/view/View;II[I)V
    :try_end_48
    .catch Ljava/lang/AbstractMethodError; {:try_start_45 .. :try_end_48} :catch_49

    .line 71
    .line 72
    .line 73
    goto :goto_62

    .line 74
    :catch_49
    move-exception p1

    .line 75
    new-instance p2, Ljava/lang/StringBuilder;

    .line 76
    .line 77
    const-string p3, "ViewParent "

    .line 78
    .line 79
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    const-string p3, " does not implement interface method onNestedPreScroll"

    .line 86
    .line 87
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    const-string p3, "ViewParentCompat"

    .line 95
    .line 96
    invoke-static {p3, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 97
    .line 98
    .line 99
    :cond_62
    :goto_62
    if-eqz p5, :cond_71

    .line 100
    .line 101
    invoke-virtual {v3, p5}, Landroid/view/View;->getLocationInWindow([I)V

    .line 102
    .line 103
    .line 104
    aget p1, p5, v1

    .line 105
    .line 106
    sub-int/2addr p1, v4

    .line 107
    aput p1, p5, v1

    .line 108
    .line 109
    aget p1, p5, v2

    .line 110
    .line 111
    sub-int/2addr p1, v5

    .line 112
    aput p1, p5, v2

    .line 113
    .line 114
    :cond_71
    aget p1, p4, v1

    .line 115
    .line 116
    if-nez p1, :cond_79

    .line 117
    .line 118
    aget p1, p4, v2

    .line 119
    .line 120
    if-eqz p1, :cond_7a

    .line 121
    .line 122
    :cond_79
    move v1, v2

    .line 123
    :cond_7a
    :goto_7a
    return v1
.end method

.method public final d(IIII[II[I)Z
    .registers 22

    .line 1
    move-object/from16 v1, p5

    .line 2
    .line 3
    move/from16 v8, p6

    .line 4
    .line 5
    iget-boolean v0, p0, LC/g;->d:Z

    .line 6
    .line 7
    const/4 v10, 0x0

    .line 8
    if-eqz v0, :cond_ae

    .line 9
    .line 10
    invoke-virtual {p0, v8}, LC/g;->e(I)Landroid/view/ViewParent;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    if-nez v2, :cond_11

    .line 15
    .line 16
    goto/16 :goto_ae

    .line 17
    .line 18
    :cond_11
    const/4 v11, 0x1

    .line 19
    if-nez p1, :cond_22

    .line 20
    .line 21
    if-nez p2, :cond_22

    .line 22
    .line 23
    if-nez p3, :cond_22

    .line 24
    .line 25
    if-eqz p4, :cond_1b

    .line 26
    .line 27
    goto :goto_22

    .line 28
    :cond_1b
    if-eqz v1, :cond_ae

    .line 29
    .line 30
    aput v10, v1, v10

    .line 31
    .line 32
    aput v10, v1, v11

    .line 33
    .line 34
    return v10

    .line 35
    :cond_22
    :goto_22
    iget-object v3, p0, LC/g;->c:Landroid/view/ViewGroup;

    .line 36
    .line 37
    if-eqz v1, :cond_30

    .line 38
    .line 39
    invoke-virtual {v3, v1}, Landroid/view/View;->getLocationInWindow([I)V

    .line 40
    .line 41
    .line 42
    aget v0, v1, v10

    .line 43
    .line 44
    aget v4, v1, v11

    .line 45
    .line 46
    move v12, v0

    .line 47
    move v13, v4

    .line 48
    goto :goto_32

    .line 49
    :cond_30
    move v12, v10

    .line 50
    move v13, v12

    .line 51
    :goto_32
    if-nez p7, :cond_45

    .line 52
    .line 53
    iget-object v0, p0, LC/g;->e:[I

    .line 54
    .line 55
    if-nez v0, :cond_3d

    .line 56
    .line 57
    const/4 v0, 0x2

    .line 58
    new-array v0, v0, [I

    .line 59
    .line 60
    iput-object v0, p0, LC/g;->e:[I

    .line 61
    .line 62
    :cond_3d
    iget-object v0, p0, LC/g;->e:[I

    .line 63
    .line 64
    aput v10, v0, v10

    .line 65
    .line 66
    aput v10, v0, v11

    .line 67
    .line 68
    move-object v9, v0

    .line 69
    goto :goto_47

    .line 70
    :cond_45
    move-object/from16 v9, p7

    .line 71
    .line 72
    :goto_47
    instance-of v0, v2, LC/i;

    .line 73
    .line 74
    if-eqz v0, :cond_58

    .line 75
    .line 76
    check-cast v2, LC/i;

    .line 77
    .line 78
    move v4, p1

    .line 79
    move/from16 v5, p2

    .line 80
    .line 81
    move/from16 v6, p3

    .line 82
    .line 83
    move/from16 v7, p4

    .line 84
    .line 85
    invoke-interface/range {v2 .. v9}, LC/i;->e(Landroid/view/ViewGroup;IIIII[I)V

    .line 86
    .line 87
    .line 88
    goto :goto_9e

    .line 89
    :cond_58
    aget v0, v9, v10

    .line 90
    .line 91
    add-int v0, v0, p3

    .line 92
    .line 93
    aput v0, v9, v10

    .line 94
    .line 95
    aget v0, v9, v11

    .line 96
    .line 97
    add-int v0, v0, p4

    .line 98
    .line 99
    aput v0, v9, v11

    .line 100
    .line 101
    instance-of v0, v2, LC/h;

    .line 102
    .line 103
    if-eqz v0, :cond_77

    .line 104
    .line 105
    check-cast v2, LC/h;

    .line 106
    .line 107
    move v4, p1

    .line 108
    move/from16 v5, p2

    .line 109
    .line 110
    move/from16 v6, p3

    .line 111
    .line 112
    move/from16 v7, p4

    .line 113
    .line 114
    move/from16 v8, p6

    .line 115
    .line 116
    invoke-interface/range {v2 .. v8}, LC/h;->b(Landroid/view/ViewGroup;IIIII)V

    .line 117
    .line 118
    .line 119
    goto :goto_9e

    .line 120
    :cond_77
    if-nez p6, :cond_9e

    .line 121
    .line 122
    move v4, p1

    .line 123
    move/from16 v5, p2

    .line 124
    .line 125
    move/from16 v6, p3

    .line 126
    .line 127
    move/from16 v7, p4

    .line 128
    .line 129
    :try_start_80
    invoke-interface/range {v2 .. v7}, Landroid/view/ViewParent;->onNestedScroll(Landroid/view/View;IIII)V
    :try_end_83
    .catch Ljava/lang/AbstractMethodError; {:try_start_80 .. :try_end_83} :catch_84

    .line 130
    .line 131
    .line 132
    goto :goto_9e

    .line 133
    :catch_84
    move-exception v0

    .line 134
    move-object p1, v0

    .line 135
    new-instance v0, Ljava/lang/StringBuilder;

    .line 136
    .line 137
    const-string v4, "ViewParent "

    .line 138
    .line 139
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    const-string v2, " does not implement interface method onNestedScroll"

    .line 146
    .line 147
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 148
    .line 149
    .line 150
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    const-string v2, "ViewParentCompat"

    .line 155
    .line 156
    invoke-static {v2, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 157
    .line 158
    .line 159
    :cond_9e
    :goto_9e
    if-eqz v1, :cond_ad

    .line 160
    .line 161
    invoke-virtual {v3, v1}, Landroid/view/View;->getLocationInWindow([I)V

    .line 162
    .line 163
    .line 164
    aget p1, v1, v10

    .line 165
    .line 166
    sub-int/2addr p1, v12

    .line 167
    aput p1, v1, v10

    .line 168
    .line 169
    aget p1, v1, v11

    .line 170
    .line 171
    sub-int/2addr p1, v13

    .line 172
    aput p1, v1, v11

    .line 173
    .line 174
    :cond_ad
    return v11

    .line 175
    :cond_ae
    :goto_ae
    return v10
.end method

.method public final e(I)Landroid/view/ViewParent;
    .registers 3

    .line 1
    if-eqz p1, :cond_a

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p1, v0, :cond_7

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    return-object p1

    .line 8
    :cond_7
    iget-object p1, p0, LC/g;->b:Landroid/view/ViewParent;

    .line 9
    .line 10
    return-object p1

    .line 11
    :cond_a
    iget-object p1, p0, LC/g;->a:Landroid/view/ViewParent;

    .line 12
    .line 13
    return-object p1
.end method

.method public final f(I)Z
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, LC/g;->e(I)Landroid/view/ViewParent;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    if-eqz p1, :cond_8

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    return p1

    .line 9
    :cond_8
    const/4 p1, 0x0

    .line 10
    return p1
.end method

.method public final g(II)Z
    .registers 14

    .line 1
    invoke-virtual {p0, p2}, LC/g;->f(I)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eqz v0, :cond_9

    .line 7
    .line 8
    goto/16 :goto_73

    .line 9
    .line 10
    :cond_9
    iget-boolean v0, p0, LC/g;->d:Z

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    if-eqz v0, :cond_80

    .line 14
    .line 15
    iget-object v0, p0, LC/g;->c:Landroid/view/ViewGroup;

    .line 16
    .line 17
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    move-object v4, v0

    .line 22
    :goto_15
    if-eqz v3, :cond_80

    .line 23
    .line 24
    instance-of v5, v3, LC/h;

    .line 25
    .line 26
    const-string v6, "ViewParentCompat"

    .line 27
    .line 28
    const-string v7, "ViewParent "

    .line 29
    .line 30
    if-eqz v5, :cond_27

    .line 31
    .line 32
    move-object v8, v3

    .line 33
    check-cast v8, LC/h;

    .line 34
    .line 35
    invoke-interface {v8, v4, v0, p1, p2}, LC/h;->f(Landroid/view/View;Landroid/view/View;II)Z

    .line 36
    .line 37
    .line 38
    move-result v8

    .line 39
    goto :goto_44

    .line 40
    :cond_27
    if-nez p2, :cond_43

    .line 41
    .line 42
    :try_start_29
    invoke-interface {v3, v4, v0, p1}, Landroid/view/ViewParent;->onStartNestedScroll(Landroid/view/View;Landroid/view/View;I)Z

    .line 43
    .line 44
    .line 45
    move-result v8
    :try_end_2d
    .catch Ljava/lang/AbstractMethodError; {:try_start_29 .. :try_end_2d} :catch_2e

    .line 46
    goto :goto_44

    .line 47
    :catch_2e
    move-exception v8

    .line 48
    new-instance v9, Ljava/lang/StringBuilder;

    .line 49
    .line 50
    invoke-direct {v9, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    const-string v10, " does not implement interface method onStartNestedScroll"

    .line 57
    .line 58
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v9

    .line 65
    invoke-static {v6, v9, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 66
    .line 67
    .line 68
    :cond_43
    move v8, v2

    .line 69
    :goto_44
    if-eqz v8, :cond_74

    .line 70
    .line 71
    if-eqz p2, :cond_4e

    .line 72
    .line 73
    if-eq p2, v1, :cond_4b

    .line 74
    .line 75
    goto :goto_50

    .line 76
    :cond_4b
    iput-object v3, p0, LC/g;->b:Landroid/view/ViewParent;

    .line 77
    .line 78
    goto :goto_50

    .line 79
    :cond_4e
    iput-object v3, p0, LC/g;->a:Landroid/view/ViewParent;

    .line 80
    .line 81
    :goto_50
    if-eqz v5, :cond_58

    .line 82
    .line 83
    check-cast v3, LC/h;

    .line 84
    .line 85
    invoke-interface {v3, v4, v0, p1, p2}, LC/h;->a(Landroid/view/View;Landroid/view/View;II)V

    .line 86
    .line 87
    .line 88
    goto :goto_73

    .line 89
    :cond_58
    if-nez p2, :cond_73

    .line 90
    .line 91
    :try_start_5a
    invoke-interface {v3, v4, v0, p1}, Landroid/view/ViewParent;->onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;I)V
    :try_end_5d
    .catch Ljava/lang/AbstractMethodError; {:try_start_5a .. :try_end_5d} :catch_5e

    .line 92
    .line 93
    .line 94
    goto :goto_73

    .line 95
    :catch_5e
    move-exception p1

    .line 96
    new-instance p2, Ljava/lang/StringBuilder;

    .line 97
    .line 98
    invoke-direct {p2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    const-string v0, " does not implement interface method onNestedScrollAccepted"

    .line 105
    .line 106
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p2

    .line 113
    invoke-static {v6, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 114
    .line 115
    .line 116
    :cond_73
    :goto_73
    return v1

    .line 117
    :cond_74
    instance-of v5, v3, Landroid/view/View;

    .line 118
    .line 119
    if-eqz v5, :cond_7b

    .line 120
    .line 121
    move-object v4, v3

    .line 122
    check-cast v4, Landroid/view/View;

    .line 123
    .line 124
    :cond_7b
    invoke-interface {v3}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    .line 125
    .line 126
    .line 127
    move-result-object v3

    .line 128
    goto :goto_15

    .line 129
    :cond_80
    return v2
.end method

.method public final h(I)V
    .registers 6

    .line 1
    invoke-virtual {p0, p1}, LC/g;->e(I)Landroid/view/ViewParent;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_3d

    .line 6
    .line 7
    instance-of v1, v0, LC/h;

    .line 8
    .line 9
    iget-object v2, p0, LC/g;->c:Landroid/view/ViewGroup;

    .line 10
    .line 11
    if-eqz v1, :cond_12

    .line 12
    .line 13
    check-cast v0, LC/h;

    .line 14
    .line 15
    invoke-interface {v0, v2, p1}, LC/h;->c(Landroid/view/View;I)V

    .line 16
    .line 17
    .line 18
    goto :goto_31

    .line 19
    :cond_12
    if-nez p1, :cond_31

    .line 20
    .line 21
    :try_start_14
    invoke-interface {v0, v2}, Landroid/view/ViewParent;->onStopNestedScroll(Landroid/view/View;)V
    :try_end_17
    .catch Ljava/lang/AbstractMethodError; {:try_start_14 .. :try_end_17} :catch_18

    .line 22
    .line 23
    .line 24
    goto :goto_31

    .line 25
    :catch_18
    move-exception v1

    .line 26
    new-instance v2, Ljava/lang/StringBuilder;

    .line 27
    .line 28
    const-string v3, "ViewParent "

    .line 29
    .line 30
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    const-string v0, " does not implement interface method onStopNestedScroll"

    .line 37
    .line 38
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    const-string v2, "ViewParentCompat"

    .line 46
    .line 47
    invoke-static {v2, v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 48
    .line 49
    .line 50
    :cond_31
    :goto_31
    const/4 v0, 0x0

    .line 51
    if-eqz p1, :cond_3b

    .line 52
    .line 53
    const/4 v1, 0x1

    .line 54
    if-eq p1, v1, :cond_38

    .line 55
    .line 56
    goto :goto_3d

    .line 57
    :cond_38
    iput-object v0, p0, LC/g;->b:Landroid/view/ViewParent;

    .line 58
    .line 59
    goto :goto_3d

    .line 60
    :cond_3b
    iput-object v0, p0, LC/g;->a:Landroid/view/ViewParent;

    .line 61
    .line 62
    :cond_3d
    :goto_3d
    return-void
.end method
