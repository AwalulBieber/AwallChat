###### Class C.U (C.U)
.class public final LC/U;
.super LC/T;
.source "SourceFile"


# static fields
.field public static final s:LC/Z;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    invoke-static {}, LC/I;->f()Landroid/view/WindowInsets;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {v0, v1}, LC/Z;->c(Landroid/view/WindowInsets;Landroid/view/View;)LC/Z;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, LC/U;->s:LC/Z;

    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>(LC/Z;Landroid/view/WindowInsets;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, LC/T;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public f(I)Lv/b;
    .registers 3

    .line 1
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-static {p1}, LC/Y;->a(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-static {v0, p1}, LC/I;->e(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-static {p1}, Lv/b;->c(Landroid/graphics/Insets;)Lv/b;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1
.end method

.method public o(I)Z
    .registers 3

    .line 1
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-static {p1}, LC/Y;->a(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-static {v0, p1}, LC/I;->q(Landroid/view/WindowInsets;I)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1
.end method
