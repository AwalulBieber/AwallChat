###### Class C.H (C.H)
.class public LC/H;
.super LC/M;
.source "SourceFile"


# instance fields
.field public final c:Landroid/view/WindowInsets$Builder;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, LC/M;-><init>()V

    .line 2
    invoke-static {}, LC/G;->f()Landroid/view/WindowInsets$Builder;

    move-result-object v0

    iput-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    return-void
.end method

.method public constructor <init>(LC/Z;)V
    .registers 2

    .line 3
    invoke-direct {p0, p1}, LC/M;-><init>(LC/Z;)V

    .line 4
    invoke-virtual {p1}, LC/Z;->b()Landroid/view/WindowInsets;

    move-result-object p1

    if-eqz p1, :cond_e

    .line 5
    invoke-static {p1}, LC/G;->g(Landroid/view/WindowInsets;)Landroid/view/WindowInsets$Builder;

    move-result-object p1

    goto :goto_12

    .line 6
    :cond_e
    invoke-static {}, LC/G;->f()Landroid/view/WindowInsets$Builder;

    move-result-object p1

    :goto_12
    iput-object p1, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    return-void
.end method


# virtual methods
.method public b()LC/Z;
    .registers 4

    .line 1
    invoke-virtual {p0}, LC/M;->a()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    .line 5
    .line 6
    invoke-static {v0}, LC/G;->h(Landroid/view/WindowInsets$Builder;)Landroid/view/WindowInsets;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-static {v0, v1}, LC/Z;->c(Landroid/view/WindowInsets;Landroid/view/View;)LC/Z;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget-object v1, p0, LC/M;->b:[Lv/b;

    .line 16
    .line 17
    iget-object v2, v0, LC/Z;->a:LC/V;

    .line 18
    .line 19
    invoke-virtual {v2, v1}, LC/V;->p([Lv/b;)V

    .line 20
    .line 21
    .line 22
    return-object v0
.end method

.method public d(Lv/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, Lv/b;->d()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LC/G;->B(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public e(Lv/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, Lv/b;->d()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LC/G;->v(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public f(Lv/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, Lv/b;->d()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LC/G;->z(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public g(Lv/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, Lv/b;->d()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LC/G;->o(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public h(Lv/b;)V
    .registers 3

    .line 1
    iget-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, Lv/b;->d()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LC/G;->C(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
