###### Class C.Q (C.Q)
.class public LC/Q;
.super LC/P;
.source "SourceFile"


# instance fields
.field public o:Lv/b;

.field public p:Lv/b;

.field public q:Lv/b;


# direct methods
.method public constructor <init>(LC/Z;Landroid/view/WindowInsets;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, LC/P;-><init>(LC/Z;Landroid/view/WindowInsets;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, LC/Q;->o:Lv/b;

    .line 6
    .line 7
    iput-object p1, p0, LC/Q;->p:Lv/b;

    .line 8
    .line 9
    iput-object p1, p0, LC/Q;->q:Lv/b;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public g()Lv/b;
    .registers 2

    .line 1
    iget-object v0, p0, LC/Q;->p:Lv/b;

    .line 2
    .line 3
    if-nez v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-static {v0}, LC/G;->q(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lv/b;->c(Landroid/graphics/Insets;)Lv/b;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, LC/Q;->p:Lv/b;

    .line 16
    .line 17
    :cond_10
    iget-object v0, p0, LC/Q;->p:Lv/b;

    .line 18
    .line 19
    return-object v0
.end method

.method public i()Lv/b;
    .registers 2

    .line 1
    iget-object v0, p0, LC/Q;->o:Lv/b;

    .line 2
    .line 3
    if-nez v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-static {v0}, LC/G;->w(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lv/b;->c(Landroid/graphics/Insets;)Lv/b;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, LC/Q;->o:Lv/b;

    .line 16
    .line 17
    :cond_10
    iget-object v0, p0, LC/Q;->o:Lv/b;

    .line 18
    .line 19
    return-object v0
.end method

.method public k()Lv/b;
    .registers 2

    .line 1
    iget-object v0, p0, LC/Q;->q:Lv/b;

    .line 2
    .line 3
    if-nez v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-static {v0}, LC/G;->c(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lv/b;->c(Landroid/graphics/Insets;)Lv/b;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, LC/Q;->q:Lv/b;

    .line 16
    .line 17
    :cond_10
    iget-object v0, p0, LC/Q;->q:Lv/b;

    .line 18
    .line 19
    return-object v0
.end method

.method public l(IIII)LC/Z;
    .registers 6

    .line 1
    iget-object v0, p0, LC/N;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-static {v0, p1, p2, p3, p4}, LC/G;->i(Landroid/view/WindowInsets;IIII)Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    const/4 p2, 0x0

    .line 8
    invoke-static {p1, p2}, LC/Z;->c(Landroid/view/WindowInsets;Landroid/view/View;)LC/Z;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

.method public r(Lv/b;)V
    .registers 2

    .line 1
    return-void
.end method
