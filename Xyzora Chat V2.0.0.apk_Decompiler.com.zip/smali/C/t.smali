###### Class C.AbstractC0018t (C.t)
.class public abstract LC/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, LJ0/g;->g:LJ0/g;

    .line 5
    .line 6
    if-nez v0, :cond_10

    .line 7
    .line 8
    new-instance v0, LJ0/g;

    .line 9
    .line 10
    const/16 v1, 0x8

    .line 11
    .line 12
    invoke-direct {v0, v1}, LJ0/g;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, LJ0/g;->g:LJ0/g;

    .line 16
    .line 17
    :cond_10
    return-void
.end method


# virtual methods
.method public a(I)I
    .registers 4

    .line 1
    iget v0, p0, LC/t;->c:I

    .line 2
    .line 3
    if-ge p1, v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, LC/t;->d:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Ljava/nio/ByteBuffer;

    .line 8
    .line 9
    iget v1, p0, LC/t;->b:I

    .line 10
    .line 11
    add-int/2addr v1, p1

    .line 12
    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->getShort(I)S

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    return p1

    .line 17
    :cond_10
    const/4 p1, 0x0

    .line 18
    return p1
.end method

.method public abstract b(Landroid/view/View;)Ljava/lang/Object;
.end method

.method public abstract c(Landroid/view/View;Ljava/lang/CharSequence;)V
.end method

.method public d(Landroid/view/View;Ljava/lang/CharSequence;)V
    .registers 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    iget v1, p0, LC/t;->b:I

    .line 4
    .line 5
    if-lt v0, v1, :cond_a

    .line 6
    .line 7
    invoke-virtual {p0, p1, p2}, LC/t;->c(Landroid/view/View;Ljava/lang/CharSequence;)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    .line 13
    iget v1, p0, LC/t;->b:I

    .line 14
    .line 15
    if-lt v0, v1, :cond_15

    .line 16
    .line 17
    invoke-virtual {p0, p1}, LC/t;->b(Landroid/view/View;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    goto :goto_27

    .line 22
    :cond_15
    iget v0, p0, LC/t;->a:I

    .line 23
    .line 24
    invoke-virtual {p1, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iget-object v1, p0, LC/t;->d:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v1, Ljava/lang/Class;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_26

    .line 37
    .line 38
    goto :goto_27

    .line 39
    :cond_26
    const/4 v0, 0x0

    .line 40
    :goto_27
    invoke-virtual {p0, v0, p2}, LC/t;->e(Ljava/lang/Object;Ljava/lang/CharSequence;)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_58

    .line 45
    .line 46
    invoke-static {p1}, LC/C;->a(Landroid/view/View;)Landroid/view/View$AccessibilityDelegate;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    if-nez v0, :cond_35

    .line 51
    .line 52
    const/4 v0, 0x0

    .line 53
    goto :goto_44

    .line 54
    :cond_35
    instance-of v1, v0, LC/a;

    .line 55
    .line 56
    if-eqz v1, :cond_3e

    .line 57
    .line 58
    check-cast v0, LC/a;

    .line 59
    .line 60
    iget-object v0, v0, LC/a;->a:LC/b;

    .line 61
    .line 62
    goto :goto_44

    .line 63
    :cond_3e
    new-instance v1, LC/b;

    .line 64
    .line 65
    invoke-direct {v1, v0}, LC/b;-><init>(Landroid/view/View$AccessibilityDelegate;)V

    .line 66
    .line 67
    .line 68
    move-object v0, v1

    .line 69
    :goto_44
    if-nez v0, :cond_4b

    .line 70
    .line 71
    new-instance v0, LC/b;

    .line 72
    .line 73
    invoke-direct {v0}, LC/b;-><init>()V

    .line 74
    .line 75
    .line 76
    :cond_4b
    invoke-static {p1, v0}, LC/C;->d(Landroid/view/View;LC/b;)V

    .line 77
    .line 78
    .line 79
    iget v0, p0, LC/t;->a:I

    .line 80
    .line 81
    invoke-virtual {p1, v0, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    iget p2, p0, LC/t;->c:I

    .line 85
    .line 86
    invoke-static {p1, p2}, LC/C;->b(Landroid/view/View;I)V

    .line 87
    .line 88
    .line 89
    :cond_58
    return-void
.end method

.method public abstract e(Ljava/lang/Object;Ljava/lang/CharSequence;)Z
.end method
