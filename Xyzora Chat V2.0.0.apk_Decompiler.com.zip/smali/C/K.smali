###### Class C.K (C.K)
.class public LC/K;
.super LC/J;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, LC/J;-><init>()V

    return-void
.end method

.method public constructor <init>(LC/Z;)V
    .registers 2

    .line 2
    invoke-direct {p0, p1}, LC/J;-><init>(LC/Z;)V

    return-void
.end method
