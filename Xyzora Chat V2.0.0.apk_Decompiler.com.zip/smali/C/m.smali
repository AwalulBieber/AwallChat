###### Class C.InterfaceC0012m (C.m)
.class public interface abstract LC/m;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(IIIZ)V
.end method

.method public abstract c(IIII)V
.end method
