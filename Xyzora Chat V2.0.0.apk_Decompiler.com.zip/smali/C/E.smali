###### Class C.E (C.E)
.class public abstract LC/E;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, LC/Z;->b:LC/Z;

    .line 2
    .line 3
    invoke-virtual {v0}, LC/Z;->b()Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    return-void
.end method
