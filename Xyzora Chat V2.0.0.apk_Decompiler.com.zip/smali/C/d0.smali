###### Class C.d0 (C.d0)
.class public final LC/d0;
.super LC/c0;
.source "SourceFile"
