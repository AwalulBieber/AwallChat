###### Class C.L (C.L)
.class public final LC/L;
.super LC/K;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, LC/K;-><init>()V

    return-void
.end method

.method public constructor <init>(LC/Z;)V
    .registers 2

    .line 2
    invoke-direct {p0, p1}, LC/K;-><init>(LC/Z;)V

    return-void
.end method


# virtual methods
.method public c(ILv/b;)V
    .registers 4

    .line 1
    iget-object v0, p0, LC/H;->c:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-static {p1}, LC/Y;->a(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-virtual {p2}, Lv/b;->d()Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object p2

    .line 11
    invoke-static {v0, p1, p2}, LC/I;->o(Landroid/view/WindowInsets$Builder;ILandroid/graphics/Insets;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
