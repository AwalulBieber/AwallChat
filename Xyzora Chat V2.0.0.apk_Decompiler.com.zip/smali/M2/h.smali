###### Class M2.h (M2.h)
.class public abstract LM2/h;
.super LF2/K;
.source "SourceFile"


# instance fields
.field public g:LM2/c;


# virtual methods
.method public final d(Lq2/h;Ljava/lang/Runnable;)V
    .registers 4

    .line 1
    iget-object p1, p0, LM2/h;->g:LM2/c;

    .line 2
    .line 3
    sget-object v0, LM2/c;->l:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    .line 4
    .line 5
    sget-object v0, LM2/l;->g:LM2/j;

    .line 6
    .line 7
    invoke-virtual {p1, p2, v0}, LM2/c;->b(Ljava/lang/Runnable;LM2/j;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
