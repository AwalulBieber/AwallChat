###### Class M2.m (M2.m)
.class public final LM2/m;
.super LF2/s;
.source "SourceFile"


# static fields
.field public static final g:LM2/m;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, LM2/m;

    .line 2
    .line 3
    invoke-direct {v0}, LF2/s;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LM2/m;->g:LM2/m;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final d(Lq2/h;Ljava/lang/Runnable;)V
    .registers 4

    .line 1
    sget-object p1, LM2/e;->h:LM2/e;

    .line 2
    .line 3
    sget-object v0, LM2/l;->h:LM2/j;

    .line 4
    .line 5
    iget-object p1, p1, LM2/h;->g:LM2/c;

    .line 6
    .line 7
    invoke-virtual {p1, p2, v0}, LM2/c;->b(Ljava/lang/Runnable;LM2/j;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
