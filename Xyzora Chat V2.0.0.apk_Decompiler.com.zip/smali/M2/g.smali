###### Class M2.g (M2.g)
.class public final LM2/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LM2/g;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, LM2/g;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LM2/g;->a:LM2/g;

    .line 7
    .line 8
    return-void
.end method
