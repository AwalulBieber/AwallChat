###### Class M2.i (M2.i)
.class public abstract LM2/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public e:J

.field public f:LM2/j;


# direct methods
.method public constructor <init>(JLM2/j;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, LM2/i;->e:J

    .line 5
    .line 6
    iput-object p3, p0, LM2/i;->f:LM2/j;

    .line 7
    .line 8
    return-void
.end method
