###### Class M2.e (M2.e)
.class public final LM2/e;
.super LM2/h;
.source "SourceFile"


# static fields
.field public static final h:LM2/e;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 1
    new-instance v0, LM2/e;

    .line 2
    .line 3
    sget v2, LM2/l;->c:I

    .line 4
    .line 5
    sget v3, LM2/l;->d:I

    .line 6
    .line 7
    sget-wide v4, LM2/l;->e:J

    .line 8
    .line 9
    sget-object v6, LM2/l;->a:Ljava/lang/String;

    .line 10
    .line 11
    invoke-direct {v0}, LF2/s;-><init>()V

    .line 12
    .line 13
    .line 14
    new-instance v1, LM2/c;

    .line 15
    .line 16
    invoke-direct/range {v1 .. v6}, LM2/c;-><init>(IIJLjava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iput-object v1, v0, LM2/h;->g:LM2/c;

    .line 20
    .line 21
    sput-object v0, LM2/e;->h:LM2/e;

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final close()V
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    const-string v1, "Dispatchers.Default cannot be closed"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    .line 1
    const-string v0, "Dispatchers.Default"

    .line 2
    .line 3
    return-object v0
.end method
