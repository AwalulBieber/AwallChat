###### Class M2.f (M2.f)
.class public final LM2/f;
.super LK2/l;
.source "SourceFile"
