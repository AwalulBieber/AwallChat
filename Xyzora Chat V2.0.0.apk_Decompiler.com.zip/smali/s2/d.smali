###### Class s2.d (s2.d)
.class public interface abstract Ls2/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract d()Ls2/d;
.end method
