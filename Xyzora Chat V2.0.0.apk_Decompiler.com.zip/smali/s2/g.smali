###### Class s2.g (s2.g)
.class public abstract Ls2/g;
.super Ls2/a;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lkotlin/coroutines/Continuation;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Ls2/a;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 2
    .line 3
    .line 4
    invoke-interface {p1}, Lkotlin/coroutines/Continuation;->getContext()Lq2/h;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    sget-object v0, Lq2/i;->e:Lq2/i;

    .line 9
    .line 10
    if-ne p1, v0, :cond_c

    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 14
    .line 15
    const-string v0, "Coroutines with restricted suspension must have EmptyCoroutineContext"

    .line 16
    .line 17
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    throw p1
.end method


# virtual methods
.method public final getContext()Lq2/h;
    .registers 2

    .line 1
    sget-object v0, Lq2/i;->e:Lq2/i;

    .line 2
    .line 3
    return-object v0
.end method
