###### Class s2.f (s2.f)
.class public abstract Ls2/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lj/C0;

.field public static b:Lj/C0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lj/C0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1, v1, v1}, Lj/C0;-><init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Ls2/f;->a:Lj/C0;

    .line 8
    .line 9
    return-void
.end method
