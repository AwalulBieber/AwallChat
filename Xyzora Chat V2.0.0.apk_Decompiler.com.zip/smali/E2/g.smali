###### Class E2.g (E2.g)
.class public abstract LE2/g;
.super LE2/f;
.source "SourceFile"
