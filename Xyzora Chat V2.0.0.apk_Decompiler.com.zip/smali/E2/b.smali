###### Class E2.b (E2.b)
.class public abstract LE2/b;
.super LO2/a;
.source "SourceFile"
