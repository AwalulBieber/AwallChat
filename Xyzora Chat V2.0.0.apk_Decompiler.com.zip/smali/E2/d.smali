###### Class E2.d (E2.d)
.class public abstract LE2/d;
.super LE2/c;
.source "SourceFile"
