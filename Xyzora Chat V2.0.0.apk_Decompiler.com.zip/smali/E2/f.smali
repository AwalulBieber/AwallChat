###### Class E2.f (E2.f)
.class public abstract LE2/f;
.super LE2/e;
.source "SourceFile"
