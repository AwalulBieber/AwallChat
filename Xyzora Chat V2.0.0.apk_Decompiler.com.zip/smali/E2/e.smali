###### Class E2.e (E2.e)
.class public abstract LE2/e;
.super LE2/d;
.source "SourceFile"
