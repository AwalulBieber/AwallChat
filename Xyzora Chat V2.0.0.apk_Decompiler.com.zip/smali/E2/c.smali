###### Class E2.c (E2.c)
.class public abstract LE2/c;
.super LE2/b;
.source "SourceFile"
