###### Class p062u.g (u.g)
.class public final Lu/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lu/d;


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:I

.field public final c:I

.field public final d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;IILjava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lu/g;->a:Ljava/util/ArrayList;

    .line 5
    .line 6
    iput p2, p0, Lu/g;->c:I

    .line 7
    .line 8
    iput p3, p0, Lu/g;->b:I

    .line 9
    .line 10
    iput-object p4, p0, Lu/g;->d:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method
