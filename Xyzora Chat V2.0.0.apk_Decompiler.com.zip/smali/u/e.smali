###### Class p062u.e (u.e)
.class public final Lu/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lu/d;


# instance fields
.field public final a:[Lu/f;


# direct methods
.method public constructor <init>([Lu/f;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lu/e;->a:[Lu/f;

    .line 5
    .line 6
    return-void
.end method
