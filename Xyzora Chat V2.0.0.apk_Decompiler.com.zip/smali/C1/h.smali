###### Class C1.h (C1.h)
.class public final LC1/h;
.super LC1/s;
.source "SourceFile"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, LC1/h;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(LK1/b;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, LC1/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_32

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, LK1/b;->v()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const/16 v1, 0x9

    .line 11
    .line 12
    if-ne v0, v1, :cond_12

    .line 13
    .line 14
    invoke-virtual {p1}, LK1/b;->r()V

    .line 15
    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    goto :goto_1b

    .line 19
    :cond_12
    invoke-virtual {p1}, LK1/b;->m()D

    .line 20
    .line 21
    .line 22
    move-result-wide v0

    .line 23
    double-to-float p1, v0

    .line 24
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    :goto_1b
    return-object p1

    .line 29
    :pswitch_1c
    invoke-virtual {p1}, LK1/b;->v()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    const/16 v1, 0x9

    .line 34
    .line 35
    if-ne v0, v1, :cond_29

    .line 36
    .line 37
    invoke-virtual {p1}, LK1/b;->r()V

    .line 38
    .line 39
    .line 40
    const/4 p1, 0x0

    .line 41
    goto :goto_31

    .line 42
    :cond_29
    invoke-virtual {p1}, LK1/b;->m()D

    .line 43
    .line 44
    .line 45
    move-result-wide v0

    .line 46
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    :goto_31
    return-object p1

    .line 51
    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_1c
    .end packed-switch
.end method

.method public final b(LK1/d;Ljava/lang/Object;)V
    .registers 5

    .line 1
    iget v0, p0, LC1/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_2c

    .line 4
    .line 5
    .line 6
    check-cast p2, Ljava/lang/Number;

    .line 7
    .line 8
    if-nez p2, :cond_d

    .line 9
    .line 10
    invoke-virtual {p1}, LK1/d;->i()LK1/d;

    .line 11
    .line 12
    .line 13
    goto :goto_18

    .line 14
    :cond_d
    invoke-virtual {p2}, Ljava/lang/Number;->floatValue()F

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    float-to-double v0, v0

    .line 19
    invoke-static {v0, v1}, LC1/k;->a(D)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1, p2}, LK1/d;->n(Ljava/lang/Number;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    return-void

    .line 26
    :pswitch_19
    check-cast p2, Ljava/lang/Number;

    .line 27
    .line 28
    if-nez p2, :cond_21

    .line 29
    .line 30
    invoke-virtual {p1}, LK1/d;->i()LK1/d;

    .line 31
    .line 32
    .line 33
    goto :goto_2b

    .line 34
    :cond_21
    invoke-virtual {p2}, Ljava/lang/Number;->doubleValue()D

    .line 35
    .line 36
    .line 37
    move-result-wide v0

    .line 38
    invoke-static {v0, v1}, LC1/k;->a(D)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1, p2}, LK1/d;->n(Ljava/lang/Number;)V

    .line 42
    .line 43
    .line 44
    :goto_2b
    return-void

    .line 45
    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_19
    .end packed-switch
.end method
