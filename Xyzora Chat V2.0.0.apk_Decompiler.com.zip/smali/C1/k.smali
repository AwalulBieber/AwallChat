###### Class C1.k (C1.k)
.class public final LC1/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/ThreadLocal;

.field public final b:Ljava/util/concurrent/ConcurrentHashMap;

.field public final c:LE0/j;

.field public final d:LF1/c;

.field public final e:Ljava/util/List;

.field public final f:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, LJ1/a;

    .line 2
    .line 3
    const-class v1, Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {v0, v1}, LJ1/a;-><init>(Ljava/lang/reflect/Type;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(LE1/f;Ljava/util/HashMap;Ljava/util/ArrayList;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/ThreadLocal;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LC1/k;->a:Ljava/lang/ThreadLocal;

    .line 10
    .line 11
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, LC1/k;->b:Ljava/util/concurrent/ConcurrentHashMap;

    .line 17
    .line 18
    new-instance v0, LE0/j;

    .line 19
    .line 20
    invoke-direct {v0, p2}, LE0/j;-><init>(Ljava/util/HashMap;)V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, LC1/k;->c:LE0/j;

    .line 24
    .line 25
    const/4 p2, 0x1

    .line 26
    iput-boolean p2, p0, LC1/k;->f:Z

    .line 27
    .line 28
    new-instance p2, Ljava/util/ArrayList;

    .line 29
    .line 30
    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    .line 31
    .line 32
    .line 33
    sget-object v1, LF1/w;->y:LF1/t;

    .line 34
    .line 35
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    sget-object v1, LF1/m;->b:LF1/a;

    .line 39
    .line 40
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 47
    .line 48
    .line 49
    sget-object p3, LF1/w;->o:LF1/t;

    .line 50
    .line 51
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    sget-object p3, LF1/w;->g:LF1/u;

    .line 55
    .line 56
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    sget-object p3, LF1/w;->d:LF1/u;

    .line 60
    .line 61
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    sget-object p3, LF1/w;->e:LF1/u;

    .line 65
    .line 66
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    sget-object p3, LF1/w;->f:LF1/u;

    .line 70
    .line 71
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    sget-object p3, LF1/w;->k:LF1/l;

    .line 75
    .line 76
    new-instance v1, LF1/u;

    .line 77
    .line 78
    sget-object v2, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 79
    .line 80
    const-class v3, Ljava/lang/Long;

    .line 81
    .line 82
    invoke-direct {v1, v2, v3, p3}, LF1/u;-><init>(Ljava/lang/Class;Ljava/lang/Class;LC1/s;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    new-instance v1, LC1/h;

    .line 89
    .line 90
    const/4 v2, 0x0

    .line 91
    invoke-direct {v1, v2}, LC1/h;-><init>(I)V

    .line 92
    .line 93
    .line 94
    new-instance v2, LF1/u;

    .line 95
    .line 96
    sget-object v3, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    .line 97
    .line 98
    const-class v4, Ljava/lang/Double;

    .line 99
    .line 100
    invoke-direct {v2, v3, v4, v1}, LF1/u;-><init>(Ljava/lang/Class;Ljava/lang/Class;LC1/s;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    new-instance v1, LC1/h;

    .line 107
    .line 108
    const/4 v2, 0x1

    .line 109
    invoke-direct {v1, v2}, LC1/h;-><init>(I)V

    .line 110
    .line 111
    .line 112
    new-instance v2, LF1/u;

    .line 113
    .line 114
    sget-object v3, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    .line 115
    .line 116
    const-class v4, Ljava/lang/Float;

    .line 117
    .line 118
    invoke-direct {v2, v3, v4, v1}, LF1/u;-><init>(Ljava/lang/Class;Ljava/lang/Class;LC1/s;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    sget-object v1, LF1/l;->b:LF1/k;

    .line 125
    .line 126
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    sget-object v1, LF1/w;->h:LF1/t;

    .line 130
    .line 131
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    sget-object v1, LF1/w;->i:LF1/t;

    .line 135
    .line 136
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    new-instance v1, LC1/i;

    .line 140
    .line 141
    const/4 v2, 0x0

    .line 142
    invoke-direct {v1, p3, v2}, LC1/i;-><init>(LC1/s;I)V

    .line 143
    .line 144
    .line 145
    new-instance v2, LC1/i;

    .line 146
    .line 147
    const/4 v3, 0x2

    .line 148
    invoke-direct {v2, v1, v3}, LC1/i;-><init>(LC1/s;I)V

    .line 149
    .line 150
    .line 151
    new-instance v1, LF1/t;

    .line 152
    .line 153
    const-class v3, Ljava/util/concurrent/atomic/AtomicLong;

    .line 154
    .line 155
    const/4 v4, 0x0

    .line 156
    invoke-direct {v1, v3, v2, v4}, LF1/t;-><init>(Ljava/lang/Object;LC1/s;I)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    new-instance v1, LC1/i;

    .line 163
    .line 164
    const/4 v2, 0x1

    .line 165
    invoke-direct {v1, p3, v2}, LC1/i;-><init>(LC1/s;I)V

    .line 166
    .line 167
    .line 168
    new-instance p3, LC1/i;

    .line 169
    .line 170
    const/4 v2, 0x2

    .line 171
    invoke-direct {p3, v1, v2}, LC1/i;-><init>(LC1/s;I)V

    .line 172
    .line 173
    .line 174
    new-instance v1, LF1/t;

    .line 175
    .line 176
    const-class v2, Ljava/util/concurrent/atomic/AtomicLongArray;

    .line 177
    .line 178
    const/4 v3, 0x0

    .line 179
    invoke-direct {v1, v2, p3, v3}, LF1/t;-><init>(Ljava/lang/Object;LC1/s;I)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 183
    .line 184
    .line 185
    sget-object p3, LF1/w;->j:LF1/t;

    .line 186
    .line 187
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    sget-object p3, LF1/w;->l:LF1/u;

    .line 191
    .line 192
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    sget-object p3, LF1/w;->p:LF1/t;

    .line 196
    .line 197
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    sget-object p3, LF1/w;->q:LF1/t;

    .line 201
    .line 202
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    sget-object p3, LF1/w;->m:LF1/l;

    .line 206
    .line 207
    new-instance v1, LF1/t;

    .line 208
    .line 209
    const-class v2, Ljava/math/BigDecimal;

    .line 210
    .line 211
    const/4 v3, 0x0

    .line 212
    invoke-direct {v1, v2, p3, v3}, LF1/t;-><init>(Ljava/lang/Object;LC1/s;I)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 216
    .line 217
    .line 218
    sget-object p3, LF1/w;->n:LF1/l;

    .line 219
    .line 220
    new-instance v1, LF1/t;

    .line 221
    .line 222
    const-class v2, Ljava/math/BigInteger;

    .line 223
    .line 224
    const/4 v3, 0x0

    .line 225
    invoke-direct {v1, v2, p3, v3}, LF1/t;-><init>(Ljava/lang/Object;LC1/s;I)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 229
    .line 230
    .line 231
    sget-object p3, LF1/w;->r:LF1/t;

    .line 232
    .line 233
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 234
    .line 235
    .line 236
    sget-object p3, LF1/w;->s:LF1/t;

    .line 237
    .line 238
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 239
    .line 240
    .line 241
    sget-object p3, LF1/w;->u:LF1/t;

    .line 242
    .line 243
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    sget-object p3, LF1/w;->v:LF1/t;

    .line 247
    .line 248
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 249
    .line 250
    .line 251
    sget-object p3, LF1/w;->x:LF1/t;

    .line 252
    .line 253
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 254
    .line 255
    .line 256
    sget-object p3, LF1/w;->t:LF1/t;

    .line 257
    .line 258
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    sget-object p3, LF1/w;->b:LF1/t;

    .line 262
    .line 263
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    sget-object p3, LF1/d;->b:LF1/a;

    .line 267
    .line 268
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 269
    .line 270
    .line 271
    sget-object p3, LF1/w;->w:LF1/k;

    .line 272
    .line 273
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 274
    .line 275
    .line 276
    sget-boolean p3, LI1/b;->a:Z

    .line 277
    .line 278
    if-eqz p3, :cond_126

    .line 279
    .line 280
    sget-object p3, LI1/b;->c:LF1/a;

    .line 281
    .line 282
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    sget-object p3, LI1/b;->b:LF1/a;

    .line 286
    .line 287
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 288
    .line 289
    .line 290
    sget-object p3, LI1/b;->d:LF1/a;

    .line 291
    .line 292
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 293
    .line 294
    .line 295
    :cond_126
    sget-object p3, LF1/b;->d:LF1/a;

    .line 296
    .line 297
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 298
    .line 299
    .line 300
    sget-object p3, LF1/w;->a:LF1/t;

    .line 301
    .line 302
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 303
    .line 304
    .line 305
    new-instance p3, LF1/c;

    .line 306
    .line 307
    const/4 v1, 0x0

    .line 308
    invoke-direct {p3, v0, v1}, LF1/c;-><init>(LE0/j;I)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    new-instance p3, LF1/c;

    .line 315
    .line 316
    const/4 v1, 0x2

    .line 317
    invoke-direct {p3, v0, v1}, LF1/c;-><init>(LE0/j;I)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 321
    .line 322
    .line 323
    new-instance p3, LF1/c;

    .line 324
    .line 325
    const/4 v1, 0x1

    .line 326
    invoke-direct {p3, v0, v1}, LF1/c;-><init>(LE0/j;I)V

    .line 327
    .line 328
    .line 329
    iput-object p3, p0, LC1/k;->d:LF1/c;

    .line 330
    .line 331
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 332
    .line 333
    .line 334
    sget-object v1, LF1/w;->z:LF1/a;

    .line 335
    .line 336
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 337
    .line 338
    .line 339
    new-instance v1, LF1/p;

    .line 340
    .line 341
    invoke-direct {v1, v0, p1, p3}, LF1/p;-><init>(LE0/j;LE1/f;LF1/c;)V

    .line 342
    .line 343
    .line 344
    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 345
    .line 346
    .line 347
    invoke-static {p2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 348
    .line 349
    .line 350
    move-result-object p1

    .line 351
    iput-object p1, p0, LC1/k;->e:Ljava/util/List;

    .line 352
    .line 353
    return-void
.end method

.method public static a(D)V
    .registers 4

    .line 1
    invoke-static {p0, p1}, Ljava/lang/Double;->isNaN(D)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_d

    .line 6
    .line 7
    invoke-static {p0, p1}, Ljava/lang/Double;->isInfinite(D)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_d

    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 15
    .line 16
    new-instance v1, Ljava/lang/StringBuilder;

    .line 17
    .line 18
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1, p0, p1}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const-string p0, " is not a valid double value as per JSON specification. To override this behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method."

    .line 25
    .line 26
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v0
.end method


# virtual methods
.method public final b(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_4

    .line 3
    .line 4
    return-object v0

    .line 5
    :cond_4
    new-instance v1, Ljava/io/StringReader;

    .line 6
    .line 7
    invoke-direct {v1, p1}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    new-instance p1, LK1/b;

    .line 11
    .line 12
    invoke-direct {p1, v1}, LK1/b;-><init>(Ljava/io/Reader;)V

    .line 13
    .line 14
    .line 15
    const-string v1, "AssertionError (GSON 2.8.9): "

    .line 16
    .line 17
    const/4 v2, 0x1

    .line 18
    iput-boolean v2, p1, LK1/b;->f:Z

    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    :try_start_14
    invoke-virtual {p1}, LK1/b;->v()I
    :try_end_17
    .catch Ljava/io/EOFException; {:try_start_14 .. :try_end_17} :catch_57
    .catch Ljava/lang/IllegalStateException; {:try_start_14 .. :try_end_17} :catch_2d
    .catch Ljava/io/IOException; {:try_start_14 .. :try_end_17} :catch_2b
    .catch Ljava/lang/AssertionError; {:try_start_14 .. :try_end_17} :catch_29
    .catchall {:try_start_14 .. :try_end_17} :catchall_27

    .line 22
    .line 23
    .line 24
    :try_start_17
    new-instance v2, LJ1/a;

    .line 25
    .line 26
    invoke-direct {v2, p2}, LJ1/a;-><init>(Ljava/lang/reflect/Type;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0, v2}, LC1/k;->c(LJ1/a;)LC1/s;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    invoke-virtual {p2, p1}, LC1/s;->a(LK1/b;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0
    :try_end_24
    .catch Ljava/io/EOFException; {:try_start_17 .. :try_end_24} :catch_2f
    .catch Ljava/lang/IllegalStateException; {:try_start_17 .. :try_end_24} :catch_2d
    .catch Ljava/io/IOException; {:try_start_17 .. :try_end_24} :catch_2b
    .catch Ljava/lang/AssertionError; {:try_start_17 .. :try_end_24} :catch_29
    .catchall {:try_start_17 .. :try_end_24} :catchall_27

    .line 37
    :goto_24
    iput-boolean v3, p1, LK1/b;->f:Z

    .line 38
    .line 39
    goto :goto_5b

    .line 40
    :catchall_27
    move-exception p2

    .line 41
    goto :goto_85

    .line 42
    :catch_29
    move-exception p2

    .line 43
    goto :goto_32

    .line 44
    :catch_2b
    move-exception p2

    .line 45
    goto :goto_4b

    .line 46
    :catch_2d
    move-exception p2

    .line 47
    goto :goto_51

    .line 48
    :catch_2f
    move-exception p2

    .line 49
    move v2, v3

    .line 50
    goto :goto_58

    .line 51
    :goto_32
    :try_start_32
    new-instance v0, Ljava/lang/AssertionError;

    .line 52
    .line 53
    new-instance v2, Ljava/lang/StringBuilder;

    .line 54
    .line 55
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v0, p2}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 73
    .line 74
    .line 75
    throw v0

    .line 76
    :goto_4b
    new-instance v0, LC1/n;

    .line 77
    .line 78
    invoke-direct {v0, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 79
    .line 80
    .line 81
    throw v0

    .line 82
    :goto_51
    new-instance v0, LC1/n;

    .line 83
    .line 84
    invoke-direct {v0, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 85
    .line 86
    .line 87
    throw v0
    :try_end_57
    .catchall {:try_start_32 .. :try_end_57} :catchall_27

    .line 88
    :catch_57
    move-exception p2

    .line 89
    :goto_58
    if-eqz v2, :cond_7f

    .line 90
    .line 91
    goto :goto_24

    .line 92
    :goto_5b
    if-eqz v0, :cond_7e

    .line 93
    .line 94
    :try_start_5d
    invoke-virtual {p1}, LK1/b;->v()I

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    const/16 p2, 0xa

    .line 99
    .line 100
    if-ne p1, p2, :cond_66

    .line 101
    .line 102
    goto :goto_7e

    .line 103
    :cond_66
    new-instance p1, LC1/n;

    .line 104
    .line 105
    const-string p2, "JSON document was not fully consumed."

    .line 106
    .line 107
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    throw p1
    :try_end_6e
    .catch LK1/e; {:try_start_5d .. :try_end_6e} :catch_70
    .catch Ljava/io/IOException; {:try_start_5d .. :try_end_6e} :catch_6e

    .line 111
    :catch_6e
    move-exception p1

    .line 112
    goto :goto_72

    .line 113
    :catch_70
    move-exception p1

    .line 114
    goto :goto_78

    .line 115
    :goto_72
    new-instance p2, LC1/n;

    .line 116
    .line 117
    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 118
    .line 119
    .line 120
    throw p2

    .line 121
    :goto_78
    new-instance p2, LC1/n;

    .line 122
    .line 123
    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 124
    .line 125
    .line 126
    throw p2

    .line 127
    :cond_7e
    :goto_7e
    return-object v0

    .line 128
    :cond_7f
    :try_start_7f
    new-instance v0, LC1/n;

    .line 129
    .line 130
    invoke-direct {v0, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 131
    .line 132
    .line 133
    throw v0
    :try_end_85
    .catchall {:try_start_7f .. :try_end_85} :catchall_27

    .line 134
    :goto_85
    iput-boolean v3, p1, LK1/b;->f:Z

    .line 135
    .line 136
    throw p2
.end method

.method public final c(LJ1/a;)LC1/s;
    .registers 9

    .line 1
    iget-object v0, p0, LC1/k;->b:Ljava/util/concurrent/ConcurrentHashMap;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, LC1/s;

    .line 8
    .line 9
    if-eqz v1, :cond_b

    .line 10
    .line 11
    return-object v1

    .line 12
    :cond_b
    iget-object v1, p0, LC1/k;->a:Ljava/lang/ThreadLocal;

    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    check-cast v2, Ljava/util/Map;

    .line 19
    .line 20
    if-nez v2, :cond_1f

    .line 21
    .line 22
    new-instance v2, Ljava/util/HashMap;

    .line 23
    .line 24
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    const/4 v3, 0x1

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    const/4 v3, 0x0

    .line 33
    :goto_20
    invoke-interface {v2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v4

    .line 37
    check-cast v4, LC1/j;

    .line 38
    .line 39
    if-eqz v4, :cond_29

    .line 40
    .line 41
    return-object v4

    .line 42
    :cond_29
    :try_start_29
    new-instance v4, LC1/j;

    .line 43
    .line 44
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 45
    .line 46
    .line 47
    invoke-interface {v2, p1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    iget-object v5, p0, LC1/k;->e:Ljava/util/List;

    .line 51
    .line 52
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 53
    .line 54
    .line 55
    move-result-object v5

    .line 56
    :cond_37
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 57
    .line 58
    .line 59
    move-result v6

    .line 60
    if-eqz v6, :cond_63

    .line 61
    .line 62
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    check-cast v6, LC1/t;

    .line 67
    .line 68
    invoke-interface {v6, p0, p1}, LC1/t;->create(LC1/k;LJ1/a;)LC1/s;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    if-eqz v6, :cond_37

    .line 73
    .line 74
    iget-object v5, v4, LC1/j;->a:LC1/s;

    .line 75
    .line 76
    if-nez v5, :cond_5b

    .line 77
    .line 78
    iput-object v6, v4, LC1/j;->a:LC1/s;

    .line 79
    .line 80
    invoke-virtual {v0, p1, v6}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_52
    .catchall {:try_start_29 .. :try_end_52} :catchall_61

    .line 81
    .line 82
    .line 83
    invoke-interface {v2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    if-eqz v3, :cond_5a

    .line 87
    .line 88
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    .line 89
    .line 90
    .line 91
    :cond_5a
    return-object v6

    .line 92
    :cond_5b
    :try_start_5b
    new-instance v0, Ljava/lang/AssertionError;

    .line 93
    .line 94
    invoke-direct {v0}, Ljava/lang/AssertionError;-><init>()V

    .line 95
    .line 96
    .line 97
    throw v0

    .line 98
    :catchall_61
    move-exception v0

    .line 99
    goto :goto_7a

    .line 100
    :cond_63
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 101
    .line 102
    new-instance v4, Ljava/lang/StringBuilder;

    .line 103
    .line 104
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 105
    .line 106
    .line 107
    const-string v5, "GSON (2.8.9) cannot handle "

    .line 108
    .line 109
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 113
    .line 114
    .line 115
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v4

    .line 119
    invoke-direct {v0, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    throw v0
    :try_end_7a
    .catchall {:try_start_5b .. :try_end_7a} :catchall_61

    .line 123
    :goto_7a
    invoke-interface {v2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    if-eqz v3, :cond_82

    .line 127
    .line 128
    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    .line 129
    .line 130
    .line 131
    :cond_82
    throw v0
.end method

.method public final d(LC1/t;LJ1/a;)LC1/s;
    .registers 6

    .line 1
    iget-object v0, p0, LC1/k;->e:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_a

    .line 8
    .line 9
    iget-object p1, p0, LC1/k;->d:LF1/c;

    .line 10
    .line 11
    :cond_a
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const/4 v1, 0x0

    .line 16
    :cond_f
    :goto_f
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_28

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, LC1/t;

    .line 27
    .line 28
    if-nez v1, :cond_21

    .line 29
    .line 30
    if-ne v2, p1, :cond_f

    .line 31
    .line 32
    const/4 v1, 0x1

    .line 33
    goto :goto_f

    .line 34
    :cond_21
    invoke-interface {v2, p0, p2}, LC1/t;->create(LC1/k;LJ1/a;)LC1/s;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    if-eqz v2, :cond_f

    .line 39
    .line 40
    return-object v2

    .line 41
    :cond_28
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 42
    .line 43
    new-instance v0, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    const-string v1, "GSON cannot serialize "

    .line 46
    .line 47
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    throw p1
.end method

.method public final e(Ljava/io/Writer;)LK1/d;
    .registers 3

    .line 1
    new-instance v0, LK1/d;

    .line 2
    .line 3
    invoke-direct {v0, p1}, LK1/d;-><init>(Ljava/io/Writer;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    iput-boolean p1, v0, LK1/d;->l:Z

    .line 8
    .line 9
    return-object v0
.end method

.method public final f(Ljava/io/Serializable;)Ljava/lang/String;
    .registers 5

    .line 1
    if-nez p1, :cond_1a

    .line 2
    .line 3
    new-instance p1, Ljava/io/StringWriter;

    .line 4
    .line 5
    invoke-direct {p1}, Ljava/io/StringWriter;-><init>()V

    .line 6
    .line 7
    .line 8
    :try_start_7
    invoke-virtual {p0, p1}, LC1/k;->e(Ljava/io/Writer;)LK1/d;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p0, v0}, LC1/k;->g(LK1/d;)V
    :try_end_e
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_e} :catch_13

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    return-object p1

    .line 20
    :catch_13
    move-exception p1

    .line 21
    new-instance v0, LC1/n;

    .line 22
    .line 23
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 24
    .line 25
    .line 26
    throw v0

    .line 27
    :cond_1a
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    new-instance v1, Ljava/io/StringWriter;

    .line 32
    .line 33
    invoke-direct {v1}, Ljava/io/StringWriter;-><init>()V

    .line 34
    .line 35
    .line 36
    :try_start_23
    invoke-virtual {p0, v1}, LC1/k;->e(Ljava/io/Writer;)LK1/d;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    invoke-virtual {p0, p1, v0, v2}, LC1/k;->h(Ljava/io/Serializable;Ljava/lang/Class;LK1/d;)V
    :try_end_2a
    .catch Ljava/io/IOException; {:try_start_23 .. :try_end_2a} :catch_2f

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    return-object p1

    .line 48
    :catch_2f
    move-exception p1

    .line 49
    new-instance v0, LC1/n;

    .line 50
    .line 51
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 52
    .line 53
    .line 54
    throw v0
.end method

.method public final g(LK1/d;)V
    .registers 9

    .line 1
    sget-object v0, LC1/o;->e:LC1/o;

    .line 2
    .line 3
    const-string v1, "AssertionError (GSON 2.8.9): "

    .line 4
    .line 5
    iget-boolean v2, p1, LK1/d;->i:Z

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    iput-boolean v3, p1, LK1/d;->i:Z

    .line 9
    .line 10
    iget-boolean v3, p1, LK1/d;->j:Z

    .line 11
    .line 12
    iget-boolean v4, p0, LC1/k;->f:Z

    .line 13
    .line 14
    iput-boolean v4, p1, LK1/d;->j:Z

    .line 15
    .line 16
    iget-boolean v4, p1, LK1/d;->l:Z

    .line 17
    .line 18
    const/4 v5, 0x0

    .line 19
    iput-boolean v5, p1, LK1/d;->l:Z

    .line 20
    .line 21
    :try_start_14
    sget-object v5, LF1/w;->a:LF1/t;

    .line 22
    .line 23
    invoke-static {p1, v0}, LF1/l;->d(LK1/d;LC1/m;)V
    :try_end_19
    .catch Ljava/io/IOException; {:try_start_14 .. :try_end_19} :catch_3c
    .catch Ljava/lang/AssertionError; {:try_start_14 .. :try_end_19} :catch_20
    .catchall {:try_start_14 .. :try_end_19} :catchall_3a

    .line 24
    .line 25
    .line 26
    iput-boolean v2, p1, LK1/d;->i:Z

    .line 27
    .line 28
    iput-boolean v3, p1, LK1/d;->j:Z

    .line 29
    .line 30
    iput-boolean v4, p1, LK1/d;->l:Z

    .line 31
    .line 32
    return-void

    .line 33
    :catch_20
    move-exception v0

    .line 34
    :try_start_21
    new-instance v5, Ljava/lang/AssertionError;

    .line 35
    .line 36
    new-instance v6, Ljava/lang/StringBuilder;

    .line 37
    .line 38
    invoke-direct {v6, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-direct {v5, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v5, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 56
    .line 57
    .line 58
    throw v5

    .line 59
    :catchall_3a
    move-exception v0

    .line 60
    goto :goto_43

    .line 61
    :catch_3c
    move-exception v0

    .line 62
    new-instance v1, LC1/n;

    .line 63
    .line 64
    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 65
    .line 66
    .line 67
    throw v1
    :try_end_43
    .catchall {:try_start_21 .. :try_end_43} :catchall_3a

    .line 68
    :goto_43
    iput-boolean v2, p1, LK1/d;->i:Z

    .line 69
    .line 70
    iput-boolean v3, p1, LK1/d;->j:Z

    .line 71
    .line 72
    iput-boolean v4, p1, LK1/d;->l:Z

    .line 73
    .line 74
    throw v0
.end method

.method public final h(Ljava/io/Serializable;Ljava/lang/Class;LK1/d;)V
    .registers 9

    .line 1
    const-string v0, "AssertionError (GSON 2.8.9): "

    .line 2
    .line 3
    new-instance v1, LJ1/a;

    .line 4
    .line 5
    invoke-direct {v1, p2}, LJ1/a;-><init>(Ljava/lang/reflect/Type;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0, v1}, LC1/k;->c(LJ1/a;)LC1/s;

    .line 9
    .line 10
    .line 11
    move-result-object p2

    .line 12
    iget-boolean v1, p3, LK1/d;->i:Z

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    iput-boolean v2, p3, LK1/d;->i:Z

    .line 16
    .line 17
    iget-boolean v2, p3, LK1/d;->j:Z

    .line 18
    .line 19
    iget-boolean v3, p0, LC1/k;->f:Z

    .line 20
    .line 21
    iput-boolean v3, p3, LK1/d;->j:Z

    .line 22
    .line 23
    iget-boolean v3, p3, LK1/d;->l:Z

    .line 24
    .line 25
    const/4 v4, 0x0

    .line 26
    iput-boolean v4, p3, LK1/d;->l:Z

    .line 27
    .line 28
    :try_start_1b
    invoke-virtual {p2, p3, p1}, LC1/s;->b(LK1/d;Ljava/lang/Object;)V
    :try_end_1e
    .catch Ljava/io/IOException; {:try_start_1b .. :try_end_1e} :catch_41
    .catch Ljava/lang/AssertionError; {:try_start_1b .. :try_end_1e} :catch_27
    .catchall {:try_start_1b .. :try_end_1e} :catchall_25

    .line 29
    .line 30
    .line 31
    iput-boolean v1, p3, LK1/d;->i:Z

    .line 32
    .line 33
    iput-boolean v2, p3, LK1/d;->j:Z

    .line 34
    .line 35
    iput-boolean v3, p3, LK1/d;->l:Z

    .line 36
    .line 37
    return-void

    .line 38
    :catchall_25
    move-exception p1

    .line 39
    goto :goto_48

    .line 40
    :catch_27
    move-exception p1

    .line 41
    :try_start_28
    new-instance p2, Ljava/lang/AssertionError;

    .line 42
    .line 43
    new-instance v4, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-direct {p2, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 63
    .line 64
    .line 65
    throw p2

    .line 66
    :catch_41
    move-exception p1

    .line 67
    new-instance p2, LC1/n;

    .line 68
    .line 69
    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 70
    .line 71
    .line 72
    throw p2
    :try_end_48
    .catchall {:try_start_28 .. :try_end_48} :catchall_25

    .line 73
    :goto_48
    iput-boolean v1, p3, LK1/d;->i:Z

    .line 74
    .line 75
    iput-boolean v2, p3, LK1/d;->j:Z

    .line 76
    .line 77
    iput-boolean v3, p3, LK1/d;->l:Z

    .line 78
    .line 79
    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "{serializeNulls:false,factories:"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LC1/k;->e:Ljava/util/List;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ",instanceCreators:"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, LC1/k;->c:LE0/j;

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, "}"

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    return-object v0
.end method
