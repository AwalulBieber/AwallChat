###### Class C1.s (C1.s)
.class public abstract LC1/s;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LK1/b;)Ljava/lang/Object;
.end method

.method public abstract b(LK1/d;Ljava/lang/Object;)V
.end method
