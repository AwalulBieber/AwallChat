###### Class C1.j (C1.j)
.class public final LC1/j;
.super LC1/s;
.source "SourceFile"


# instance fields
.field public a:LC1/s;


# virtual methods
.method public final a(LK1/b;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object v0, p0, LC1/j;->a:LC1/s;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LC1/s;->a(LK1/b;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1

    .line 10
    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 11
    .line 12
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 13
    .line 14
    .line 15
    throw p1
.end method

.method public final b(LK1/d;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iget-object v0, p0, LC1/j;->a:LC1/s;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, LC1/s;->b(LK1/d;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 10
    .line 11
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 12
    .line 13
    .line 14
    throw p1
.end method
