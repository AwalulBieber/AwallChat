###### Class C1.t (C1.t)
.class public interface abstract LC1/t;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract create(LC1/k;LJ1/a;)LC1/s;
.end method
