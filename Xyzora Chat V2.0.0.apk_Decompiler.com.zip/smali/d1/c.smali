###### Class p011d1.c (d1.c)
.class public final synthetic Ld1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr1/a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, Ld1/c;->a:I

    iput-object p2, p0, Ld1/c;->b:Ljava/lang/Object;

    iput-object p3, p0, Ld1/c;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    .line 2
    const/4 v0, 0x2

    iput v0, p0, Ld1/c;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld1/c;->c:Ljava/lang/Object;

    iput-object p2, p0, Ld1/c;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 16

    .line 1
    iget v0, p0, Ld1/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_ca

    .line 4
    .line 5
    .line 6
    new-instance v0, Lp1/h;

    .line 7
    .line 8
    iget-object v1, p0, Ld1/c;->c:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Landroid/content/Context;

    .line 11
    .line 12
    iget-object v2, p0, Ld1/c;->b:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, Ljava/lang/String;

    .line 15
    .line 16
    invoke-direct {v0, v1, v2}, Lp1/h;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-object v0

    .line 20
    :pswitch_13
    iget-object v0, p0, Ld1/c;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, Lg1/f;

    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    iget-object v1, p0, Ld1/c;->c:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v1, Lg1/a;

    .line 30
    .line 31
    iget-object v2, v1, Lg1/a;->f:Lg1/d;

    .line 32
    .line 33
    new-instance v3, Lg1/s;

    .line 34
    .line 35
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 36
    .line 37
    .line 38
    new-instance v4, Ljava/util/HashSet;

    .line 39
    .line 40
    invoke-direct {v4}, Ljava/util/HashSet;-><init>()V

    .line 41
    .line 42
    .line 43
    new-instance v5, Ljava/util/HashSet;

    .line 44
    .line 45
    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    .line 46
    .line 47
    .line 48
    new-instance v6, Ljava/util/HashSet;

    .line 49
    .line 50
    invoke-direct {v6}, Ljava/util/HashSet;-><init>()V

    .line 51
    .line 52
    .line 53
    new-instance v7, Ljava/util/HashSet;

    .line 54
    .line 55
    invoke-direct {v7}, Ljava/util/HashSet;-><init>()V

    .line 56
    .line 57
    .line 58
    new-instance v8, Ljava/util/HashSet;

    .line 59
    .line 60
    invoke-direct {v8}, Ljava/util/HashSet;-><init>()V

    .line 61
    .line 62
    .line 63
    iget-object v9, v1, Lg1/a;->c:Ljava/util/Set;

    .line 64
    .line 65
    invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 66
    .line 67
    .line 68
    move-result-object v9

    .line 69
    :goto_44
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 70
    .line 71
    .line 72
    move-result v10

    .line 73
    if-eqz v10, :cond_78

    .line 74
    .line 75
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v10

    .line 79
    check-cast v10, Lg1/i;

    .line 80
    .line 81
    iget v11, v10, Lg1/i;->c:I

    .line 82
    .line 83
    if-nez v11, :cond_56

    .line 84
    .line 85
    const/4 v12, 0x1

    .line 86
    goto :goto_57

    .line 87
    :cond_56
    const/4 v12, 0x0

    .line 88
    :goto_57
    const/4 v13, 0x2

    .line 89
    iget v14, v10, Lg1/i;->b:I

    .line 90
    .line 91
    iget-object v10, v10, Lg1/i;->a:Lg1/q;

    .line 92
    .line 93
    if-eqz v12, :cond_68

    .line 94
    .line 95
    if-ne v14, v13, :cond_64

    .line 96
    .line 97
    invoke-virtual {v7, v10}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    goto :goto_44

    .line 101
    :cond_64
    invoke-virtual {v4, v10}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    goto :goto_44

    .line 105
    :cond_68
    if-ne v11, v13, :cond_6e

    .line 106
    .line 107
    invoke-virtual {v6, v10}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    goto :goto_44

    .line 111
    :cond_6e
    if-ne v14, v13, :cond_74

    .line 112
    .line 113
    invoke-virtual {v8, v10}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    goto :goto_44

    .line 117
    :cond_74
    invoke-virtual {v5, v10}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 118
    .line 119
    .line 120
    goto :goto_44

    .line 121
    :cond_78
    iget-object v1, v1, Lg1/a;->g:Ljava/util/Set;

    .line 122
    .line 123
    invoke-interface {v1}, Ljava/util/Set;->isEmpty()Z

    .line 124
    .line 125
    .line 126
    move-result v9

    .line 127
    if-nez v9, :cond_89

    .line 128
    .line 129
    const-class v9, Lo1/b;

    .line 130
    .line 131
    invoke-static {v9}, Lg1/q;->a(Ljava/lang/Class;)Lg1/q;

    .line 132
    .line 133
    .line 134
    move-result-object v9

    .line 135
    invoke-virtual {v4, v9}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    :cond_89
    invoke-static {v4}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 139
    .line 140
    .line 141
    move-result-object v4

    .line 142
    iput-object v4, v3, Lg1/s;->a:Ljava/lang/Object;

    .line 143
    .line 144
    invoke-static {v5}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 145
    .line 146
    .line 147
    move-result-object v4

    .line 148
    iput-object v4, v3, Lg1/s;->b:Ljava/lang/Object;

    .line 149
    .line 150
    invoke-static {v6}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 151
    .line 152
    .line 153
    invoke-static {v7}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    iput-object v4, v3, Lg1/s;->c:Ljava/lang/Object;

    .line 158
    .line 159
    invoke-static {v8}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 160
    .line 161
    .line 162
    move-result-object v4

    .line 163
    iput-object v4, v3, Lg1/s;->d:Ljava/lang/Object;

    .line 164
    .line 165
    iput-object v1, v3, Lg1/s;->e:Ljava/lang/Object;

    .line 166
    .line 167
    iput-object v0, v3, Lg1/s;->f:Ljava/lang/Object;

    .line 168
    .line 169
    invoke-interface {v2, v3}, Lg1/d;->a(Lg1/s;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    return-object v0

    .line 174
    :pswitch_ad
    new-instance v0, Lw1/a;

    .line 175
    .line 176
    iget-object v1, p0, Ld1/c;->b:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v1, Ld1/g;

    .line 179
    .line 180
    invoke-virtual {v1}, Ld1/g;->f()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v2

    .line 184
    iget-object v1, v1, Ld1/g;->d:Lg1/f;

    .line 185
    .line 186
    const-class v3, Lo1/b;

    .line 187
    .line 188
    invoke-interface {v1, v3}, Lg1/b;->a(Ljava/lang/Class;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    check-cast v1, Lo1/b;

    .line 193
    .line 194
    iget-object v3, p0, Ld1/c;->c:Ljava/lang/Object;

    .line 195
    .line 196
    check-cast v3, Landroid/content/Context;

    .line 197
    .line 198
    invoke-direct {v0, v3, v2, v1}, Lw1/a;-><init>(Landroid/content/Context;Ljava/lang/String;Lo1/b;)V

    .line 199
    .line 200
    .line 201
    return-object v0

    .line 202
    nop

    .line 203
    :pswitch_data_ca
    .packed-switch 0x0
        :pswitch_ad
        :pswitch_13
    .end packed-switch
.end method
