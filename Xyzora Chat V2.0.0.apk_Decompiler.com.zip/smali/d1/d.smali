###### Class p011d1.d (d1.d)
.class public final synthetic Ld1/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Ld1/g;


# direct methods
.method public synthetic constructor <init>(Ld1/g;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld1/d;->a:Ld1/g;

    return-void
.end method
