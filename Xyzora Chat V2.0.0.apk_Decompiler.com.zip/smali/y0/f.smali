###### Class y0.f (y0.f)
.class public final Ly0/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lb2/n;

.field public final b:Ly0/e;

.field public final c:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ly0/e;)V
    .registers 5

    .line 1
    new-instance v0, Lb2/n;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput-object v1, v0, Lb2/n;->f:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p1, v0, Lb2/n;->e:Ljava/lang/Object;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    new-instance p1, Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Ly0/f;->c:Ljava/util/HashMap;

    .line 20
    .line 21
    iput-object v0, p0, Ly0/f;->a:Lb2/n;

    .line 22
    .line 23
    iput-object p2, p0, Ly0/f;->b:Ly0/e;

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Ljava/lang/String;)Ly0/g;
    .registers 7

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Ly0/f;->c:Ljava/util/HashMap;

    .line 3
    .line 4
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_15

    .line 9
    .line 10
    iget-object v0, p0, Ly0/f;->c:Ljava/util/HashMap;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, Ly0/g;
    :try_end_11
    .catchall {:try_start_1 .. :try_end_11} :catchall_13

    .line 17
    .line 18
    monitor-exit p0

    .line 19
    return-object p1

    .line 20
    :catchall_13
    move-exception p1

    .line 21
    goto :goto_38

    .line 22
    :cond_15
    :try_start_15
    iget-object v0, p0, Ly0/f;->a:Lb2/n;

    .line 23
    .line 24
    invoke-virtual {v0, p1}, Lb2/n;->q(Ljava/lang/String;)Lcom/google/android/datatransport/cct/CctBackendFactory;

    .line 25
    .line 26
    .line 27
    move-result-object v0
    :try_end_1b
    .catchall {:try_start_15 .. :try_end_1b} :catchall_13

    .line 28
    if-nez v0, :cond_20

    .line 29
    .line 30
    monitor-exit p0

    .line 31
    const/4 p1, 0x0

    .line 32
    return-object p1

    .line 33
    :cond_20
    :try_start_20
    iget-object v1, p0, Ly0/f;->b:Ly0/e;

    .line 34
    .line 35
    new-instance v2, Ly0/b;

    .line 36
    .line 37
    iget-object v3, v1, Ly0/e;->a:Landroid/content/Context;

    .line 38
    .line 39
    iget-object v4, v1, Ly0/e;->b:LG0/a;

    .line 40
    .line 41
    iget-object v1, v1, Ly0/e;->c:LG0/a;

    .line 42
    .line 43
    invoke-direct {v2, v3, v4, v1, p1}, Ly0/b;-><init>(Landroid/content/Context;LG0/a;LG0/a;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v2}, Lcom/google/android/datatransport/cct/CctBackendFactory;->create(Ly0/d;)Ly0/g;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iget-object v1, p0, Ly0/f;->c:Ljava/util/HashMap;

    .line 51
    .line 52
    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_36
    .catchall {:try_start_20 .. :try_end_36} :catchall_13

    .line 53
    .line 54
    .line 55
    monitor-exit p0

    .line 56
    return-object v0

    .line 57
    :goto_38
    :try_start_38
    monitor-exit p0
    :try_end_39
    .catchall {:try_start_38 .. :try_end_39} :catchall_13

    .line 58
    throw p1
.end method
