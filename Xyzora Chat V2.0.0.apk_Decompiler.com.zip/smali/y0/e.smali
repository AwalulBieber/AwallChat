###### Class y0.e (y0.e)
.class public final Ly0/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:LG0/a;

.field public final c:LG0/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;LG0/a;LG0/a;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ly0/e;->a:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p2, p0, Ly0/e;->b:LG0/a;

    .line 7
    .line 8
    iput-object p3, p0, Ly0/e;->c:LG0/a;

    .line 9
    .line 10
    return-void
.end method
