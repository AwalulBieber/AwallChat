###### Class y0.g (y0.g)
.class public interface abstract Ly0/g;
.super Ljava/lang/Object;
.source "SourceFile"
