###### Class p051p1.c (p1.c)
.class public final synthetic Lp1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lp1/d;


# direct methods
.method public synthetic constructor <init>(Lp1/d;I)V
    .registers 3

    .line 1
    iput p2, p0, Lp1/c;->a:I

    iput-object p1, p0, Lp1/c;->b:Lp1/d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 9

    .line 1
    iget v0, p0, Lp1/c;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_c2

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lp1/c;->b:Lp1/d;

    .line 7
    .line 8
    monitor-enter v0

    .line 9
    :try_start_8
    iget-object v1, v0, Lp1/d;->a:Ld1/c;

    .line 10
    .line 11
    invoke-virtual {v1}, Ld1/c;->get()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lp1/h;

    .line 16
    .line 17
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v2

    .line 21
    iget-object v4, v0, Lp1/d;->c:Lr1/a;

    .line 22
    .line 23
    invoke-interface {v4}, Lr1/a;->get()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    check-cast v4, LA1/c;

    .line 28
    .line 29
    invoke-virtual {v4}, LA1/c;->a()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    invoke-virtual {v1, v2, v3, v4}, Lp1/h;->h(JLjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    monitor-exit v0

    .line 37
    const/4 v0, 0x0

    .line 38
    return-object v0

    .line 39
    :catchall_26
    move-exception v1

    .line 40
    monitor-exit v0
    :try_end_28
    .catchall {:try_start_8 .. :try_end_28} :catchall_26

    .line 41
    throw v1

    .line 42
    :pswitch_29
    iget-object v0, p0, Lp1/c;->b:Lp1/d;

    .line 43
    .line 44
    monitor-enter v0

    .line 45
    :try_start_2c
    iget-object v1, v0, Lp1/d;->a:Ld1/c;

    .line 46
    .line 47
    invoke-virtual {v1}, Ld1/c;->get()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Lp1/h;

    .line 52
    .line 53
    invoke-virtual {v1}, Lp1/h;->c()Ljava/util/ArrayList;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-virtual {v1}, Lp1/h;->b()V

    .line 58
    .line 59
    .line 60
    new-instance v1, Lorg/json/JSONArray;

    .line 61
    .line 62
    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    .line 63
    .line 64
    .line 65
    const/4 v3, 0x0

    .line 66
    :goto_41
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    if-ge v3, v4, :cond_6d

    .line 71
    .line 72
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    check-cast v4, Lp1/a;

    .line 77
    .line 78
    new-instance v5, Lorg/json/JSONObject;

    .line 79
    .line 80
    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    .line 81
    .line 82
    .line 83
    const-string v6, "agent"

    .line 84
    .line 85
    iget-object v7, v4, Lp1/a;->a:Ljava/lang/String;

    .line 86
    .line 87
    invoke-virtual {v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 88
    .line 89
    .line 90
    const-string v6, "dates"

    .line 91
    .line 92
    new-instance v7, Lorg/json/JSONArray;

    .line 93
    .line 94
    iget-object v4, v4, Lp1/a;->b:Ljava/util/ArrayList;

    .line 95
    .line 96
    invoke-direct {v7, v4}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 100
    .line 101
    .line 102
    invoke-virtual {v1, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 103
    .line 104
    .line 105
    add-int/lit8 v3, v3, 0x1

    .line 106
    .line 107
    goto :goto_41

    .line 108
    :catchall_6b
    move-exception v1

    .line 109
    goto :goto_bf

    .line 110
    :cond_6d
    new-instance v2, Lorg/json/JSONObject;

    .line 111
    .line 112
    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    .line 113
    .line 114
    .line 115
    const-string v3, "heartbeats"

    .line 116
    .line 117
    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 118
    .line 119
    .line 120
    const-string v1, "version"

    .line 121
    .line 122
    const-string v3, "2"

    .line 123
    .line 124
    invoke-virtual {v2, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 125
    .line 126
    .line 127
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    .line 128
    .line 129
    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 130
    .line 131
    .line 132
    new-instance v3, Landroid/util/Base64OutputStream;

    .line 133
    .line 134
    const/16 v4, 0xb

    .line 135
    .line 136
    invoke-direct {v3, v1, v4}, Landroid/util/Base64OutputStream;-><init>(Ljava/io/OutputStream;I)V
    :try_end_8a
    .catchall {:try_start_2c .. :try_end_8a} :catchall_6b

    .line 137
    .line 138
    .line 139
    :try_start_8a
    new-instance v4, Ljava/util/zip/GZIPOutputStream;

    .line 140
    .line 141
    invoke-direct {v4, v3}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_8f
    .catchall {:try_start_8a .. :try_end_8f} :catchall_aa

    .line 142
    .line 143
    .line 144
    :try_start_8f
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v2

    .line 148
    const-string v5, "UTF-8"

    .line 149
    .line 150
    invoke-virtual {v2, v5}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    invoke-virtual {v4, v2}, Ljava/io/OutputStream;->write([B)V
    :try_end_9c
    .catchall {:try_start_8f .. :try_end_9c} :catchall_ac

    .line 155
    .line 156
    .line 157
    :try_start_9c
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_9f
    .catchall {:try_start_9c .. :try_end_9f} :catchall_aa

    .line 158
    .line 159
    .line 160
    :try_start_9f
    invoke-virtual {v3}, Landroid/util/Base64OutputStream;->close()V

    .line 161
    .line 162
    .line 163
    const-string v2, "UTF-8"

    .line 164
    .line 165
    invoke-virtual {v1, v2}, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    monitor-exit v0
    :try_end_a9
    .catchall {:try_start_9f .. :try_end_a9} :catchall_6b

    .line 170
    return-object v1

    .line 171
    :catchall_aa
    move-exception v1

    .line 172
    goto :goto_b6

    .line 173
    :catchall_ac
    move-exception v1

    .line 174
    :try_start_ad
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_b0
    .catchall {:try_start_ad .. :try_end_b0} :catchall_b1

    .line 175
    .line 176
    .line 177
    goto :goto_b5

    .line 178
    :catchall_b1
    move-exception v2

    .line 179
    :try_start_b2
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 180
    .line 181
    .line 182
    :goto_b5
    throw v1
    :try_end_b6
    .catchall {:try_start_b2 .. :try_end_b6} :catchall_aa

    .line 183
    :goto_b6
    :try_start_b6
    invoke-virtual {v3}, Landroid/util/Base64OutputStream;->close()V
    :try_end_b9
    .catchall {:try_start_b6 .. :try_end_b9} :catchall_ba

    .line 184
    .line 185
    .line 186
    goto :goto_be

    .line 187
    :catchall_ba
    move-exception v2

    .line 188
    :try_start_bb
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 189
    .line 190
    .line 191
    :goto_be
    throw v1

    .line 192
    :goto_bf
    monitor-exit v0
    :try_end_c0
    .catchall {:try_start_bb .. :try_end_c0} :catchall_6b

    .line 193
    throw v1

    .line 194
    nop

    .line 195
    :pswitch_data_c2
    .packed-switch 0x0
        :pswitch_29
    .end packed-switch
.end method
