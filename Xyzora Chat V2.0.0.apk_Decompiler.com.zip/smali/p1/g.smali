###### Class p051p1.g (p1.g)
.class public interface abstract Lp1/g;
.super Ljava/lang/Object;
.source "SourceFile"
