###### Class p051p1.f (p1.f)
.class public interface abstract Lp1/f;
.super Ljava/lang/Object;
.source "SourceFile"
