###### Class p051p1.d (p1.d)
.class public final Lp1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp1/f;
.implements Lp1/g;


# instance fields
.field public final a:Ld1/c;

.field public final b:Landroid/content/Context;

.field public final c:Lr1/a;

.field public final d:Ljava/util/Set;

.field public final e:Ljava/util/concurrent/Executor;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lr1/a;Ljava/util/concurrent/Executor;)V
    .registers 7

    .line 1
    new-instance v0, Ld1/c;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2}, Ld1/c;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lp1/d;->a:Ld1/c;

    .line 10
    .line 11
    iput-object p3, p0, Lp1/d;->d:Ljava/util/Set;

    .line 12
    .line 13
    iput-object p5, p0, Lp1/d;->e:Ljava/util/concurrent/Executor;

    .line 14
    .line 15
    iput-object p4, p0, Lp1/d;->c:Lr1/a;

    .line 16
    .line 17
    iput-object p1, p0, Lp1/d;->b:Landroid/content/Context;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final a()Lc1/p;
    .registers 3

    .line 1
    const-class v0, Landroid/os/UserManager;

    .line 2
    .line 3
    iget-object v1, p0, Lp1/d;->b:Landroid/content/Context;

    .line 4
    .line 5
    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Landroid/os/UserManager;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/os/UserManager;->isUserUnlocked()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_17

    .line 16
    .line 17
    const-string v0, ""

    .line 18
    .line 19
    invoke-static {v0}, LO2/a;->q(Ljava/lang/Object;)Lc1/p;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    return-object v0

    .line 24
    :cond_17
    new-instance v0, Lp1/c;

    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    invoke-direct {v0, p0, v1}, Lp1/c;-><init>(Lp1/d;I)V

    .line 28
    .line 29
    .line 30
    iget-object v1, p0, Lp1/d;->e:Ljava/util/concurrent/Executor;

    .line 31
    .line 32
    invoke-static {v1, v0}, LO2/a;->d(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lc1/p;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    return-object v0
.end method

.method public final b()V
    .registers 4

    .line 1
    iget-object v0, p0, Lp1/d;->d:Ljava/util/Set;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/Set;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-gtz v0, :cond_d

    .line 9
    .line 10
    invoke-static {v1}, LO2/a;->q(Ljava/lang/Object;)Lc1/p;

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    const-class v0, Landroid/os/UserManager;

    .line 15
    .line 16
    iget-object v2, p0, Lp1/d;->b:Landroid/content/Context;

    .line 17
    .line 18
    invoke-virtual {v2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Landroid/os/UserManager;

    .line 23
    .line 24
    invoke-virtual {v0}, Landroid/os/UserManager;->isUserUnlocked()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_21

    .line 29
    .line 30
    invoke-static {v1}, LO2/a;->q(Ljava/lang/Object;)Lc1/p;

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_21
    new-instance v0, Lp1/c;

    .line 35
    .line 36
    const/4 v1, 0x1

    .line 37
    invoke-direct {v0, p0, v1}, Lp1/c;-><init>(Lp1/d;I)V

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, Lp1/d;->e:Ljava/util/concurrent/Executor;

    .line 41
    .line 42
    invoke-static {v1, v0}, LO2/a;->d(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lc1/p;

    .line 43
    .line 44
    .line 45
    return-void
.end method
