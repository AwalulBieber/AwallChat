###### Class j$.time.format.z (j$.time.format.z)
.class public final enum Lj$/time/format/z;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum ALWAYS:Lj$/time/format/z;

.field public static final enum EXCEEDS_PAD:Lj$/time/format/z;

.field public static final enum NEVER:Lj$/time/format/z;

.field public static final enum NORMAL:Lj$/time/format/z;

.field public static final enum NOT_NEGATIVE:Lj$/time/format/z;

.field private static final synthetic a:[Lj$/time/format/z;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    .line 84
    new-instance v0, Lj$/time/format/z;

    .line 76
    const-string v1, "NORMAL"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 84
    sput-object v0, Lj$/time/format/z;->NORMAL:Lj$/time/format/z;

    .line 92
    new-instance v1, Lj$/time/format/z;

    .line 76
    const-string v2, "ALWAYS"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 92
    sput-object v1, Lj$/time/format/z;->ALWAYS:Lj$/time/format/z;

    .line 99
    new-instance v2, Lj$/time/format/z;

    .line 76
    const-string v3, "NEVER"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 99
    sput-object v2, Lj$/time/format/z;->NEVER:Lj$/time/format/z;

    .line 106
    new-instance v3, Lj$/time/format/z;

    .line 76
    const-string v4, "NOT_NEGATIVE"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 106
    sput-object v3, Lj$/time/format/z;->NOT_NEGATIVE:Lj$/time/format/z;

    .line 115
    new-instance v4, Lj$/time/format/z;

    .line 76
    const-string v5, "EXCEEDS_PAD"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 115
    sput-object v4, Lj$/time/format/z;->EXCEEDS_PAD:Lj$/time/format/z;

    .line 76
    filled-new-array {v0, v1, v2, v3, v4}, [Lj$/time/format/z;

    move-result-object v0

    sput-object v0, Lj$/time/format/z;->a:[Lj$/time/format/z;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lj$/time/format/z;
    .registers 2

    .line 76
    const-class v0, Lj$/time/format/z;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lj$/time/format/z;

    return-object p0
.end method

.method public static values()[Lj$/time/format/z;
    .registers 1

    .line 76
    sget-object v0, Lj$/time/format/z;->a:[Lj$/time/format/z;

    invoke-virtual {v0}, [Lj$/time/format/z;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lj$/time/format/z;

    return-object v0
.end method
