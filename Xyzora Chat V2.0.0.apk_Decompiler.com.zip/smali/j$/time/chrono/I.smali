###### Class j$.time.chrono.I (j$.time.chrono.I)
.class public final Lj$/time/chrono/I;
.super Lj$/time/chrono/d;
.source "SourceFile"


# static fields
.field private static final serialVersionUID:J = -0x790bcfffa3423007L


# instance fields
.field private final transient a:Lj$/time/h;


# direct methods
.method constructor <init>(Lj$/time/h;)V
    .registers 3

    .line 212
    invoke-direct {p0}, Lj$/time/chrono/d;-><init>()V

    .line 213
    const-string v0, "isoDate"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    .line 214
    iput-object p1, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    return-void
.end method

.method private T()I
    .registers 2

    .line 306
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0}, Lj$/time/h;->b0()I

    move-result v0

    add-int/lit16 v0, v0, 0x21f

    return v0
.end method

.method private Z(Lj$/time/h;)Lj$/time/chrono/I;
    .registers 3

    .line 422
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {p1, v0}, Lj$/time/h;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-object p0

    :cond_9
    new-instance v0, Lj$/time/chrono/I;

    invoke-direct {v0, p1}, Lj$/time/chrono/I;-><init>(Lj$/time/h;)V

    return-object v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 3

    .line 485
    new-instance p1, Ljava/io/InvalidObjectException;

    const-string v0, "Deserialization via serialization delegate"

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    .line 502
    new-instance v0, Lj$/time/chrono/E;

    const/16 v1, 0x8

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/E;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method final C(J)Lj$/time/chrono/b;
    .registers 4

    .line 388
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0, p1, p2}, Lj$/time/h;->l0(J)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1
.end method

.method final J(J)Lj$/time/chrono/b;
    .registers 4

    .line 378
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0, p1, p2}, Lj$/time/h;->m0(J)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1
.end method

.method public final K(Lj$/time/l;)Lj$/time/chrono/e;
    .registers 2

    .line 657
    invoke-static {p0, p1}, Lj$/time/chrono/g;->C(Lj$/time/chrono/b;Lj$/time/l;)Lj$/time/chrono/g;

    move-result-object p1

    return-object p1
.end method

.method public final M(Lj$/time/temporal/q;)Lj$/time/chrono/b;
    .registers 2

    .line 357
    invoke-super {p0, p1}, Lj$/time/chrono/d;->M(Lj$/time/temporal/q;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method final S(J)Lj$/time/chrono/b;
    .registers 4

    .line 373
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0, p1, p2}, Lj$/time/h;->o0(J)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1
.end method

.method public final W(JLj$/time/temporal/r;)Lj$/time/chrono/I;
    .registers 12

    .line 312
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_99

    .line 313
    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    .line 314
    invoke-virtual {p0, v0}, Lj$/time/chrono/I;->g(Lj$/time/temporal/r;)J

    move-result-wide v1

    cmp-long v1, v1, p1

    if-nez v1, :cond_10

    return-object p0

    .line 317
    :cond_10
    sget-object v1, Lj$/time/chrono/H;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v2, v1, v2

    iget-object v3, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eq v2, v6, :cond_4b

    const/4 v7, 0x5

    if-eq v2, v7, :cond_27

    if-eq v2, v5, :cond_4b

    if-eq v2, v4, :cond_4b

    goto :goto_61

    .line 228
    :cond_27
    sget-object p3, Lj$/time/chrono/G;->d:Lj$/time/chrono/G;

    .line 319
    invoke-virtual {p3, v0}, Lj$/time/chrono/G;->U(Lj$/time/temporal/a;)Lj$/time/temporal/w;

    move-result-object p3

    invoke-virtual {p3, p1, p2, v0}, Lj$/time/temporal/w;->b(JLj$/time/temporal/r;)V

    .line 302
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result p3

    int-to-long v0, p3

    const-wide/16 v4, 0xc

    mul-long/2addr v0, v4

    invoke-virtual {v3}, Lj$/time/h;->a0()I

    move-result p3

    int-to-long v4, p3

    add-long/2addr v0, v4

    const-wide/16 v4, 0x1

    sub-long/2addr v0, v4

    sub-long/2addr p1, v0

    .line 378
    invoke-virtual {v3, p1, p2}, Lj$/time/h;->m0(J)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1

    .line 228
    :cond_4b
    sget-object v2, Lj$/time/chrono/G;->d:Lj$/time/chrono/G;

    .line 324
    invoke-virtual {v2, v0}, Lj$/time/chrono/G;->U(Lj$/time/temporal/a;)Lj$/time/temporal/w;

    move-result-object v2

    invoke-virtual {v2, p1, p2, v0}, Lj$/time/temporal/w;->a(JLj$/time/temporal/r;)I

    move-result v2

    .line 325
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    if-eq v0, v6, :cond_84

    if-eq v0, v5, :cond_79

    if-eq v0, v4, :cond_6a

    .line 335
    :goto_61
    invoke-virtual {v3, p1, p2, p3}, Lj$/time/h;->q0(JLj$/time/temporal/r;)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1

    .line 331
    :cond_6a
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result p1

    rsub-int p1, p1, -0x21e

    invoke-virtual {v3, p1}, Lj$/time/h;->t0(I)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1

    :cond_79
    add-int/lit16 v2, v2, -0x21f

    .line 329
    invoke-virtual {v3, v2}, Lj$/time/h;->t0(I)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1

    .line 327
    :cond_84
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result p1

    const/4 p2, 0x1

    if-lt p1, p2, :cond_8c

    goto :goto_8e

    :cond_8c
    rsub-int/lit8 v2, v2, 0x1

    :goto_8e
    add-int/lit16 v2, v2, -0x21f

    invoke-virtual {v3, v2}, Lj$/time/h;->t0(I)Lj$/time/h;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/I;->Z(Lj$/time/h;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1

    .line 337
    :cond_99
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->b(JLj$/time/temporal/r;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method public final bridge synthetic b(JLj$/time/temporal/r;)Lj$/time/chrono/b;
    .registers 4

    .line 106
    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/I;->W(JLj$/time/temporal/r;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1
.end method

.method public final bridge synthetic b(JLj$/time/temporal/r;)Lj$/time/temporal/m;
    .registers 4

    .line 106
    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/I;->W(JLj$/time/temporal/r;)Lj$/time/chrono/I;

    move-result-object p1

    return-object p1
.end method

.method public final d(JLj$/time/temporal/u;)Lj$/time/chrono/b;
    .registers 4

    .line 393
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->d(JLj$/time/temporal/u;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method public final d(JLj$/time/temporal/u;)Lj$/time/temporal/m;
    .registers 4

    .line 393
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->d(JLj$/time/temporal/u;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method public final e(JLj$/time/temporal/u;)Lj$/time/chrono/b;
    .registers 4

    .line 398
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->e(JLj$/time/temporal/u;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method public final e(JLj$/time/temporal/u;)Lj$/time/temporal/m;
    .registers 4

    .line 398
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->e(JLj$/time/temporal/u;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    .line 460
    :cond_4
    instance-of v0, p1, Lj$/time/chrono/I;

    if-eqz v0, :cond_13

    .line 461
    check-cast p1, Lj$/time/chrono/I;

    .line 462
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    iget-object p1, p1, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0, p1}, Lj$/time/h;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1

    :cond_13
    const/4 p1, 0x0

    return p1
.end method

.method public final g(Lj$/time/temporal/r;)J
    .registers 8

    .line 283
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_50

    .line 284
    sget-object v0, Lj$/time/chrono/H;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eq v0, v1, :cond_45

    const/4 v1, 0x5

    iget-object v3, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    if-eq v0, v1, :cond_33

    const/4 v1, 0x6

    if-eq v0, v1, :cond_2d

    const/4 v1, 0x7

    if-eq v0, v1, :cond_23

    .line 296
    invoke-virtual {v3, p1}, Lj$/time/h;->g(Lj$/time/temporal/r;)J

    move-result-wide v0

    return-wide v0

    .line 294
    :cond_23
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result p1

    if-lt p1, v2, :cond_2a

    goto :goto_2b

    :cond_2a
    const/4 v2, 0x0

    :goto_2b
    int-to-long v0, v2

    return-wide v0

    .line 292
    :cond_2d
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result p1

    int-to-long v0, p1

    return-wide v0

    .line 302
    :cond_33
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result p1

    int-to-long v0, p1

    const-wide/16 v4, 0xc

    mul-long/2addr v0, v4

    invoke-virtual {v3}, Lj$/time/h;->a0()I

    move-result p1

    int-to-long v2, p1

    add-long/2addr v0, v2

    const-wide/16 v2, 0x1

    sub-long/2addr v0, v2

    return-wide v0

    .line 288
    :cond_45
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result p1

    if-lt p1, v2, :cond_4c

    goto :goto_4e

    :cond_4c
    rsub-int/lit8 p1, p1, 0x1

    :goto_4e
    int-to-long v0, p1

    return-wide v0

    .line 298
    :cond_50
    invoke-interface {p1, p0}, Lj$/time/temporal/r;->r(Lj$/time/temporal/TemporalAccessor;)J

    move-result-wide v0

    return-wide v0
.end method

.method public final h()Lj$/time/chrono/l;
    .registers 2

    .line 228
    sget-object v0, Lj$/time/chrono/G;->d:Lj$/time/chrono/G;

    return-object v0
.end method

.method public final hashCode()I
    .registers 3

    .line 228
    sget-object v0, Lj$/time/chrono/G;->d:Lj$/time/chrono/G;

    .line 474
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0}, Lj$/time/h;->hashCode()I

    move-result v0

    const v1, 0x8b59791

    xor-int/2addr v0, v1

    return v0
.end method

.method public final j(Lj$/time/h;)Lj$/time/temporal/m;
    .registers 2

    .line 347
    invoke-super {p0, p1}, Lj$/time/chrono/d;->m(Lj$/time/temporal/n;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method public final l(Lj$/time/temporal/r;)Lj$/time/temporal/w;
    .registers 9

    .line 260
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_5d

    .line 261
    invoke-interface {p0, p1}, Lj$/time/chrono/b;->f(Lj$/time/temporal/r;)Z

    move-result v0

    if-eqz v0, :cond_51

    .line 262
    move-object v0, p1

    check-cast v0, Lj$/time/temporal/a;

    .line 263
    sget-object v1, Lj$/time/chrono/H;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v1, v1, v2

    const/4 v2, 0x1

    if-eq v1, v2, :cond_4a

    const/4 v2, 0x2

    if-eq v1, v2, :cond_4a

    const/4 v2, 0x3

    if-eq v1, v2, :cond_4a

    const/4 p1, 0x4

    if-eq v1, p1, :cond_28

    .line 228
    sget-object p1, Lj$/time/chrono/G;->d:Lj$/time/chrono/G;

    .line 274
    invoke-virtual {p1, v0}, Lj$/time/chrono/G;->U(Lj$/time/temporal/a;)Lj$/time/temporal/w;

    move-result-object p1

    return-object p1

    .line 269
    :cond_28
    sget-object p1, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-virtual {p1}, Lj$/time/temporal/a;->C()Lj$/time/temporal/w;

    move-result-object p1

    .line 270
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result v0

    const-wide/16 v1, 0x1

    const-wide/16 v3, 0x21f

    if-gtz v0, :cond_40

    invoke-virtual {p1}, Lj$/time/temporal/w;->e()J

    move-result-wide v5

    add-long/2addr v5, v3

    neg-long v3, v5

    add-long/2addr v3, v1

    goto :goto_45

    :cond_40
    invoke-virtual {p1}, Lj$/time/temporal/w;->d()J

    move-result-wide v5

    add-long/2addr v3, v5

    .line 271
    :goto_45
    invoke-static {v1, v2, v3, v4}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object p1

    return-object p1

    .line 267
    :cond_4a
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0, p1}, Lj$/time/h;->l(Lj$/time/temporal/r;)Lj$/time/temporal/w;

    move-result-object p1

    return-object p1

    .line 276
    :cond_51
    new-instance v0, Lj$/time/temporal/v;

    const-string v1, "Unsupported field: "

    .line 0
    invoke-static {v1, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/r;)Ljava/lang/String;

    move-result-object p1

    .line 88
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 276
    throw v0

    .line 278
    :cond_5d
    invoke-interface {p1, p0}, Lj$/time/temporal/r;->J(Lj$/time/temporal/TemporalAccessor;)Lj$/time/temporal/w;

    move-result-object p1

    return-object p1
.end method

.method public final m(Lj$/time/temporal/n;)Lj$/time/chrono/b;
    .registers 2

    .line 347
    invoke-super {p0, p1}, Lj$/time/chrono/d;->m(Lj$/time/temporal/n;)Lj$/time/chrono/b;

    move-result-object p1

    check-cast p1, Lj$/time/chrono/I;

    return-object p1
.end method

.method public final u()Lj$/time/chrono/m;
    .registers 3

    .line 241
    invoke-direct {p0}, Lj$/time/chrono/I;->T()I

    move-result v0

    const/4 v1, 0x1

    if-lt v0, v1, :cond_a

    sget-object v0, Lj$/time/chrono/J;->BE:Lj$/time/chrono/J;

    return-object v0

    :cond_a
    sget-object v0, Lj$/time/chrono/J;->BEFORE_BE:Lj$/time/chrono/J;

    return-object v0
.end method

.method public final v()J
    .registers 3

    .line 439
    iget-object v0, p0, Lj$/time/chrono/I;->a:Lj$/time/h;

    invoke-virtual {v0}, Lj$/time/h;->v()J

    move-result-wide v0

    return-wide v0
.end method
