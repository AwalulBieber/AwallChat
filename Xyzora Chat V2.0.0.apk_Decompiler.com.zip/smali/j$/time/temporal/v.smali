###### Class j$.time.temporal.v (j$.time.temporal.v)
.class public final Lj$/time/temporal/v;
.super Lj$/time/c;
.source "SourceFile"


# static fields
.field private static final serialVersionUID:J = -0x5578cd7fadb7ecb6L
