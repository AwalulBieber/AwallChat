###### Class j$.time.temporal.t (j$.time.temporal.t)
.class public interface abstract Lj$/time/temporal/t;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract j(Lj$/time/temporal/TemporalAccessor;)Ljava/lang/Object;
.end method
