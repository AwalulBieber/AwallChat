###### Class j$.time.temporal.a (j$.time.temporal.a)
.class public final enum Lj$/time/temporal/a;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Lj$/time/temporal/r;


# static fields
.field public static final enum ALIGNED_DAY_OF_WEEK_IN_MONTH:Lj$/time/temporal/a;

.field public static final enum ALIGNED_DAY_OF_WEEK_IN_YEAR:Lj$/time/temporal/a;

.field public static final enum ALIGNED_WEEK_OF_MONTH:Lj$/time/temporal/a;

.field public static final enum ALIGNED_WEEK_OF_YEAR:Lj$/time/temporal/a;

.field public static final enum AMPM_OF_DAY:Lj$/time/temporal/a;

.field public static final enum CLOCK_HOUR_OF_AMPM:Lj$/time/temporal/a;

.field public static final enum CLOCK_HOUR_OF_DAY:Lj$/time/temporal/a;

.field public static final enum DAY_OF_MONTH:Lj$/time/temporal/a;

.field public static final enum DAY_OF_WEEK:Lj$/time/temporal/a;

.field public static final enum DAY_OF_YEAR:Lj$/time/temporal/a;

.field public static final enum EPOCH_DAY:Lj$/time/temporal/a;

.field public static final enum ERA:Lj$/time/temporal/a;

.field public static final enum HOUR_OF_AMPM:Lj$/time/temporal/a;

.field public static final enum HOUR_OF_DAY:Lj$/time/temporal/a;

.field public static final enum INSTANT_SECONDS:Lj$/time/temporal/a;

.field public static final enum MICRO_OF_DAY:Lj$/time/temporal/a;

.field public static final enum MICRO_OF_SECOND:Lj$/time/temporal/a;

.field public static final enum MILLI_OF_DAY:Lj$/time/temporal/a;

.field public static final enum MILLI_OF_SECOND:Lj$/time/temporal/a;

.field public static final enum MINUTE_OF_DAY:Lj$/time/temporal/a;

.field public static final enum MINUTE_OF_HOUR:Lj$/time/temporal/a;

.field public static final enum MONTH_OF_YEAR:Lj$/time/temporal/a;

.field public static final enum NANO_OF_DAY:Lj$/time/temporal/a;

.field public static final enum NANO_OF_SECOND:Lj$/time/temporal/a;

.field public static final enum OFFSET_SECONDS:Lj$/time/temporal/a;

.field public static final enum PROLEPTIC_MONTH:Lj$/time/temporal/a;

.field public static final enum SECOND_OF_DAY:Lj$/time/temporal/a;

.field public static final enum SECOND_OF_MINUTE:Lj$/time/temporal/a;

.field public static final enum YEAR:Lj$/time/temporal/a;

.field public static final enum YEAR_OF_ERA:Lj$/time/temporal/a;

.field private static final synthetic c:[Lj$/time/temporal/a;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Lj$/time/temporal/w;


# direct methods
.method static constructor <clinit>()V
    .registers 43

    .line 120
    new-instance v1, Lj$/time/temporal/a;

    sget-object v0, Lj$/time/temporal/b;->NANOS:Lj$/time/temporal/b;

    const-wide/16 v2, 0x0

    const-wide/32 v4, 0x3b9ac9ff

    invoke-static {v2, v3, v4, v5}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v0

    const/4 v6, 0x0

    const-string v7, "NanoOfSecond"

    const-string v8, "NANO_OF_SECOND"

    invoke-direct {v1, v8, v6, v7, v0}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v1, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    .line 136
    new-instance v0, Lj$/time/temporal/a;

    const-wide v6, 0x4e94914effffL

    invoke-static {v2, v3, v6, v7}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v6

    const/4 v7, 0x1

    const-string v8, "NanoOfDay"

    const-string v9, "NANO_OF_DAY"

    invoke-direct {v0, v9, v7, v8, v6}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v0, Lj$/time/temporal/a;->NANO_OF_DAY:Lj$/time/temporal/a;

    .line 156
    new-instance v6, Lj$/time/temporal/a;

    const-wide/32 v7, 0xf423f

    invoke-static {v2, v3, v7, v8}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v7

    const/4 v8, 0x2

    const-string v9, "MicroOfSecond"

    const-string v10, "MICRO_OF_SECOND"

    invoke-direct {v6, v10, v8, v9, v7}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v6, Lj$/time/temporal/a;->MICRO_OF_SECOND:Lj$/time/temporal/a;

    .line 175
    new-instance v7, Lj$/time/temporal/a;

    const-wide v8, 0x141dd75fffL

    invoke-static {v2, v3, v8, v9}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v8

    const/4 v9, 0x3

    const-string v10, "MicroOfDay"

    const-string v11, "MICRO_OF_DAY"

    invoke-direct {v7, v11, v9, v10, v8}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v7, Lj$/time/temporal/a;->MICRO_OF_DAY:Lj$/time/temporal/a;

    .line 195
    new-instance v8, Lj$/time/temporal/a;

    const-wide/16 v9, 0x3e7

    invoke-static {v2, v3, v9, v10}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v9

    const/4 v10, 0x4

    const-string v11, "MilliOfSecond"

    const-string v12, "MILLI_OF_SECOND"

    invoke-direct {v8, v12, v10, v11, v9}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v8, Lj$/time/temporal/a;->MILLI_OF_SECOND:Lj$/time/temporal/a;

    move-object v9, v6

    .line 214
    new-instance v6, Lj$/time/temporal/a;

    const-wide/32 v10, 0x5265bff

    invoke-static {v2, v3, v10, v11}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v10

    const/4 v11, 0x5

    const-string v12, "MilliOfDay"

    const-string v13, "MILLI_OF_DAY"

    invoke-direct {v6, v13, v11, v12, v10}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v6, Lj$/time/temporal/a;->MILLI_OF_DAY:Lj$/time/temporal/a;

    .line 224
    new-instance v14, Lj$/time/temporal/a;

    const-wide/16 v10, 0x3b

    invoke-static {v2, v3, v10, v11}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v18

    const-string v17, "SecondOfMinute"

    const/16 v19, 0x0

    const-string v15, "SECOND_OF_MINUTE"

    const/16 v16, 0x6

    invoke-direct/range {v14 .. v19}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v14, Lj$/time/temporal/a;->SECOND_OF_MINUTE:Lj$/time/temporal/a;

    move-object v12, v8

    .line 236
    new-instance v8, Lj$/time/temporal/a;

    const-wide/32 v4, 0x1517f

    invoke-static {v2, v3, v4, v5}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v4

    const/4 v5, 0x7

    const-string v13, "SecondOfDay"

    const-string v15, "SECOND_OF_DAY"

    invoke-direct {v8, v15, v5, v13, v4}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v8, Lj$/time/temporal/a;->SECOND_OF_DAY:Lj$/time/temporal/a;

    .line 246
    new-instance v19, Lj$/time/temporal/a;

    invoke-static {v2, v3, v10, v11}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v23

    const-string v22, "MinuteOfHour"

    const/16 v24, 0x0

    const-string v20, "MINUTE_OF_HOUR"

    const/16 v21, 0x8

    invoke-direct/range {v19 .. v24}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v19, Lj$/time/temporal/a;->MINUTE_OF_HOUR:Lj$/time/temporal/a;

    .line 257
    new-instance v10, Lj$/time/temporal/a;

    const-wide/16 v4, 0x59f

    invoke-static {v2, v3, v4, v5}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v4

    const/16 v5, 0x9

    const-string v11, "MinuteOfDay"

    const-string v13, "MINUTE_OF_DAY"

    invoke-direct {v10, v13, v5, v11, v4}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v10, Lj$/time/temporal/a;->MINUTE_OF_DAY:Lj$/time/temporal/a;

    .line 273
    new-instance v11, Lj$/time/temporal/a;

    const-wide/16 v4, 0xb

    invoke-static {v2, v3, v4, v5}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v4

    const/16 v5, 0xa

    const-string v13, "HourOfAmPm"

    const-string v15, "HOUR_OF_AMPM"

    invoke-direct {v11, v15, v5, v13, v4}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v11, Lj$/time/temporal/a;->HOUR_OF_AMPM:Lj$/time/temporal/a;

    move-object v5, v12

    .line 289
    new-instance v12, Lj$/time/temporal/a;

    const-wide/16 v2, 0x1

    move-object v13, v0

    move-object v4, v1

    const-wide/16 v0, 0xc

    invoke-static {v2, v3, v0, v1}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v15

    const/16 v0, 0xb

    const-string v1, "ClockHourOfAmPm"

    const-string v2, "CLOCK_HOUR_OF_AMPM"

    invoke-direct {v12, v2, v0, v1, v15}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v12, Lj$/time/temporal/a;->CLOCK_HOUR_OF_AMPM:Lj$/time/temporal/a;

    .line 306
    new-instance v26, Lj$/time/temporal/a;

    const-wide/16 v0, 0x17

    const-wide/16 v2, 0x0

    invoke-static {v2, v3, v0, v1}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v30

    const-string v29, "HourOfDay"

    const/16 v31, 0x0

    const-string v27, "HOUR_OF_DAY"

    const/16 v28, 0xc

    invoke-direct/range {v26 .. v31}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v26, Lj$/time/temporal/a;->HOUR_OF_DAY:Lj$/time/temporal/a;

    move-object v1, v4

    move-object v4, v7

    move-object v7, v14

    .line 322
    new-instance v14, Lj$/time/temporal/a;

    const-wide/16 v2, 0x18

    move-object/from16 v20, v1

    const-wide/16 v0, 0x1

    invoke-static {v0, v1, v2, v3}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v2

    const/16 v3, 0xd

    const-string v15, "ClockHourOfDay"

    const-string v0, "CLOCK_HOUR_OF_DAY"

    invoke-direct {v14, v0, v3, v15, v2}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v14, Lj$/time/temporal/a;->CLOCK_HOUR_OF_DAY:Lj$/time/temporal/a;

    .line 335
    new-instance v29, Lj$/time/temporal/a;

    const-wide/16 v0, 0x1

    const-wide/16 v2, 0x0

    invoke-static {v2, v3, v0, v1}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v33

    const-string v32, "AmPmOfDay"

    const/16 v34, 0x0

    const-string v30, "AMPM_OF_DAY"

    const/16 v31, 0xe

    invoke-direct/range {v29 .. v34}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v29, Lj$/time/temporal/a;->AMPM_OF_DAY:Lj$/time/temporal/a;

    .line 351
    new-instance v30, Lj$/time/temporal/a;

    const-wide/16 v2, 0x7

    invoke-static {v0, v1, v2, v3}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v34

    const-string v33, "DayOfWeek"

    const/16 v35, 0x0

    const-string v31, "DAY_OF_WEEK"

    const/16 v32, 0xf

    invoke-direct/range {v30 .. v35}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v30, Lj$/time/temporal/a;->DAY_OF_WEEK:Lj$/time/temporal/a;

    .line 369
    new-instance v15, Lj$/time/temporal/a;

    move-object/from16 v16, v4

    invoke-static {v0, v1, v2, v3}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v4

    const/16 v0, 0x10

    const-string v1, "AlignedDayOfWeekInMonth"

    const-string v2, "ALIGNED_DAY_OF_WEEK_IN_MONTH"

    invoke-direct {v15, v2, v0, v1, v4}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v15, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_MONTH:Lj$/time/temporal/a;

    .line 387
    new-instance v0, Lj$/time/temporal/a;

    const-wide/16 v1, 0x1

    const-wide/16 v3, 0x7

    invoke-static {v1, v2, v3, v4}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v3

    const/16 v1, 0x11

    const-string v2, "AlignedDayOfWeekInYear"

    const-string v4, "ALIGNED_DAY_OF_WEEK_IN_YEAR"

    invoke-direct {v0, v4, v1, v2, v3}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v0, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_YEAR:Lj$/time/temporal/a;

    .line 400
    new-instance v31, Lj$/time/temporal/a;

    const-wide/16 v1, 0x1c

    const-wide/16 v3, 0x1f

    .line 147
    invoke-static {v1, v2, v3, v4}, Lj$/time/temporal/w;->k(JJ)Lj$/time/temporal/w;

    move-result-object v35

    .line 400
    const-string v34, "DayOfMonth"

    const/16 v36, 0x0

    const-string v32, "DAY_OF_MONTH"

    const/16 v33, 0x12

    invoke-direct/range {v31 .. v36}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v31, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    .line 418
    new-instance v1, Lj$/time/temporal/a;

    const-wide/16 v2, 0x16d

    move-object/from16 v21, v5

    const-wide/16 v4, 0x16e

    .line 147
    invoke-static {v2, v3, v4, v5}, Lj$/time/temporal/w;->k(JJ)Lj$/time/temporal/w;

    move-result-object v2

    const/16 v3, 0x13

    .line 418
    const-string v4, "DayOfYear"

    const-string v5, "DAY_OF_YEAR"

    invoke-direct {v1, v5, v3, v4, v2}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v1, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    .line 431
    new-instance v2, Lj$/time/temporal/a;

    const-wide v3, -0x550a313cdaL

    move-object v5, v0

    move-object/from16 v32, v1

    const-wide v0, 0x550a1b48f7L

    invoke-static {v3, v4, v0, v1}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v0

    const/16 v1, 0x14

    const-string v3, "EpochDay"

    const-string v4, "EPOCH_DAY"

    invoke-direct {v2, v4, v1, v3, v0}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v2, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    .line 447
    new-instance v0, Lj$/time/temporal/a;

    const-wide/16 v3, 0x4

    move-object/from16 v33, v2

    const-wide/16 v1, 0x5

    .line 147
    invoke-static {v3, v4, v1, v2}, Lj$/time/temporal/w;->k(JJ)Lj$/time/temporal/w;

    move-result-object v1

    const/16 v2, 0x15

    .line 447
    const-string v3, "AlignedWeekOfMonth"

    const-string v4, "ALIGNED_WEEK_OF_MONTH"

    invoke-direct {v0, v4, v2, v3, v1}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v0, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_MONTH:Lj$/time/temporal/a;

    .line 463
    new-instance v1, Lj$/time/temporal/a;

    const-wide/16 v2, 0x35

    move-object/from16 v34, v5

    const-wide/16 v4, 0x1

    invoke-static {v4, v5, v2, v3}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v2

    const/16 v3, 0x16

    const-string v4, "AlignedWeekOfYear"

    const-string v5, "ALIGNED_WEEK_OF_YEAR"

    invoke-direct {v1, v5, v3, v4, v2}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v1, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_YEAR:Lj$/time/temporal/a;

    .line 474
    new-instance v35, Lj$/time/temporal/a;

    const-wide/16 v2, 0xc

    const-wide/16 v4, 0x1

    invoke-static {v4, v5, v2, v3}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v39

    const-string v38, "MonthOfYear"

    const/16 v40, 0x0

    const-string v36, "MONTH_OF_YEAR"

    const/16 v37, 0x17

    invoke-direct/range {v35 .. v40}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v35, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    .line 494
    new-instance v2, Lj$/time/temporal/a;

    const-wide v3, -0x2cb4177f4L

    move-object/from16 v22, v0

    move-object/from16 v23, v1

    const-wide v0, 0x2cb4177ffL

    invoke-static {v3, v4, v0, v1}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v0

    const/16 v1, 0x18

    const-string v3, "ProlepticMonth"

    const-string v4, "PROLEPTIC_MONTH"

    invoke-direct {v2, v4, v1, v3, v0}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v2, Lj$/time/temporal/a;->PROLEPTIC_MONTH:Lj$/time/temporal/a;

    .line 529
    new-instance v0, Lj$/time/temporal/a;

    const-wide/32 v3, 0x3b9aca00

    move-object v5, v2

    const-wide/32 v1, 0x3b9ac9ff

    .line 147
    invoke-static {v1, v2, v3, v4}, Lj$/time/temporal/w;->k(JJ)Lj$/time/temporal/w;

    move-result-object v3

    const/16 v4, 0x19

    .line 529
    const-string v1, "YearOfEra"

    const-string v2, "YEAR_OF_ERA"

    invoke-direct {v0, v2, v4, v1, v3}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v0, Lj$/time/temporal/a;->YEAR_OF_ERA:Lj$/time/temporal/a;

    .line 553
    new-instance v36, Lj$/time/temporal/a;

    const-wide/32 v1, -0x3b9ac9ff

    const-wide/32 v3, 0x3b9ac9ff

    invoke-static {v1, v2, v3, v4}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v40

    const-string v39, "Year"

    const/16 v41, 0x0

    const-string v37, "YEAR"

    const/16 v38, 0x1a

    invoke-direct/range {v36 .. v41}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v36, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    .line 570
    new-instance v37, Lj$/time/temporal/a;

    move-object v4, v0

    const-wide/16 v0, 0x1

    const-wide/16 v2, 0x0

    invoke-static {v2, v3, v0, v1}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v41

    const-string v40, "Era"

    const/16 v42, 0x0

    const-string v38, "ERA"

    const/16 v39, 0x1b

    invoke-direct/range {v37 .. v42}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V

    sput-object v37, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    .line 585
    new-instance v0, Lj$/time/temporal/a;

    const-wide/high16 v1, -0x8000000000000000L

    move-object/from16 v17, v4

    const-wide v3, 0x7fffffffffffffffL

    invoke-static {v1, v2, v3, v4}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v1

    const/16 v2, 0x1c

    const-string v3, "InstantSeconds"

    const-string v4, "INSTANT_SECONDS"

    invoke-direct {v0, v4, v2, v3, v1}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v0, Lj$/time/temporal/a;->INSTANT_SECONDS:Lj$/time/temporal/a;

    .line 599
    new-instance v1, Lj$/time/temporal/a;

    const-wide/32 v2, -0xfd20

    move-object/from16 v25, v5

    const-wide/32 v4, 0xfd20

    invoke-static {v2, v3, v4, v5}, Lj$/time/temporal/w;->j(JJ)Lj$/time/temporal/w;

    move-result-object v2

    const/16 v3, 0x1d

    const-string v4, "OffsetSeconds"

    const-string v5, "OFFSET_SECONDS"

    invoke-direct {v1, v5, v3, v4, v2}, Lj$/time/temporal/a;-><init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V

    sput-object v1, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    move-object v3, v9

    move-object v2, v13

    move-object/from16 v4, v16

    move-object/from16 v9, v19

    move-object/from16 v5, v21

    move-object/from16 v13, v26

    move-object/from16 v16, v30

    move-object/from16 v19, v31

    move-object/from16 v21, v33

    move-object/from16 v18, v34

    move-object/from16 v24, v35

    move-object/from16 v27, v36

    move-object/from16 v28, v37

    move-object/from16 v30, v1

    move-object/from16 v26, v17

    move-object/from16 v1, v20

    move-object/from16 v20, v32

    move-object/from16 v17, v15

    move-object/from16 v15, v29

    move-object/from16 v29, v0

    .line 98
    filled-new-array/range {v1 .. v30}, [Lj$/time/temporal/a;

    move-result-object v0

    sput-object v0, Lj$/time/temporal/a;->c:[Lj$/time/temporal/a;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;)V
    .registers 5

    .line 607
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 608
    iput-object p3, p0, Lj$/time/temporal/a;->a:Ljava/lang/String;

    .line 611
    iput-object p4, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/w;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Lj$/time/temporal/w;I)V
    .registers 6

    .line 616
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 617
    iput-object p3, p0, Lj$/time/temporal/a;->a:Ljava/lang/String;

    .line 620
    iput-object p4, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/w;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lj$/time/temporal/a;
    .registers 2

    .line 98
    const-class v0, Lj$/time/temporal/a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lj$/time/temporal/a;

    return-object p0
.end method

.method public static values()[Lj$/time/temporal/a;
    .registers 1

    .line 98
    sget-object v0, Lj$/time/temporal/a;->c:[Lj$/time/temporal/a;

    invoke-virtual {v0}, [Lj$/time/temporal/a;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lj$/time/temporal/a;

    return-object v0
.end method


# virtual methods
.method public final C()Lj$/time/temporal/w;
    .registers 2

    .line 669
    iget-object v0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/w;

    return-object v0
.end method

.method public final J(Lj$/time/temporal/TemporalAccessor;)Lj$/time/temporal/w;
    .registers 2

    .line 743
    invoke-interface {p1, p0}, Lj$/time/temporal/TemporalAccessor;->l(Lj$/time/temporal/r;)Lj$/time/temporal/w;

    move-result-object p1

    return-object p1
.end method

.method public final T()Z
    .registers 3

    .line 682
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    sget-object v1, Lj$/time/temporal/a;->DAY_OF_WEEK:Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    if-lt v0, v1, :cond_1a

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    sget-object v1, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    if-gt v0, v1, :cond_1a

    const/4 v0, 0x1

    return v0

    :cond_1a
    const/4 v0, 0x0

    return v0
.end method

.method public final W(Lj$/time/temporal/TemporalAccessor;)Z
    .registers 2

    .line 738
    invoke-interface {p1, p0}, Lj$/time/temporal/TemporalAccessor;->f(Lj$/time/temporal/r;)Z

    move-result p1

    return p1
.end method

.method public final Z(J)I
    .registers 4

    .line 732
    iget-object v0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/w;

    invoke-virtual {v0, p1, p2, p0}, Lj$/time/temporal/w;->a(JLj$/time/temporal/r;)I

    move-result p1

    return p1
.end method

.method public final a0(J)V
    .registers 4

    .line 713
    iget-object v0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/w;

    invoke-virtual {v0, p1, p2, p0}, Lj$/time/temporal/w;->b(JLj$/time/temporal/r;)V

    return-void
.end method

.method public final b0()Z
    .registers 3

    .line 694
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    sget-object v1, Lj$/time/temporal/a;->DAY_OF_WEEK:Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    if-ge v0, v1, :cond_e

    const/4 v0, 0x1

    return v0

    :cond_e
    const/4 v0, 0x0

    return v0
.end method

.method public final p(Lj$/time/temporal/m;J)Lj$/time/temporal/m;
    .registers 4

    .line 754
    invoke-interface {p1, p2, p3, p0}, Lj$/time/temporal/m;->b(JLj$/time/temporal/r;)Lj$/time/temporal/m;

    move-result-object p1

    return-object p1
.end method

.method public final r(Lj$/time/temporal/TemporalAccessor;)J
    .registers 4

    .line 748
    invoke-interface {p1, p0}, Lj$/time/temporal/TemporalAccessor;->g(Lj$/time/temporal/r;)J

    move-result-wide v0

    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    .line 760
    iget-object v0, p0, Lj$/time/temporal/a;->a:Ljava/lang/String;

    return-object v0
.end method
