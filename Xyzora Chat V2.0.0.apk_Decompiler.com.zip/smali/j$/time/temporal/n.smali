###### Class j$.time.temporal.n (j$.time.temporal.n)
.class public interface abstract Lj$/time/temporal/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Lj$/time/temporal/m;)Lj$/time/temporal/m;
.end method
