###### Class J0.d (J0.d)
.class public final LJ0/d;
.super LJ0/e;
.source "SourceFile"


# static fields
.field public static final b:Ljava/lang/Object;

.field public static final c:LJ0/d;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LJ0/d;->b:Ljava/lang/Object;

    .line 7
    .line 8
    new-instance v0, LJ0/d;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, LJ0/d;->c:LJ0/d;

    .line 14
    .line 15
    return-void
.end method

.method public static d(Landroid/app/Activity;ILM0/k;Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog;
    .registers 9

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_4

    .line 3
    .line 4
    return-object v0

    .line 5
    :cond_4
    new-instance v1, Landroid/util/TypedValue;

    .line 6
    .line 7
    invoke-direct {v1}, Landroid/util/TypedValue;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const v3, 0x1010309

    .line 15
    .line 16
    .line 17
    const/4 v4, 0x1

    .line 18
    invoke-virtual {v2, v3, v1, v4}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    iget v1, v1, Landroid/util/TypedValue;->resourceId:I

    .line 26
    .line 27
    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-string v2, "Theme.Dialog.Alert"

    .line 32
    .line 33
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-eqz v1, :cond_2c

    .line 38
    .line 39
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 40
    .line 41
    const/4 v1, 0x5

    .line 42
    invoke-direct {v0, p0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    .line 43
    .line 44
    .line 45
    :cond_2c
    if-nez v0, :cond_33

    .line 46
    .line 47
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 48
    .line 49
    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 50
    .line 51
    .line 52
    :cond_33
    invoke-static {p0, p1}, LM0/j;->b(Landroid/content/Context;I)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 57
    .line 58
    .line 59
    if-eqz p3, :cond_3f

    .line 60
    .line 61
    invoke-virtual {v0, p3}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    .line 62
    .line 63
    .line 64
    :cond_3f
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 65
    .line 66
    .line 67
    move-result-object p3

    .line 68
    if-eq p1, v4, :cond_63

    .line 69
    .line 70
    const/4 v1, 0x2

    .line 71
    if-eq p1, v1, :cond_5b

    .line 72
    .line 73
    const/4 v1, 0x3

    .line 74
    if-eq p1, v1, :cond_53

    .line 75
    .line 76
    const v1, 0x104000a

    .line 77
    .line 78
    .line 79
    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p3

    .line 83
    goto :goto_6a

    .line 84
    :cond_53
    const v1, 0x7f0e0023

    .line 85
    .line 86
    .line 87
    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object p3

    .line 91
    goto :goto_6a

    .line 92
    :cond_5b
    const v1, 0x7f0e002d

    .line 93
    .line 94
    .line 95
    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object p3

    .line 99
    goto :goto_6a

    .line 100
    :cond_63
    const v1, 0x7f0e0026

    .line 101
    .line 102
    .line 103
    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object p3

    .line 107
    :goto_6a
    if-eqz p3, :cond_6f

    .line 108
    .line 109
    invoke-virtual {v0, p3, p2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 110
    .line 111
    .line 112
    :cond_6f
    invoke-static {p0, p1}, LM0/j;->c(Landroid/content/Context;I)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p0

    .line 116
    if-eqz p0, :cond_78

    .line 117
    .line 118
    invoke-virtual {v0, p0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 119
    .line 120
    .line 121
    :cond_78
    const-string p0, "Creating dialog for Google Play services availability issue. ConnectionResult="

    .line 122
    .line 123
    invoke-static {p0, p1}, LK1/c;->e(Ljava/lang/String;I)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object p0

    .line 127
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 128
    .line 129
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 130
    .line 131
    .line 132
    const-string p2, "GoogleApiAvailability"

    .line 133
    .line 134
    invoke-static {p2, p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 135
    .line 136
    .line 137
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    return-object p0
.end method

.method public static e(Landroid/app/Activity;Landroid/app/AlertDialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V
    .registers 6

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    new-instance v0, LJ0/b;

    .line 6
    .line 7
    invoke-direct {v0}, Landroid/app/DialogFragment;-><init>()V

    .line 8
    .line 9
    .line 10
    const-string v1, "Cannot display null dialog"

    .line 11
    .line 12
    invoke-static {p1, v1}, LM0/o;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-virtual {p1, v1}, Landroid/app/Dialog;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1, v1}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 20
    .line 21
    .line 22
    iput-object p1, v0, LJ0/b;->e:Landroid/app/AlertDialog;

    .line 23
    .line 24
    if-eqz p3, :cond_1b

    .line 25
    .line 26
    iput-object p3, v0, LJ0/b;->f:Landroid/content/DialogInterface$OnCancelListener;

    .line 27
    .line 28
    :cond_1b
    invoke-virtual {v0, p0, p2}, Landroid/app/DialogFragment;->show(Landroid/app/FragmentManager;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method


# virtual methods
.method public final c(Lcom/google/android/gms/common/api/GoogleApiActivity;ILcom/google/android/gms/common/api/GoogleApiActivity;)V
    .registers 7

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-super {p0, p2, p1, v0}, LJ0/e;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, LM0/k;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-direct {v1, v0, p1, v2}, LM0/k;-><init>(Landroid/content/Intent;Ljava/lang/Object;I)V

    .line 11
    .line 12
    .line 13
    invoke-static {p1, p2, v1, p3}, LJ0/d;->d(Landroid/app/Activity;ILM0/k;Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    if-nez p2, :cond_13

    .line 18
    .line 19
    return-void

    .line 20
    :cond_13
    const-string v0, "GooglePlayServicesErrorDialog"

    .line 21
    .line 22
    invoke-static {p1, p2, v0, p3}, LJ0/d;->e(Landroid/app/Activity;Landroid/app/AlertDialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public final f(Landroid/content/Context;ILandroid/app/PendingIntent;)V
    .registers 21

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move/from16 v1, p2

    .line 4
    .line 5
    new-instance v2, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    const-string v3, "GMS core API Availability. ConnectionResult="

    .line 8
    .line 9
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    const-string v3, ", tag=null"

    .line 16
    .line 17
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    new-instance v3, Ljava/lang/IllegalArgumentException;

    .line 25
    .line 26
    invoke-direct {v3}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 27
    .line 28
    .line 29
    const-string v4, "GoogleApiAvailability"

    .line 30
    .line 31
    invoke-static {v4, v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 32
    .line 33
    .line 34
    const/16 v2, 0x12

    .line 35
    .line 36
    const/4 v12, 0x1

    .line 37
    if-ne v1, v2, :cond_34

    .line 38
    .line 39
    new-instance v1, LJ0/i;

    .line 40
    .line 41
    move-object/from16 v13, p0

    .line 42
    .line 43
    invoke-direct {v1, v13, v0}, LJ0/i;-><init>(LJ0/d;Landroid/content/Context;)V

    .line 44
    .line 45
    .line 46
    const-wide/32 v2, 0x1d4c0

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1, v12, v2, v3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_34
    move-object/from16 v13, p0

    .line 54
    .line 55
    const/4 v2, 0x6

    .line 56
    if-nez p3, :cond_43

    .line 57
    .line 58
    if-ne v1, v2, :cond_42

    .line 59
    .line 60
    const-string v0, "GoogleApiAvailability"

    .line 61
    .line 62
    const-string v1, "Missing resolution for ConnectionResult.RESOLUTION_REQUIRED. Call GoogleApiAvailability#showErrorNotification(Context, ConnectionResult) instead."

    .line 63
    .line 64
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 65
    .line 66
    .line 67
    :cond_42
    return-void

    .line 68
    :cond_43
    if-ne v1, v2, :cond_4c

    .line 69
    .line 70
    const-string v3, "common_google_play_services_resolution_required_title"

    .line 71
    .line 72
    invoke-static {v0, v3}, LM0/j;->e(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    goto :goto_50

    .line 77
    :cond_4c
    invoke-static/range {p1 .. p2}, LM0/j;->c(Landroid/content/Context;I)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    :goto_50
    const v4, 0x7f0e002a

    .line 82
    .line 83
    .line 84
    if-nez v3, :cond_5d

    .line 85
    .line 86
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v3

    .line 94
    :cond_5d
    if-eq v1, v2, :cond_69

    .line 95
    .line 96
    const/16 v2, 0x13

    .line 97
    .line 98
    if-ne v1, v2, :cond_64

    .line 99
    .line 100
    goto :goto_69

    .line 101
    :cond_64
    invoke-static/range {p1 .. p2}, LM0/j;->b(Landroid/content/Context;I)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    goto :goto_73

    .line 106
    :cond_69
    :goto_69
    invoke-static {v0}, LM0/j;->a(Landroid/content/Context;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v2

    .line 110
    const-string v5, "common_google_play_services_resolution_required_text"

    .line 111
    .line 112
    invoke-static {v0, v5, v2}, LM0/j;->d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    :goto_73
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 117
    .line 118
    .line 119
    move-result-object v5

    .line 120
    const-string v6, "notification"

    .line 121
    .line 122
    invoke-virtual {v0, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v6

    .line 126
    invoke-static {v6}, LM0/o;->e(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    move-object v14, v6

    .line 130
    check-cast v14, Landroid/app/NotificationManager;

    .line 131
    .line 132
    new-instance v15, Lr/i;

    .line 133
    .line 134
    const/4 v6, 0x0

    .line 135
    invoke-direct {v15, v0, v6}, Lr/i;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    iput-boolean v12, v15, Lr/i;->u:Z

    .line 139
    .line 140
    const/16 v7, 0x10

    .line 141
    .line 142
    invoke-virtual {v15, v7, v12}, Lr/i;->c(IZ)V

    .line 143
    .line 144
    .line 145
    invoke-static {v3}, Lr/i;->b(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 146
    .line 147
    .line 148
    move-result-object v3

    .line 149
    iput-object v3, v15, Lr/i;->e:Ljava/lang/CharSequence;

    .line 150
    .line 151
    new-instance v3, Lr/g;

    .line 152
    .line 153
    const/4 v7, 0x0

    .line 154
    invoke-direct {v3, v7}, Lr/g;-><init>(I)V

    .line 155
    .line 156
    .line 157
    invoke-static {v2}, Lr/i;->b(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 158
    .line 159
    .line 160
    move-result-object v7

    .line 161
    iput-object v7, v3, Lr/g;->f:Ljava/lang/Object;

    .line 162
    .line 163
    invoke-virtual {v15, v3}, Lr/i;->f(Lr/A;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 167
    .line 168
    .line 169
    move-result-object v3

    .line 170
    sget-object v7, LQ0/b;->b:Ljava/lang/Boolean;

    .line 171
    .line 172
    if-nez v7, :cond_b9

    .line 173
    .line 174
    const-string v7, "android.hardware.type.watch"

    .line 175
    .line 176
    invoke-virtual {v3, v7}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 177
    .line 178
    .line 179
    move-result v3

    .line 180
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 181
    .line 182
    .line 183
    move-result-object v3

    .line 184
    sput-object v3, LQ0/b;->b:Ljava/lang/Boolean;

    .line 185
    .line 186
    :cond_b9
    sget-object v3, LQ0/b;->b:Ljava/lang/Boolean;

    .line 187
    .line 188
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 189
    .line 190
    .line 191
    move-result v3

    .line 192
    const/4 v7, 0x2

    .line 193
    if-eqz v3, :cond_107

    .line 194
    .line 195
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 196
    .line 197
    .line 198
    move-result-object v2

    .line 199
    iget v2, v2, Landroid/content/pm/ApplicationInfo;->icon:I

    .line 200
    .line 201
    iget-object v3, v15, Lr/i;->G:Landroid/app/Notification;

    .line 202
    .line 203
    iput v2, v3, Landroid/app/Notification;->icon:I

    .line 204
    .line 205
    iput v7, v15, Lr/i;->k:I

    .line 206
    .line 207
    invoke-static {v0}, LQ0/b;->c(Landroid/content/Context;)Z

    .line 208
    .line 209
    .line 210
    move-result v2

    .line 211
    if-eqz v2, :cond_102

    .line 212
    .line 213
    const v2, 0x7f0e0032

    .line 214
    .line 215
    .line 216
    invoke-virtual {v5, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object v4

    .line 220
    iget-object v2, v15, Lr/i;->b:Ljava/util/ArrayList;

    .line 221
    .line 222
    move-object v3, v2

    .line 223
    new-instance v2, Lr/c;

    .line 224
    .line 225
    const-string v5, ""

    .line 226
    .line 227
    const v8, 0x7f070057

    .line 228
    .line 229
    .line 230
    invoke-static {v6, v5, v8}, Landroidx/core/graphics/drawable/IconCompat;->e(Landroid/content/res/Resources;Ljava/lang/String;I)Landroidx/core/graphics/drawable/IconCompat;

    .line 231
    .line 232
    .line 233
    move-result-object v5

    .line 234
    new-instance v6, Landroid/os/Bundle;

    .line 235
    .line 236
    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    .line 237
    .line 238
    .line 239
    const/4 v9, 0x1

    .line 240
    const/4 v11, 0x0

    .line 241
    move v8, v7

    .line 242
    const/4 v7, 0x0

    .line 243
    move v10, v8

    .line 244
    const/4 v8, 0x0

    .line 245
    move/from16 v16, v10

    .line 246
    .line 247
    const/4 v10, 0x1

    .line 248
    move-object v12, v3

    .line 249
    move-object v3, v5

    .line 250
    move-object/from16 v5, p3

    .line 251
    .line 252
    invoke-direct/range {v2 .. v11}, Lr/c;-><init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Lr/J;[Lr/J;ZZZ)V

    .line 253
    .line 254
    .line 255
    invoke-virtual {v12, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    goto :goto_12c

    .line 259
    :cond_102
    move-object/from16 v3, p3

    .line 260
    .line 261
    iput-object v3, v15, Lr/i;->g:Landroid/app/PendingIntent;

    .line 262
    .line 263
    goto :goto_12c

    .line 264
    :cond_107
    move-object/from16 v3, p3

    .line 265
    .line 266
    iget-object v6, v15, Lr/i;->G:Landroid/app/Notification;

    .line 267
    .line 268
    const v7, 0x108008a

    .line 269
    .line 270
    .line 271
    iput v7, v6, Landroid/app/Notification;->icon:I

    .line 272
    .line 273
    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 274
    .line 275
    .line 276
    move-result-object v4

    .line 277
    iget-object v5, v15, Lr/i;->G:Landroid/app/Notification;

    .line 278
    .line 279
    invoke-static {v4}, Lr/i;->b(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 280
    .line 281
    .line 282
    move-result-object v4

    .line 283
    iput-object v4, v5, Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;

    .line 284
    .line 285
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 286
    .line 287
    .line 288
    move-result-wide v4

    .line 289
    iget-object v6, v15, Lr/i;->G:Landroid/app/Notification;

    .line 290
    .line 291
    iput-wide v4, v6, Landroid/app/Notification;->when:J

    .line 292
    .line 293
    iput-object v3, v15, Lr/i;->g:Landroid/app/PendingIntent;

    .line 294
    .line 295
    invoke-static {v2}, Lr/i;->b(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 296
    .line 297
    .line 298
    move-result-object v2

    .line 299
    iput-object v2, v15, Lr/i;->f:Ljava/lang/CharSequence;

    .line 300
    .line 301
    :goto_12c
    invoke-static {}, LQ0/b;->b()Z

    .line 302
    .line 303
    .line 304
    move-result v2

    .line 305
    if-nez v2, :cond_133

    .line 306
    .line 307
    goto :goto_16a

    .line 308
    :cond_133
    invoke-static {}, LQ0/b;->b()Z

    .line 309
    .line 310
    .line 311
    move-result v2

    .line 312
    if-eqz v2, :cond_18a

    .line 313
    .line 314
    sget-object v2, LJ0/d;->b:Ljava/lang/Object;

    .line 315
    .line 316
    monitor-enter v2

    .line 317
    :try_start_13c
    monitor-exit v2
    :try_end_13d
    .catchall {:try_start_13c .. :try_end_13d} :catchall_187

    .line 318
    const-string v2, "com.google.android.gms.availability"

    .line 319
    .line 320
    invoke-static {v14}, LA/a;->c(Landroid/app/NotificationManager;)Landroid/app/NotificationChannel;

    .line 321
    .line 322
    .line 323
    move-result-object v3

    .line 324
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    const v4, 0x7f0e0029

    .line 329
    .line 330
    .line 331
    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    if-nez v3, :cond_158

    .line 336
    .line 337
    invoke-static {v0}, LA/a;->d(Ljava/lang/String;)Landroid/app/NotificationChannel;

    .line 338
    .line 339
    .line 340
    move-result-object v0

    .line 341
    invoke-static {v14, v0}, LA/a;->v(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    .line 342
    .line 343
    .line 344
    goto :goto_168

    .line 345
    :cond_158
    invoke-static {v3}, LA/a;->j(Landroid/app/NotificationChannel;)Ljava/lang/CharSequence;

    .line 346
    .line 347
    .line 348
    move-result-object v4

    .line 349
    invoke-virtual {v0, v4}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    .line 350
    .line 351
    .line 352
    move-result v4

    .line 353
    if-nez v4, :cond_168

    .line 354
    .line 355
    invoke-static {v3, v0}, LA/a;->s(Landroid/app/NotificationChannel;Ljava/lang/String;)V

    .line 356
    .line 357
    .line 358
    invoke-static {v14, v3}, LA/a;->v(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    .line 359
    .line 360
    .line 361
    :cond_168
    :goto_168
    iput-object v2, v15, Lr/i;->B:Ljava/lang/String;

    .line 362
    .line 363
    :goto_16a
    invoke-virtual {v15}, Lr/i;->a()Landroid/app/Notification;

    .line 364
    .line 365
    .line 366
    move-result-object v0

    .line 367
    const/4 v2, 0x1

    .line 368
    if-eq v1, v2, :cond_17b

    .line 369
    .line 370
    const/4 v8, 0x2

    .line 371
    if-eq v1, v8, :cond_17b

    .line 372
    .line 373
    const/4 v2, 0x3

    .line 374
    if-eq v1, v2, :cond_17b

    .line 375
    .line 376
    const v1, 0x9b6d

    .line 377
    .line 378
    .line 379
    goto :goto_183

    .line 380
    :cond_17b
    sget-object v1, LJ0/f;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 381
    .line 382
    const/4 v2, 0x0

    .line 383
    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 384
    .line 385
    .line 386
    const/16 v1, 0x28c4

    .line 387
    .line 388
    :goto_183
    invoke-virtual {v14, v1, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 389
    .line 390
    .line 391
    return-void

    .line 392
    :catchall_187
    move-exception v0

    .line 393
    :try_start_188
    monitor-exit v2
    :try_end_189
    .catchall {:try_start_188 .. :try_end_189} :catchall_187

    .line 394
    throw v0

    .line 395
    :cond_18a
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 396
    .line 397
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 398
    .line 399
    .line 400
    throw v0
.end method

.method public final g(Landroid/app/Activity;LL0/x;ILandroid/content/DialogInterface$OnCancelListener;)V
    .registers 8

    .line 1
    const-string v0, "d"

    .line 2
    .line 3
    invoke-super {p0, p3, p1, v0}, LJ0/e;->a(ILandroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, LM0/k;

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    invoke-direct {v1, v0, p2, v2}, LM0/k;-><init>(Landroid/content/Intent;Ljava/lang/Object;I)V

    .line 11
    .line 12
    .line 13
    invoke-static {p1, p3, v1, p4}, LJ0/d;->d(Landroid/app/Activity;ILM0/k;Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    if-nez p2, :cond_13

    .line 18
    .line 19
    return-void

    .line 20
    :cond_13
    const-string p3, "GooglePlayServicesErrorDialog"

    .line 21
    .line 22
    invoke-static {p1, p2, p3, p4}, LJ0/d;->e(Landroid/app/Activity;Landroid/app/AlertDialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method
