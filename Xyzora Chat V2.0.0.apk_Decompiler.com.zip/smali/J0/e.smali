###### Class J0.e (J0.e)
.class public abstract LJ0/e;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget v0, LJ0/f;->c:I

    .line 2
    .line 3
    const v0, 0xbdfcb8

    .line 4
    .line 5
    .line 6
    sput v0, LJ0/e;->a:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public a(ILandroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .registers 7

    .line 1
    const/4 v0, 0x1

    .line 2
    const-string v1, "com.google.android.gms"

    .line 3
    .line 4
    if-eq p1, v0, :cond_1e

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    if-eq p1, v0, :cond_1e

    .line 8
    .line 9
    const/4 p2, 0x3

    .line 10
    const/4 p3, 0x0

    .line 11
    if-eq p1, p2, :cond_d

    .line 12
    .line 13
    return-object p3

    .line 14
    :cond_d
    const-string p1, "package"

    .line 15
    .line 16
    invoke-static {p1, v1, p3}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    new-instance p2, Landroid/content/Intent;

    .line 21
    .line 22
    const-string p3, "android.settings.APPLICATION_DETAILS_SETTINGS"

    .line 23
    .line 24
    invoke-direct {p2, p3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p2, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 28
    .line 29
    .line 30
    return-object p2

    .line 31
    :cond_1e
    if-eqz p2, :cond_34

    .line 32
    .line 33
    invoke-static {p2}, LQ0/b;->c(Landroid/content/Context;)Z

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    if-nez p1, :cond_27

    .line 38
    .line 39
    goto :goto_34

    .line 40
    :cond_27
    new-instance p1, Landroid/content/Intent;

    .line 41
    .line 42
    const-string p2, "com.google.android.clockwork.home.UPDATE_ANDROID_WEAR_ACTION"

    .line 43
    .line 44
    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    const-string p2, "com.google.android.wearable.app"

    .line 48
    .line 49
    invoke-virtual {p1, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 50
    .line 51
    .line 52
    return-object p1

    .line 53
    :cond_34
    :goto_34
    new-instance p1, Ljava/lang/StringBuilder;

    .line 54
    .line 55
    const-string v0, "gcore_"

    .line 56
    .line 57
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    sget v0, LJ0/e;->a:I

    .line 61
    .line 62
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    const-string v0, "-"

    .line 66
    .line 67
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    if-nez v2, :cond_4e

    .line 75
    .line 76
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    :cond_4e
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    if-eqz p2, :cond_5a

    .line 83
    .line 84
    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p3

    .line 88
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    :cond_5a
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 92
    .line 93
    .line 94
    if-eqz p2, :cond_77

    .line 95
    .line 96
    :try_start_5f
    invoke-static {p2}, LS0/b;->a(Landroid/content/Context;)LM/l;

    .line 97
    .line 98
    .line 99
    move-result-object p3

    .line 100
    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p2

    .line 104
    iget-object p3, p3, LM/l;->a:Landroid/content/Context;

    .line 105
    .line 106
    invoke-virtual {p3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 107
    .line 108
    .line 109
    move-result-object p3

    .line 110
    const/4 v0, 0x0

    .line 111
    invoke-virtual {p3, p2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 112
    .line 113
    .line 114
    move-result-object p2

    .line 115
    iget p2, p2, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 116
    .line 117
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    :try_end_77
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_5f .. :try_end_77} :catch_77

    .line 118
    .line 119
    .line 120
    :catch_77
    :cond_77
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    new-instance p2, Landroid/content/Intent;

    .line 125
    .line 126
    const-string p3, "android.intent.action.VIEW"

    .line 127
    .line 128
    invoke-direct {p2, p3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    const-string p3, "market://details"

    .line 132
    .line 133
    invoke-static {p3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 134
    .line 135
    .line 136
    move-result-object p3

    .line 137
    invoke-virtual {p3}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    .line 138
    .line 139
    .line 140
    move-result-object p3

    .line 141
    const-string v0, "id"

    .line 142
    .line 143
    invoke-virtual {p3, v0, v1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 144
    .line 145
    .line 146
    move-result-object p3

    .line 147
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-nez v0, :cond_9d

    .line 152
    .line 153
    const-string v0, "pcampaignid"

    .line 154
    .line 155
    invoke-virtual {p3, v0, p1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    .line 156
    .line 157
    .line 158
    :cond_9d
    invoke-virtual {p3}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    invoke-virtual {p2, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 163
    .line 164
    .line 165
    const-string p1, "com.android.vending"

    .line 166
    .line 167
    invoke-virtual {p2, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 168
    .line 169
    .line 170
    const/high16 p1, 0x80000

    .line 171
    .line 172
    invoke-virtual {p2, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 173
    .line 174
    .line 175
    return-object p2
.end method

.method public b(Landroid/content/Context;I)I
    .registers 15

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    sget v2, LJ0/f;->c:I

    .line 4
    .line 5
    :try_start_4
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    const v3, 0x7f0e002b

    .line 10
    .line 11
    .line 12
    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    :try_end_e
    .catchall {:try_start_4 .. :try_end_e} :catchall_f

    .line 13
    .line 14
    .line 15
    goto :goto_16

    .line 16
    :catchall_f
    const-string v2, "GooglePlayServicesUtil"

    .line 17
    .line 18
    const-string v3, "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included."

    .line 19
    .line 20
    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 21
    .line 22
    .line 23
    :goto_16
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    const-string v3, "com.google.android.gms"

    .line 28
    .line 29
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-nez v2, :cond_9f

    .line 34
    .line 35
    sget-object v2, LJ0/f;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 36
    .line 37
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    if-eqz v2, :cond_2c

    .line 42
    .line 43
    goto/16 :goto_9f

    .line 44
    .line 45
    :cond_2c
    sget-object v2, LM0/o;->a:Ljava/lang/Object;

    .line 46
    .line 47
    monitor-enter v2

    .line 48
    :try_start_2f
    sget-boolean v3, LM0/o;->b:Z

    .line 49
    .line 50
    if-eqz v3, :cond_37

    .line 51
    .line 52
    monitor-exit v2

    .line 53
    goto :goto_6a

    .line 54
    :catchall_35
    move-exception p1

    .line 55
    goto :goto_9d

    .line 56
    :cond_37
    sput-boolean v0, LM0/o;->b:Z

    .line 57
    .line 58
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    invoke-static {p1}, LS0/b;->a(Landroid/content/Context;)LM/l;

    .line 63
    .line 64
    .line 65
    move-result-object v4
    :try_end_41
    .catchall {:try_start_2f .. :try_end_41} :catchall_35

    .line 66
    :try_start_41
    iget-object v4, v4, LM/l;->a:Landroid/content/Context;

    .line 67
    .line 68
    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    const/16 v5, 0x80

    .line 73
    .line 74
    invoke-virtual {v4, v3, v5}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    iget-object v3, v3, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;
    :try_end_4f
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_41 .. :try_end_4f} :catch_61
    .catchall {:try_start_41 .. :try_end_4f} :catchall_35

    .line 79
    .line 80
    if-nez v3, :cond_53

    .line 81
    .line 82
    :try_start_51
    monitor-exit v2
    :try_end_52
    .catchall {:try_start_51 .. :try_end_52} :catchall_35

    .line 83
    goto :goto_6a

    .line 84
    :cond_53
    :try_start_53
    const-string v4, "com.google.app.id"

    .line 85
    .line 86
    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    const-string v4, "com.google.android.gms.version"

    .line 90
    .line 91
    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 92
    .line 93
    .line 94
    move-result v3

    .line 95
    sput v3, LM0/o;->c:I
    :try_end_60
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_53 .. :try_end_60} :catch_61
    .catchall {:try_start_53 .. :try_end_60} :catchall_35

    .line 96
    .line 97
    goto :goto_69

    .line 98
    :catch_61
    move-exception v3

    .line 99
    :try_start_62
    const-string v4, "MetadataValueReader"

    .line 100
    .line 101
    const-string v5, "This should never happen."

    .line 102
    .line 103
    invoke-static {v4, v5, v3}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 104
    .line 105
    .line 106
    :goto_69
    monitor-exit v2
    :try_end_6a
    .catchall {:try_start_62 .. :try_end_6a} :catchall_35

    .line 107
    :goto_6a
    sget v2, LM0/o;->c:I

    .line 108
    .line 109
    if-eqz v2, :cond_97

    .line 110
    .line 111
    const v3, 0xbdfcb8

    .line 112
    .line 113
    .line 114
    if-ne v2, v3, :cond_74

    .line 115
    .line 116
    goto :goto_9f

    .line 117
    :cond_74
    new-instance p1, Lcom/google/android/gms/common/GooglePlayServicesIncorrectManifestValueException;

    .line 118
    .line 119
    sget p2, LJ0/e;->a:I

    .line 120
    .line 121
    new-instance v0, Ljava/lang/StringBuilder;

    .line 122
    .line 123
    const-string v1, "The meta-data tag in your app\'s AndroidManifest.xml does not have the right value.  Expected "

    .line 124
    .line 125
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 129
    .line 130
    .line 131
    const-string p2, " but found "

    .line 132
    .line 133
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 134
    .line 135
    .line 136
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    const-string p2, ".  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />"

    .line 140
    .line 141
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object p2

    .line 148
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    throw p1

    .line 152
    :cond_97
    new-instance p1, Lcom/google/android/gms/common/GooglePlayServicesMissingManifestValueException;

    .line 153
    .line 154
    invoke-direct {p1}, Lcom/google/android/gms/common/GooglePlayServicesMissingManifestValueException;-><init>()V

    .line 155
    .line 156
    .line 157
    throw p1

    .line 158
    :goto_9d
    :try_start_9d
    monitor-exit v2
    :try_end_9e
    .catchall {:try_start_9d .. :try_end_9e} :catchall_35

    .line 159
    throw p1

    .line 160
    :cond_9f
    :goto_9f
    invoke-static {p1}, LQ0/b;->c(Landroid/content/Context;)Z

    .line 161
    .line 162
    .line 163
    move-result v2

    .line 164
    if-nez v2, :cond_d4

    .line 165
    .line 166
    sget-object v2, LQ0/b;->d:Ljava/lang/Boolean;

    .line 167
    .line 168
    if-nez v2, :cond_ca

    .line 169
    .line 170
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 171
    .line 172
    .line 173
    move-result-object v2

    .line 174
    const-string v3, "android.hardware.type.iot"

    .line 175
    .line 176
    invoke-virtual {v2, v3}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 177
    .line 178
    .line 179
    move-result v2

    .line 180
    if-nez v2, :cond_c1

    .line 181
    .line 182
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 183
    .line 184
    .line 185
    move-result-object v2

    .line 186
    const-string v3, "android.hardware.type.embedded"

    .line 187
    .line 188
    invoke-virtual {v2, v3}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    if-eqz v2, :cond_c3

    .line 193
    .line 194
    :cond_c1
    move v2, v0

    .line 195
    goto :goto_c4

    .line 196
    :cond_c3
    move v2, v1

    .line 197
    :goto_c4
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 198
    .line 199
    .line 200
    move-result-object v2

    .line 201
    sput-object v2, LQ0/b;->d:Ljava/lang/Boolean;

    .line 202
    .line 203
    :cond_ca
    sget-object v2, LQ0/b;->d:Ljava/lang/Boolean;

    .line 204
    .line 205
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 206
    .line 207
    .line 208
    move-result v2

    .line 209
    if-nez v2, :cond_d4

    .line 210
    .line 211
    move v2, v0

    .line 212
    goto :goto_d5

    .line 213
    :cond_d4
    move v2, v1

    .line 214
    :goto_d5
    if-ltz p2, :cond_23e

    .line 215
    .line 216
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 217
    .line 218
    .line 219
    move-result-object v3

    .line 220
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 221
    .line 222
    .line 223
    move-result-object v4

    .line 224
    const/16 v5, 0x9

    .line 225
    .line 226
    if-eqz v2, :cond_fd

    .line 227
    .line 228
    :try_start_e3
    const-string v6, "com.android.vending"

    .line 229
    .line 230
    const/16 v7, 0x2040

    .line 231
    .line 232
    invoke-virtual {v4, v6, v7}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 233
    .line 234
    .line 235
    move-result-object v6
    :try_end_eb
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_e3 .. :try_end_eb} :catch_ec

    .line 236
    goto :goto_fe

    .line 237
    :catch_ec
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object p2

    .line 241
    const-string v2, " requires the Google Play Store, but it is missing."

    .line 242
    .line 243
    const-string v3, "GooglePlayServicesUtil"

    .line 244
    .line 245
    invoke-virtual {p2, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object p2

    .line 249
    invoke-static {v3, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 250
    .line 251
    .line 252
    goto/16 :goto_1fb

    .line 253
    .line 254
    :cond_fd
    const/4 v6, 0x0

    .line 255
    :goto_fe
    :try_start_fe
    const-string v7, "com.google.android.gms"

    .line 256
    .line 257
    const/16 v8, 0x40

    .line 258
    .line 259
    invoke-virtual {v4, v7, v8}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 260
    .line 261
    .line 262
    move-result-object v7
    :try_end_106
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_fe .. :try_end_106} :catch_1eb

    .line 263
    const-class v8, LJ0/g;

    .line 264
    .line 265
    monitor-enter v8

    .line 266
    :try_start_109
    sget-object v9, LJ0/g;->f:LJ0/g;

    .line 267
    .line 268
    if-nez v9, :cond_138

    .line 269
    .line 270
    sget-object v9, LJ0/n;->a:LJ0/j;

    .line 271
    .line 272
    const-class v9, LJ0/n;

    .line 273
    .line 274
    monitor-enter v9
    :try_end_112
    .catchall {:try_start_109 .. :try_end_112} :catchall_133

    .line 275
    :try_start_112
    sget-object v10, LJ0/n;->c:Landroid/content/Context;

    .line 276
    .line 277
    if-nez v10, :cond_120

    .line 278
    .line 279
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 280
    .line 281
    .line 282
    move-result-object v10

    .line 283
    sput-object v10, LJ0/n;->c:Landroid/content/Context;
    :try_end_11c
    .catchall {:try_start_112 .. :try_end_11c} :catchall_11e

    .line 284
    .line 285
    :try_start_11c
    monitor-exit v9
    :try_end_11d
    .catchall {:try_start_11c .. :try_end_11d} :catchall_133

    .line 286
    goto :goto_128

    .line 287
    :catchall_11e
    move-exception p1

    .line 288
    goto :goto_136

    .line 289
    :cond_120
    :try_start_120
    const-string v10, "GoogleCertificates"

    .line 290
    .line 291
    const-string v11, "GoogleCertificates has been initialized already"

    .line 292
    .line 293
    invoke-static {v10, v11}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_127
    .catchall {:try_start_120 .. :try_end_127} :catchall_11e

    .line 294
    .line 295
    .line 296
    :try_start_127
    monitor-exit v9

    .line 297
    :goto_128
    new-instance v9, LJ0/g;

    .line 298
    .line 299
    invoke-direct {v9, v1}, LJ0/g;-><init>(I)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 303
    .line 304
    .line 305
    sput-object v9, LJ0/g;->f:LJ0/g;
    :try_end_132
    .catchall {:try_start_127 .. :try_end_132} :catchall_133

    .line 306
    .line 307
    goto :goto_138

    .line 308
    :catchall_133
    move-exception p1

    .line 309
    goto/16 :goto_1e9

    .line 310
    .line 311
    :goto_136
    :try_start_136
    monitor-exit v9
    :try_end_137
    .catchall {:try_start_136 .. :try_end_137} :catchall_11e

    .line 312
    :try_start_137
    throw p1

    .line 313
    :cond_138
    :goto_138
    monitor-exit v8
    :try_end_139
    .catchall {:try_start_137 .. :try_end_139} :catchall_133

    .line 314
    invoke-static {v7}, LJ0/g;->e(Landroid/content/pm/PackageInfo;)Z

    .line 315
    .line 316
    .line 317
    move-result v8

    .line 318
    if-nez v8, :cond_150

    .line 319
    .line 320
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 321
    .line 322
    .line 323
    move-result-object p2

    .line 324
    const-string v2, " requires Google Play services, but their signature is invalid."

    .line 325
    .line 326
    const-string v3, "GooglePlayServicesUtil"

    .line 327
    .line 328
    invoke-virtual {p2, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 329
    .line 330
    .line 331
    move-result-object p2

    .line 332
    invoke-static {v3, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 333
    .line 334
    .line 335
    goto/16 :goto_1fb

    .line 336
    .line 337
    :cond_150
    if-eqz v2, :cond_16c

    .line 338
    .line 339
    invoke-static {v6}, LM0/o;->e(Ljava/lang/Object;)V

    .line 340
    .line 341
    .line 342
    invoke-static {v6}, LJ0/g;->e(Landroid/content/pm/PackageInfo;)Z

    .line 343
    .line 344
    .line 345
    move-result v8

    .line 346
    if-nez v8, :cond_16c

    .line 347
    .line 348
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object p2

    .line 352
    const-string v2, " requires Google Play Store, but its signature is invalid."

    .line 353
    .line 354
    const-string v3, "GooglePlayServicesUtil"

    .line 355
    .line 356
    invoke-virtual {p2, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object p2

    .line 360
    invoke-static {v3, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 361
    .line 362
    .line 363
    goto/16 :goto_1fb

    .line 364
    .line 365
    :cond_16c
    if-eqz v2, :cond_18f

    .line 366
    .line 367
    if-eqz v6, :cond_18f

    .line 368
    .line 369
    iget-object v2, v6, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 370
    .line 371
    aget-object v2, v2, v1

    .line 372
    .line 373
    iget-object v6, v7, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 374
    .line 375
    aget-object v6, v6, v1

    .line 376
    .line 377
    invoke-virtual {v2, v6}, Landroid/content/pm/Signature;->equals(Ljava/lang/Object;)Z

    .line 378
    .line 379
    .line 380
    move-result v2

    .line 381
    if-nez v2, :cond_18f

    .line 382
    .line 383
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 384
    .line 385
    .line 386
    move-result-object p2

    .line 387
    const-string v2, " requires Google Play Store, but its signature doesn\'t match that of Google Play services."

    .line 388
    .line 389
    const-string v3, "GooglePlayServicesUtil"

    .line 390
    .line 391
    invoke-virtual {p2, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 392
    .line 393
    .line 394
    move-result-object p2

    .line 395
    invoke-static {v3, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 396
    .line 397
    .line 398
    goto/16 :goto_1fb

    .line 399
    .line 400
    :cond_18f
    iget v2, v7, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 401
    .line 402
    const/4 v5, -0x1

    .line 403
    if-ne v2, v5, :cond_196

    .line 404
    .line 405
    move v6, v5

    .line 406
    goto :goto_198

    .line 407
    :cond_196
    div-int/lit16 v6, v2, 0x3e8

    .line 408
    .line 409
    :goto_198
    if-ne p2, v5, :cond_19b

    .line 410
    .line 411
    goto :goto_19d

    .line 412
    :cond_19b
    div-int/lit16 v5, p2, 0x3e8

    .line 413
    .line 414
    :goto_19d
    if-ge v6, v5, :cond_1c4

    .line 415
    .line 416
    new-instance v4, Ljava/lang/StringBuilder;

    .line 417
    .line 418
    const-string v5, "Google Play services out of date for "

    .line 419
    .line 420
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 421
    .line 422
    .line 423
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 424
    .line 425
    .line 426
    const-string v3, ".  Requires "

    .line 427
    .line 428
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 429
    .line 430
    .line 431
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 432
    .line 433
    .line 434
    const-string p2, " but found "

    .line 435
    .line 436
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 437
    .line 438
    .line 439
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 440
    .line 441
    .line 442
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 443
    .line 444
    .line 445
    move-result-object p2

    .line 446
    const-string v2, "GooglePlayServicesUtil"

    .line 447
    .line 448
    invoke-static {v2, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 449
    .line 450
    .line 451
    const/4 v5, 0x2

    .line 452
    goto :goto_1fb

    .line 453
    :cond_1c4
    iget-object p2, v7, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    .line 454
    .line 455
    if-nez p2, :cond_1e1

    .line 456
    .line 457
    :try_start_1c8
    const-string p2, "com.google.android.gms"

    .line 458
    .line 459
    invoke-virtual {v4, p2, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    .line 460
    .line 461
    .line 462
    move-result-object p2
    :try_end_1ce
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1c8 .. :try_end_1ce} :catch_1cf

    .line 463
    goto :goto_1e1

    .line 464
    :catch_1cf
    move-exception p2

    .line 465
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 466
    .line 467
    .line 468
    move-result-object v2

    .line 469
    const-string v3, " requires Google Play services, but they\'re missing when getting application info."

    .line 470
    .line 471
    const-string v4, "GooglePlayServicesUtil"

    .line 472
    .line 473
    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 474
    .line 475
    .line 476
    move-result-object v2

    .line 477
    invoke-static {v4, v2, p2}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 478
    .line 479
    .line 480
    :goto_1df
    move v5, v0

    .line 481
    goto :goto_1fb

    .line 482
    :cond_1e1
    :goto_1e1
    iget-boolean p2, p2, Landroid/content/pm/ApplicationInfo;->enabled:Z

    .line 483
    .line 484
    if-nez p2, :cond_1e7

    .line 485
    .line 486
    const/4 v5, 0x3

    .line 487
    goto :goto_1fb

    .line 488
    :cond_1e7
    move v5, v1

    .line 489
    goto :goto_1fb

    .line 490
    :goto_1e9
    :try_start_1e9
    monitor-exit v8
    :try_end_1ea
    .catchall {:try_start_1e9 .. :try_end_1ea} :catchall_133

    .line 491
    throw p1

    .line 492
    :catch_1eb
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 493
    .line 494
    .line 495
    move-result-object p2

    .line 496
    const-string v2, " requires Google Play services, but they are missing."

    .line 497
    .line 498
    const-string v3, "GooglePlayServicesUtil"

    .line 499
    .line 500
    invoke-virtual {p2, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 501
    .line 502
    .line 503
    move-result-object p2

    .line 504
    invoke-static {v3, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 505
    .line 506
    .line 507
    goto :goto_1df

    .line 508
    :goto_1fb
    const/16 p2, 0x12

    .line 509
    .line 510
    if-ne v5, p2, :cond_200

    .line 511
    .line 512
    goto :goto_23a

    .line 513
    :cond_200
    if-ne v5, v0, :cond_239

    .line 514
    .line 515
    :try_start_202
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 516
    .line 517
    .line 518
    move-result-object v2

    .line 519
    invoke-virtual {v2}, Landroid/content/pm/PackageManager;->getPackageInstaller()Landroid/content/pm/PackageInstaller;

    .line 520
    .line 521
    .line 522
    move-result-object v2

    .line 523
    invoke-virtual {v2}, Landroid/content/pm/PackageInstaller;->getAllSessions()Ljava/util/List;

    .line 524
    .line 525
    .line 526
    move-result-object v2
    :try_end_20e
    .catch Ljava/lang/Exception; {:try_start_202 .. :try_end_20e} :catch_239

    .line 527
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 528
    .line 529
    .line 530
    move-result-object v2

    .line 531
    :cond_212
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 532
    .line 533
    .line 534
    move-result v3

    .line 535
    const-string v4, "com.google.android.gms"

    .line 536
    .line 537
    if-eqz v3, :cond_22b

    .line 538
    .line 539
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 540
    .line 541
    .line 542
    move-result-object v3

    .line 543
    check-cast v3, Landroid/content/pm/PackageInstaller$SessionInfo;

    .line 544
    .line 545
    invoke-virtual {v3}, Landroid/content/pm/PackageInstaller$SessionInfo;->getAppPackageName()Ljava/lang/String;

    .line 546
    .line 547
    .line 548
    move-result-object v3

    .line 549
    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 550
    .line 551
    .line 552
    move-result v3

    .line 553
    if-eqz v3, :cond_212

    .line 554
    .line 555
    goto :goto_23a

    .line 556
    :cond_22b
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 557
    .line 558
    .line 559
    move-result-object p1

    .line 560
    const/16 v0, 0x2000

    .line 561
    .line 562
    :try_start_231
    invoke-virtual {p1, v4, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    .line 563
    .line 564
    .line 565
    move-result-object p1

    .line 566
    iget-boolean p1, p1, Landroid/content/pm/ApplicationInfo;->enabled:Z
    :try_end_237
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_231 .. :try_end_237} :catch_239

    .line 567
    .line 568
    move v0, p1

    .line 569
    goto :goto_23a

    .line 570
    :catch_239
    :cond_239
    move v0, v1

    .line 571
    :goto_23a
    if-eqz v0, :cond_23d

    .line 572
    .line 573
    return p2

    .line 574
    :cond_23d
    return v5

    .line 575
    :cond_23e
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 576
    .line 577
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 578
    .line 579
    .line 580
    throw p1
.end method
