###### Class J0.a (J0.a)
.class public final LJ0/a;
.super LN0/a;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "LJ0/a;",
            ">;"
        }
    .end annotation
.end field

.field public static final e:LJ0/a;


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Landroid/app/PendingIntent;

.field public final d:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, LJ0/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LJ0/a;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LJ0/a;->e:LJ0/a;

    .line 8
    .line 9
    new-instance v0, LF/h;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, LF/h;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, LJ0/a;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>(I)V
    .registers 4

    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 3
    invoke-direct {p0, v0, p1, v1, v1}, LJ0/a;-><init>(IILandroid/app/PendingIntent;Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(IILandroid/app/PendingIntent;Ljava/lang/String;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput p1, p0, LJ0/a;->a:I

    iput p2, p0, LJ0/a;->b:I

    iput-object p3, p0, LJ0/a;->c:Landroid/app/PendingIntent;

    iput-object p4, p0, LJ0/a;->d:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(ILandroid/app/PendingIntent;)V
    .registers 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 4
    invoke-direct {p0, v0, p1, p2, v1}, LJ0/a;-><init>(IILandroid/app/PendingIntent;Ljava/lang/String;)V

    return-void
.end method

.method public static a(I)Ljava/lang/String;
    .registers 3

    .line 1
    const/16 v0, 0x63

    .line 2
    .line 3
    if-eq p0, v0, :cond_70

    .line 4
    .line 5
    const/16 v0, 0x5dc

    .line 6
    .line 7
    if-eq p0, v0, :cond_6d

    .line 8
    .line 9
    packed-switch p0, :pswitch_data_74

    .line 10
    .line 11
    .line 12
    packed-switch p0, :pswitch_data_92

    .line 13
    .line 14
    .line 15
    new-instance v0, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v1, "UNKNOWN_ERROR_CODE("

    .line 18
    .line 19
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string p0, ")"

    .line 26
    .line 27
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    return-object p0

    .line 35
    :pswitch_22
    const-string p0, "API_DISABLED_FOR_CONNECTION"

    .line 36
    .line 37
    return-object p0

    .line 38
    :pswitch_25
    const-string p0, "API_DISABLED"

    .line 39
    .line 40
    return-object p0

    .line 41
    :pswitch_28
    const-string p0, "RESOLUTION_ACTIVITY_NOT_FOUND"

    .line 42
    .line 43
    return-object p0

    .line 44
    :pswitch_2b
    const-string p0, "API_VERSION_UPDATE_REQUIRED"

    .line 45
    .line 46
    return-object p0

    .line 47
    :pswitch_2e
    const-string p0, "RESTRICTED_PROFILE"

    .line 48
    .line 49
    return-object p0

    .line 50
    :pswitch_31
    const-string p0, "SERVICE_MISSING_PERMISSION"

    .line 51
    .line 52
    return-object p0

    .line 53
    :pswitch_34
    const-string p0, "SERVICE_UPDATING"

    .line 54
    .line 55
    return-object p0

    .line 56
    :pswitch_37
    const-string p0, "SIGN_IN_FAILED"

    .line 57
    .line 58
    return-object p0

    .line 59
    :pswitch_3a
    const-string p0, "API_UNAVAILABLE"

    .line 60
    .line 61
    return-object p0

    .line 62
    :pswitch_3d
    const-string p0, "INTERRUPTED"

    .line 63
    .line 64
    return-object p0

    .line 65
    :pswitch_40
    const-string p0, "TIMEOUT"

    .line 66
    .line 67
    return-object p0

    .line 68
    :pswitch_43
    const-string p0, "CANCELED"

    .line 69
    .line 70
    return-object p0

    .line 71
    :pswitch_46
    const-string p0, "LICENSE_CHECK_FAILED"

    .line 72
    .line 73
    return-object p0

    .line 74
    :pswitch_49
    const-string p0, "DEVELOPER_ERROR"

    .line 75
    .line 76
    return-object p0

    .line 77
    :pswitch_4c
    const-string p0, "SERVICE_INVALID"

    .line 78
    .line 79
    return-object p0

    .line 80
    :pswitch_4f
    const-string p0, "INTERNAL_ERROR"

    .line 81
    .line 82
    return-object p0

    .line 83
    :pswitch_52
    const-string p0, "NETWORK_ERROR"

    .line 84
    .line 85
    return-object p0

    .line 86
    :pswitch_55
    const-string p0, "RESOLUTION_REQUIRED"

    .line 87
    .line 88
    return-object p0

    .line 89
    :pswitch_58
    const-string p0, "INVALID_ACCOUNT"

    .line 90
    .line 91
    return-object p0

    .line 92
    :pswitch_5b
    const-string p0, "SIGN_IN_REQUIRED"

    .line 93
    .line 94
    return-object p0

    .line 95
    :pswitch_5e
    const-string p0, "SERVICE_DISABLED"

    .line 96
    .line 97
    return-object p0

    .line 98
    :pswitch_61
    const-string p0, "SERVICE_VERSION_UPDATE_REQUIRED"

    .line 99
    .line 100
    return-object p0

    .line 101
    :pswitch_64
    const-string p0, "SERVICE_MISSING"

    .line 102
    .line 103
    return-object p0

    .line 104
    :pswitch_67
    const-string p0, "SUCCESS"

    .line 105
    .line 106
    return-object p0

    .line 107
    :pswitch_6a
    const-string p0, "UNKNOWN"

    .line 108
    .line 109
    return-object p0

    .line 110
    :cond_6d
    const-string p0, "DRIVE_EXTERNAL_STORAGE_REQUIRED"

    .line 111
    .line 112
    return-object p0

    .line 113
    :cond_70
    const-string p0, "UNFINISHED"

    .line 114
    .line 115
    return-object p0

    .line 116
    nop

    .line 117
    :pswitch_data_74
    .packed-switch -0x1
        :pswitch_6a
        :pswitch_67
        :pswitch_64
        :pswitch_61
        :pswitch_5e
        :pswitch_5b
        :pswitch_58
        :pswitch_55
        :pswitch_52
        :pswitch_4f
        :pswitch_4c
        :pswitch_49
        :pswitch_46
    .end packed-switch

    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    :pswitch_data_92
    .packed-switch 0xd
        :pswitch_43
        :pswitch_40
        :pswitch_3d
        :pswitch_3a
        :pswitch_37
        :pswitch_34
        :pswitch_31
        :pswitch_2e
        :pswitch_2b
        :pswitch_28
        :pswitch_25
        :pswitch_22
    .end packed-switch
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, LJ0/a;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, LJ0/a;

    .line 12
    .line 13
    iget v1, p1, LJ0/a;->b:I

    .line 14
    .line 15
    iget v3, p0, LJ0/a;->b:I

    .line 16
    .line 17
    if-ne v3, v1, :cond_27

    .line 18
    .line 19
    iget-object v1, p0, LJ0/a;->c:Landroid/app/PendingIntent;

    .line 20
    .line 21
    iget-object v3, p1, LJ0/a;->c:Landroid/app/PendingIntent;

    .line 22
    .line 23
    invoke-static {v1, v3}, LM0/o;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_27

    .line 28
    .line 29
    iget-object v1, p0, LJ0/a;->d:Ljava/lang/String;

    .line 30
    .line 31
    iget-object p1, p1, LJ0/a;->d:Ljava/lang/String;

    .line 32
    .line 33
    invoke-static {v1, p1}, LM0/o;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    if-eqz p1, :cond_27

    .line 38
    .line 39
    return v0

    .line 40
    :cond_27
    return v2
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget v0, p0, LJ0/a;->b:I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, LJ0/a;->c:Landroid/app/PendingIntent;

    .line 8
    .line 9
    iget-object v2, p0, LJ0/a;->d:Ljava/lang/String;

    .line 10
    .line 11
    filled-new-array {v0, v1, v2}, [Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, LE0/j;

    .line 2
    .line 3
    invoke-direct {v0, p0}, LE0/j;-><init>(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget v1, p0, LJ0/a;->b:I

    .line 7
    .line 8
    invoke-static {v1}, LJ0/a;->a(I)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const-string v2, "statusCode"

    .line 13
    .line 14
    invoke-virtual {v0, v1, v2}, LE0/j;->h(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const-string v1, "resolution"

    .line 18
    .line 19
    iget-object v2, p0, LJ0/a;->c:Landroid/app/PendingIntent;

    .line 20
    .line 21
    invoke-virtual {v0, v2, v1}, LE0/j;->h(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const-string v1, "message"

    .line 25
    .line 26
    iget-object v2, p0, LJ0/a;->d:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v0, v2, v1}, LE0/j;->h(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0}, LE0/j;->toString()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 7

    .line 1
    const/16 v0, 0x4f45

    .line 2
    .line 3
    invoke-static {p1, v0}, LO2/a;->M(Landroid/os/Parcel;I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x1

    .line 8
    const/4 v2, 0x4

    .line 9
    invoke-static {p1, v1, v2}, LO2/a;->P(Landroid/os/Parcel;II)V

    .line 10
    .line 11
    .line 12
    iget v1, p0, LJ0/a;->a:I

    .line 13
    .line 14
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 15
    .line 16
    .line 17
    const/4 v1, 0x2

    .line 18
    invoke-static {p1, v1, v2}, LO2/a;->P(Landroid/os/Parcel;II)V

    .line 19
    .line 20
    .line 21
    iget v1, p0, LJ0/a;->b:I

    .line 22
    .line 23
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x3

    .line 27
    iget-object v3, p0, LJ0/a;->c:Landroid/app/PendingIntent;

    .line 28
    .line 29
    invoke-static {p1, v1, v3, p2}, LO2/a;->I(Landroid/os/Parcel;ILandroid/os/Parcelable;I)V

    .line 30
    .line 31
    .line 32
    iget-object p2, p0, LJ0/a;->d:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {p1, v2, p2}, LO2/a;->J(Landroid/os/Parcel;ILjava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-static {p1, v0}, LO2/a;->O(Landroid/os/Parcel;I)V

    .line 38
    .line 39
    .line 40
    return-void
.end method
