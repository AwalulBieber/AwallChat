###### Class N1.c (N1.c)
.class public LN1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LX1/b;


# instance fields
.field public e:Lb2/q;

.field public f:LC0/f;

.field public g:LN1/b;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final onAttachedToEngine(LX1/a;)V
    .registers 5

    .line 1
    iget-object v0, p1, LX1/a;->c:Lb2/f;

    .line 2
    .line 3
    new-instance v1, Lb2/q;

    .line 4
    .line 5
    const-string v2, "dev.fluttercommunity.plus/connectivity"

    .line 6
    .line 7
    invoke-direct {v1, v0, v2}, Lb2/q;-><init>(Lb2/f;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iput-object v1, p0, LN1/c;->e:Lb2/q;

    .line 11
    .line 12
    new-instance v1, LC0/f;

    .line 13
    .line 14
    const-string v2, "dev.fluttercommunity.plus/connectivity_status"

    .line 15
    .line 16
    invoke-direct {v1, v0, v2}, LC0/f;-><init>(Lb2/f;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iput-object v1, p0, LN1/c;->f:LC0/f;

    .line 20
    .line 21
    iget-object p1, p1, LX1/a;->a:Landroid/content/Context;

    .line 22
    .line 23
    const-string v0, "connectivity"

    .line 24
    .line 25
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Landroid/net/ConnectivityManager;

    .line 30
    .line 31
    new-instance v1, LD/i;

    .line 32
    .line 33
    const/16 v2, 0xa

    .line 34
    .line 35
    invoke-direct {v1, v2, v0}, LD/i;-><init>(ILjava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    new-instance v0, LA1/d;

    .line 39
    .line 40
    const/16 v2, 0x9

    .line 41
    .line 42
    invoke-direct {v0, v2, v1}, LA1/d;-><init>(ILjava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    new-instance v2, LN1/b;

    .line 46
    .line 47
    invoke-direct {v2, p1, v1}, LN1/b;-><init>(Landroid/content/Context;LD/i;)V

    .line 48
    .line 49
    .line 50
    iput-object v2, p0, LN1/c;->g:LN1/b;

    .line 51
    .line 52
    iget-object p1, p0, LN1/c;->e:Lb2/q;

    .line 53
    .line 54
    invoke-virtual {p1, v0}, Lb2/q;->b(Lb2/o;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, LN1/c;->f:LC0/f;

    .line 58
    .line 59
    iget-object v0, p0, LN1/c;->g:LN1/b;

    .line 60
    .line 61
    invoke-virtual {p1, v0}, LC0/f;->S(Lb2/h;)V

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public final onDetachedFromEngine(LX1/a;)V
    .registers 3

    .line 1
    iget-object p1, p0, LN1/c;->e:Lb2/q;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p1, v0}, Lb2/q;->b(Lb2/o;)V

    .line 5
    .line 6
    .line 7
    iget-object p1, p0, LN1/c;->f:LC0/f;

    .line 8
    .line 9
    invoke-virtual {p1, v0}, LC0/f;->S(Lb2/h;)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, LN1/c;->g:LN1/b;

    .line 13
    .line 14
    invoke-virtual {p1}, LN1/b;->o()V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, LN1/c;->e:Lb2/q;

    .line 18
    .line 19
    iput-object v0, p0, LN1/c;->f:LC0/f;

    .line 20
    .line 21
    iput-object v0, p0, LN1/c;->g:LN1/b;

    .line 22
    .line 23
    return-void
.end method
