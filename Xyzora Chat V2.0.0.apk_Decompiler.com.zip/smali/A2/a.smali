###### Class A2.a (A2.a)
.class public interface abstract LA2/a;
.super Ljava/lang/Object;
.source "SourceFile"
