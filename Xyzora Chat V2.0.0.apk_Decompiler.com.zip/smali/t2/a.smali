###### Class t2.a (t2.a)
.class public interface abstract Lt2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/List;
.implements LA2/a;
