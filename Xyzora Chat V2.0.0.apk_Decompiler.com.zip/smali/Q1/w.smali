###### Class Q1.w (Q1.w)
.class public interface abstract LQ1/w;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/view/KeyEvent;LM0/z;)V
.end method
