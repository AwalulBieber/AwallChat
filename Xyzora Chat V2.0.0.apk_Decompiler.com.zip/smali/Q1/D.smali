###### Class Q1.D (Q1.D)
.class public final LQ1/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lio/flutter/embedding/engine/renderer/k;


# instance fields
.field public final synthetic a:Ljava/lang/Runnable;

.field public final synthetic b:LQ1/F;


# direct methods
.method public constructor <init>(LQ1/F;Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LQ1/D;->b:LQ1/F;

    .line 5
    .line 6
    iput-object p2, p0, LQ1/D;->a:Ljava/lang/Runnable;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 1

    .line 1
    return-void
.end method

.method public final b()V
    .registers 2

    .line 1
    iget-object v0, p0, LQ1/D;->a:Ljava/lang/Runnable;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LQ1/D;->b:LQ1/F;

    .line 7
    .line 8
    iget-object v0, v0, LQ1/F;->b:Lio/flutter/embedding/engine/renderer/j;

    .line 9
    .line 10
    if-eqz v0, :cond_e

    .line 11
    .line 12
    invoke-virtual {v0, p0}, Lio/flutter/embedding/engine/renderer/j;->g(Lio/flutter/embedding/engine/renderer/k;)V

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method
