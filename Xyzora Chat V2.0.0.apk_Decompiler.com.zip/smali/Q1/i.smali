###### Class Q1.i (Q1.i)
.class public final LQ1/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# instance fields
.field public final synthetic a:LQ1/j;


# direct methods
.method public constructor <init>(LQ1/j;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LQ1/i;->a:LQ1/j;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .registers 5

    .line 1
    iget-object p1, p0, LQ1/i;->a:LQ1/j;

    .line 2
    .line 3
    iget-object p2, p1, LQ1/j;->g:Lio/flutter/embedding/engine/renderer/j;

    .line 4
    .line 5
    if-eqz p2, :cond_1a

    .line 6
    .line 7
    iget-boolean p1, p1, LQ1/j;->f:Z

    .line 8
    .line 9
    if-nez p1, :cond_1a

    .line 10
    .line 11
    if-eqz p2, :cond_12

    .line 12
    .line 13
    iget-object p1, p2, Lio/flutter/embedding/engine/renderer/j;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 14
    .line 15
    invoke-virtual {p1, p3, p4}, Lio/flutter/embedding/engine/FlutterJNI;->onSurfaceChanged(II)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    const-string p2, "changeSurfaceSize() should only be called when flutterRenderer is non-null."

    .line 22
    .line 23
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1

    .line 27
    :cond_1a
    return-void
.end method

.method public final surfaceCreated(Landroid/view/SurfaceHolder;)V
    .registers 4

    .line 1
    iget-object p1, p0, LQ1/i;->a:LQ1/j;

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    iput-boolean v0, p1, LQ1/j;->e:Z

    .line 5
    .line 6
    iget-object v1, p1, LQ1/j;->g:Lio/flutter/embedding/engine/renderer/j;

    .line 7
    .line 8
    if-eqz v1, :cond_e

    .line 9
    .line 10
    iget-boolean v1, p1, LQ1/j;->f:Z

    .line 11
    .line 12
    if-nez v1, :cond_e

    .line 13
    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    if-eqz v0, :cond_14

    .line 17
    .line 18
    invoke-virtual {p1}, LQ1/j;->e()V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public final surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .registers 4

    .line 1
    iget-object p1, p0, LQ1/i;->a:LQ1/j;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    iput-boolean v0, p1, LQ1/j;->e:Z

    .line 5
    .line 6
    iget-object v1, p1, LQ1/j;->g:Lio/flutter/embedding/engine/renderer/j;

    .line 7
    .line 8
    if-eqz v1, :cond_e

    .line 9
    .line 10
    iget-boolean p1, p1, LQ1/j;->f:Z

    .line 11
    .line 12
    if-nez p1, :cond_e

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    :cond_e
    if-eqz v0, :cond_1e

    .line 16
    .line 17
    if-eqz v1, :cond_16

    .line 18
    .line 19
    invoke-virtual {v1}, Lio/flutter/embedding/engine/renderer/j;->j()V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_16
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 24
    .line 25
    const-string v0, "disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null."

    .line 26
    .line 27
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw p1

    .line 31
    :cond_1e
    return-void
.end method
