###### Class Q1.p (Q1.p)
.class public final LQ1/p;
.super Landroid/widget/FrameLayout;
.source "SourceFile"

# interfaces
.implements Ld2/a;
.implements LQ1/x;


# instance fields
.field public final A:LG/a;

.field public final B:LQ1/n;

.field public final C:LQ1/e;

.field public D:LQ1/m;

.field public E:I

.field public F:I

.field public G:LQ1/r;

.field public final e:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public f:Z

.field public final g:LQ1/j;

.field public final h:LQ1/l;

.field public i:LQ1/h;

.field public j:Landroid/view/View;

.field public k:Landroid/view/View;

.field public final l:Ljava/util/HashSet;

.field public m:Z

.field public n:LR1/c;

.field public final o:Ljava/util/HashSet;

.field public p:Lb2/n;

.field public q:Lio/flutter/plugin/editing/j;

.field public r:Lio/flutter/plugin/editing/g;

.field public s:Lc2/a;

.field public t:LC0/f;

.field public u:LQ1/a;

.field public v:Lio/flutter/view/j;

.field public w:Landroid/view/textservice/TextServicesManager;

.field public x:LA1/d;

.field public final y:Lio/flutter/embedding/engine/renderer/i;

.field public final z:LD/i;


# direct methods
.method public constructor <init>(LQ1/d;LQ1/j;)V
    .registers 5

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, LQ1/p;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, LQ1/p;->f:Z

    .line 4
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, LQ1/p;->l:Ljava/util/HashSet;

    .line 5
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, LQ1/p;->o:Ljava/util/HashSet;

    .line 6
    new-instance p1, Lio/flutter/embedding/engine/renderer/i;

    invoke-direct {p1}, Lio/flutter/embedding/engine/renderer/i;-><init>()V

    iput-object p1, p0, LQ1/p;->y:Lio/flutter/embedding/engine/renderer/i;

    .line 7
    new-instance p1, LD/i;

    const/16 v0, 0xe

    invoke-direct {p1, v0, p0}, LD/i;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LQ1/p;->z:LD/i;

    .line 8
    new-instance p1, LG/a;

    new-instance v0, Landroid/os/Handler;

    .line 9
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x1

    invoke-direct {p1, p0, v0, v1}, LG/a;-><init>(Ljava/lang/Object;Landroid/os/Handler;I)V

    iput-object p1, p0, LQ1/p;->A:LG/a;

    .line 10
    new-instance p1, LQ1/n;

    invoke-direct {p1, p0}, LQ1/n;-><init>(LQ1/p;)V

    iput-object p1, p0, LQ1/p;->B:LQ1/n;

    .line 11
    new-instance p1, LQ1/e;

    const/4 v0, 0x1

    invoke-direct {p1, v0, p0}, LQ1/e;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LQ1/p;->C:LQ1/e;

    .line 12
    new-instance p1, LQ1/r;

    .line 13
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p1, p0, LQ1/p;->G:LQ1/r;

    .line 15
    iput-object p2, p0, LQ1/p;->g:LQ1/j;

    .line 16
    iput-object p2, p0, LQ1/p;->j:Landroid/view/View;

    .line 17
    invoke-virtual {p0}, LQ1/p;->b()V

    return-void
.end method

.method public constructor <init>(LQ1/d;LQ1/l;)V
    .registers 5

    const/4 v0, 0x0

    .line 18
    invoke-direct {p0, p1, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 19
    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, LQ1/p;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p1, 0x0

    .line 20
    iput-boolean p1, p0, LQ1/p;->f:Z

    .line 21
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, LQ1/p;->l:Ljava/util/HashSet;

    .line 22
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, LQ1/p;->o:Ljava/util/HashSet;

    .line 23
    new-instance p1, Lio/flutter/embedding/engine/renderer/i;

    invoke-direct {p1}, Lio/flutter/embedding/engine/renderer/i;-><init>()V

    iput-object p1, p0, LQ1/p;->y:Lio/flutter/embedding/engine/renderer/i;

    .line 24
    new-instance p1, LD/i;

    const/16 v0, 0xe

    invoke-direct {p1, v0, p0}, LD/i;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LQ1/p;->z:LD/i;

    .line 25
    new-instance p1, LG/a;

    new-instance v0, Landroid/os/Handler;

    .line 26
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x1

    invoke-direct {p1, p0, v0, v1}, LG/a;-><init>(Ljava/lang/Object;Landroid/os/Handler;I)V

    iput-object p1, p0, LQ1/p;->A:LG/a;

    .line 27
    new-instance p1, LQ1/n;

    invoke-direct {p1, p0}, LQ1/n;-><init>(LQ1/p;)V

    iput-object p1, p0, LQ1/p;->B:LQ1/n;

    .line 28
    new-instance p1, LQ1/e;

    const/4 v0, 0x1

    invoke-direct {p1, v0, p0}, LQ1/e;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, LQ1/p;->C:LQ1/e;

    .line 29
    new-instance p1, LQ1/r;

    .line 30
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 31
    iput-object p1, p0, LQ1/p;->G:LQ1/r;

    .line 32
    iput-object p2, p0, LQ1/p;->h:LQ1/l;

    .line 33
    iput-object p2, p0, LQ1/p;->j:Landroid/view/View;

    .line 34
    invoke-virtual {p0}, LQ1/p;->b()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 7

    .line 1
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, LQ1/p;->c()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_c

    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    iget-object v0, p0, LQ1/p;->o:Ljava/util/HashSet;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-nez v1, :cond_19d

    .line 24
    .line 25
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iget-object v1, p0, LQ1/p;->A:LG/a;

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 39
    .line 40
    iget-object v0, v0, LR1/c;->s:Lio/flutter/plugin/platform/p;

    .line 41
    .line 42
    const/4 v1, 0x0

    .line 43
    move v2, v1

    .line 44
    :goto_2b
    iget-object v3, v0, Lio/flutter/plugin/platform/p;->s:Landroid/util/SparseArray;

    .line 45
    .line 46
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 47
    .line 48
    .line 49
    move-result v4

    .line 50
    if-ge v2, v4, :cond_41

    .line 51
    .line 52
    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    check-cast v3, Lio/flutter/plugin/platform/h;

    .line 57
    .line 58
    iget-object v4, v0, Lio/flutter/plugin/platform/p;->h:LQ1/p;

    .line 59
    .line 60
    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 61
    .line 62
    .line 63
    add-int/lit8 v2, v2, 0x1

    .line 64
    .line 65
    goto :goto_2b

    .line 66
    :cond_41
    move v2, v1

    .line 67
    :goto_42
    iget-object v3, v0, Lio/flutter/plugin/platform/p;->q:Landroid/util/SparseArray;

    .line 68
    .line 69
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 70
    .line 71
    .line 72
    move-result v4

    .line 73
    if-ge v2, v4, :cond_58

    .line 74
    .line 75
    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    check-cast v3, LW1/b;

    .line 80
    .line 81
    iget-object v4, v0, Lio/flutter/plugin/platform/p;->h:LQ1/p;

    .line 82
    .line 83
    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 84
    .line 85
    .line 86
    add-int/lit8 v2, v2, 0x1

    .line 87
    .line 88
    goto :goto_42

    .line 89
    :cond_58
    invoke-virtual {v0}, Lio/flutter/plugin/platform/p;->d()V

    .line 90
    .line 91
    .line 92
    iget-object v2, v0, Lio/flutter/plugin/platform/p;->h:LQ1/p;

    .line 93
    .line 94
    if-nez v2, :cond_67

    .line 95
    .line 96
    const-string v2, "PlatformViewsController"

    .line 97
    .line 98
    const-string v3, "removeOverlaySurfaces called while flutter view is null"

    .line 99
    .line 100
    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 101
    .line 102
    .line 103
    goto :goto_81

    .line 104
    :cond_67
    move v2, v1

    .line 105
    :goto_68
    iget-object v3, v0, Lio/flutter/plugin/platform/p;->r:Landroid/util/SparseArray;

    .line 106
    .line 107
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 108
    .line 109
    .line 110
    move-result v4

    .line 111
    if-ge v2, v4, :cond_7e

    .line 112
    .line 113
    iget-object v4, v0, Lio/flutter/plugin/platform/p;->h:LQ1/p;

    .line 114
    .line 115
    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    check-cast v3, Landroid/view/View;

    .line 120
    .line 121
    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 122
    .line 123
    .line 124
    add-int/lit8 v2, v2, 0x1

    .line 125
    .line 126
    goto :goto_68

    .line 127
    :cond_7e
    invoke-virtual {v3}, Landroid/util/SparseArray;->clear()V

    .line 128
    .line 129
    .line 130
    :goto_81
    const/4 v2, 0x0

    .line 131
    iput-object v2, v0, Lio/flutter/plugin/platform/p;->h:LQ1/p;

    .line 132
    .line 133
    iput-boolean v1, v0, Lio/flutter/plugin/platform/p;->u:Z

    .line 134
    .line 135
    move v3, v1

    .line 136
    :goto_87
    iget-object v4, v0, Lio/flutter/plugin/platform/p;->p:Landroid/util/SparseArray;

    .line 137
    .line 138
    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    .line 139
    .line 140
    .line 141
    move-result v5

    .line 142
    if-ge v3, v5, :cond_9b

    .line 143
    .line 144
    invoke-virtual {v4, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v4

    .line 148
    check-cast v4, Lio/flutter/plugin/platform/f;

    .line 149
    .line 150
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 151
    .line 152
    .line 153
    add-int/lit8 v3, v3, 0x1

    .line 154
    .line 155
    goto :goto_87

    .line 156
    :cond_9b
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 157
    .line 158
    iget-object v0, v0, LR1/c;->t:Lio/flutter/plugin/platform/o;

    .line 159
    .line 160
    move v3, v1

    .line 161
    :goto_a0
    iget-object v4, v0, Lio/flutter/plugin/platform/o;->n:Landroid/util/SparseArray;

    .line 162
    .line 163
    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    .line 164
    .line 165
    .line 166
    move-result v5

    .line 167
    if-ge v3, v5, :cond_b6

    .line 168
    .line 169
    invoke-virtual {v4, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v4

    .line 173
    check-cast v4, LW1/b;

    .line 174
    .line 175
    iget-object v5, v0, Lio/flutter/plugin/platform/o;->h:LQ1/p;

    .line 176
    .line 177
    invoke-virtual {v5, v4}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 178
    .line 179
    .line 180
    add-int/lit8 v3, v3, 0x1

    .line 181
    .line 182
    goto :goto_a0

    .line 183
    :cond_b6
    iget-object v3, v0, Lio/flutter/plugin/platform/o;->r:Landroid/view/Surface;

    .line 184
    .line 185
    if-eqz v3, :cond_c1

    .line 186
    .line 187
    invoke-virtual {v3}, Landroid/view/Surface;->release()V

    .line 188
    .line 189
    .line 190
    iput-object v2, v0, Lio/flutter/plugin/platform/o;->r:Landroid/view/Surface;

    .line 191
    .line 192
    iput-object v2, v0, Lio/flutter/plugin/platform/o;->s:Landroid/view/SurfaceControl;

    .line 193
    .line 194
    :cond_c1
    iput-object v2, v0, Lio/flutter/plugin/platform/o;->h:LQ1/p;

    .line 195
    .line 196
    move v3, v1

    .line 197
    :goto_c4
    iget-object v4, v0, Lio/flutter/plugin/platform/o;->m:Landroid/util/SparseArray;

    .line 198
    .line 199
    invoke-virtual {v4}, Landroid/util/SparseArray;->size()I

    .line 200
    .line 201
    .line 202
    move-result v5

    .line 203
    if-ge v3, v5, :cond_d8

    .line 204
    .line 205
    invoke-virtual {v4, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    check-cast v4, Lio/flutter/plugin/platform/f;

    .line 210
    .line 211
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 212
    .line 213
    .line 214
    add-int/lit8 v3, v3, 0x1

    .line 215
    .line 216
    goto :goto_c4

    .line 217
    :cond_d8
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 218
    .line 219
    iget-object v0, v0, LR1/c;->s:Lio/flutter/plugin/platform/p;

    .line 220
    .line 221
    invoke-virtual {v0}, Lio/flutter/plugin/platform/p;->b()V

    .line 222
    .line 223
    .line 224
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 225
    .line 226
    iget-object v0, v0, LR1/c;->t:Lio/flutter/plugin/platform/o;

    .line 227
    .line 228
    invoke-virtual {v0}, Lio/flutter/plugin/platform/o;->b()V

    .line 229
    .line 230
    .line 231
    iget-object v0, p0, LQ1/p;->v:Lio/flutter/view/j;

    .line 232
    .line 233
    const/4 v3, 0x1

    .line 234
    iput-boolean v3, v0, Lio/flutter/view/j;->u:Z

    .line 235
    .line 236
    iget-object v3, v0, Lio/flutter/view/j;->e:Lio/flutter/plugin/platform/i;

    .line 237
    .line 238
    invoke-interface {v3}, Lio/flutter/plugin/platform/i;->b()V

    .line 239
    .line 240
    .line 241
    iput-object v2, v0, Lio/flutter/view/j;->s:LD/i;

    .line 242
    .line 243
    iget-object v3, v0, Lio/flutter/view/j;->c:Landroid/view/accessibility/AccessibilityManager;

    .line 244
    .line 245
    iget-object v4, v0, Lio/flutter/view/j;->v:Lio/flutter/view/e;

    .line 246
    .line 247
    invoke-virtual {v3, v4}, Landroid/view/accessibility/AccessibilityManager;->removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;)Z

    .line 248
    .line 249
    .line 250
    iget-object v4, v0, Lio/flutter/view/j;->w:Lio/flutter/view/f;

    .line 251
    .line 252
    invoke-virtual {v3, v4}, Landroid/view/accessibility/AccessibilityManager;->removeTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z

    .line 253
    .line 254
    .line 255
    iget-object v3, v0, Lio/flutter/view/j;->x:LG/a;

    .line 256
    .line 257
    iget-object v4, v0, Lio/flutter/view/j;->f:Landroid/content/ContentResolver;

    .line 258
    .line 259
    invoke-virtual {v4, v3}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 260
    .line 261
    .line 262
    iget-object v0, v0, Lio/flutter/view/j;->b:LC0/f;

    .line 263
    .line 264
    iput-object v2, v0, LC0/f;->h:Ljava/lang/Object;

    .line 265
    .line 266
    iget-object v0, v0, LC0/f;->g:Ljava/lang/Object;

    .line 267
    .line 268
    check-cast v0, Lio/flutter/embedding/engine/FlutterJNI;

    .line 269
    .line 270
    invoke-virtual {v0, v2}, Lio/flutter/embedding/engine/FlutterJNI;->setAccessibilityDelegate(LR1/j;)V

    .line 271
    .line 272
    .line 273
    iput-object v2, p0, LQ1/p;->v:Lio/flutter/view/j;

    .line 274
    .line 275
    iget-object v0, p0, LQ1/p;->q:Lio/flutter/plugin/editing/j;

    .line 276
    .line 277
    iget-object v0, v0, Lio/flutter/plugin/editing/j;->b:Landroid/view/inputmethod/InputMethodManager;

    .line 278
    .line 279
    invoke-virtual {v0, p0}, Landroid/view/inputmethod/InputMethodManager;->restartInput(Landroid/view/View;)V

    .line 280
    .line 281
    .line 282
    iget-object v0, p0, LQ1/p;->q:Lio/flutter/plugin/editing/j;

    .line 283
    .line 284
    invoke-virtual {v0}, Lio/flutter/plugin/editing/j;->c()V

    .line 285
    .line 286
    .line 287
    iget-object v0, p0, LQ1/p;->t:LC0/f;

    .line 288
    .line 289
    iget-object v0, v0, LC0/f;->g:Ljava/lang/Object;

    .line 290
    .line 291
    check-cast v0, Ljava/util/HashSet;

    .line 292
    .line 293
    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    .line 294
    .line 295
    .line 296
    move-result v0

    .line 297
    if-lez v0, :cond_142

    .line 298
    .line 299
    new-instance v3, Ljava/lang/StringBuilder;

    .line 300
    .line 301
    const-string v4, "A KeyboardManager was destroyed with "

    .line 302
    .line 303
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 307
    .line 308
    .line 309
    const-string v0, " unhandled redispatch event(s)."

    .line 310
    .line 311
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 312
    .line 313
    .line 314
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    const-string v3, "KeyboardManager"

    .line 319
    .line 320
    invoke-static {v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 321
    .line 322
    .line 323
    :cond_142
    iget-object v0, p0, LQ1/p;->r:Lio/flutter/plugin/editing/g;

    .line 324
    .line 325
    if-eqz v0, :cond_151

    .line 326
    .line 327
    iget-object v3, v0, Lio/flutter/plugin/editing/g;->a:LA1/d;

    .line 328
    .line 329
    iput-object v2, v3, LA1/d;->f:Ljava/lang/Object;

    .line 330
    .line 331
    iget-object v0, v0, Lio/flutter/plugin/editing/g;->c:Landroid/view/textservice/SpellCheckerSession;

    .line 332
    .line 333
    if-eqz v0, :cond_151

    .line 334
    .line 335
    invoke-virtual {v0}, Landroid/view/textservice/SpellCheckerSession;->close()V

    .line 336
    .line 337
    .line 338
    :cond_151
    iget-object v0, p0, LQ1/p;->p:Lb2/n;

    .line 339
    .line 340
    if-eqz v0, :cond_15b

    .line 341
    .line 342
    iget-object v0, v0, Lb2/n;->f:Ljava/lang/Object;

    .line 343
    .line 344
    check-cast v0, LA1/d;

    .line 345
    .line 346
    iput-object v2, v0, LA1/d;->f:Ljava/lang/Object;

    .line 347
    .line 348
    :cond_15b
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 349
    .line 350
    iget-object v0, v0, LR1/c;->b:Lio/flutter/embedding/engine/renderer/j;

    .line 351
    .line 352
    iput-boolean v1, p0, LQ1/p;->m:Z

    .line 353
    .line 354
    iget-object v3, p0, LQ1/p;->C:LQ1/e;

    .line 355
    .line 356
    invoke-virtual {v0, v3}, Lio/flutter/embedding/engine/renderer/j;->g(Lio/flutter/embedding/engine/renderer/k;)V

    .line 357
    .line 358
    .line 359
    iget-boolean v3, p0, LQ1/p;->f:Z

    .line 360
    .line 361
    iget-object v4, v0, Lio/flutter/embedding/engine/renderer/j;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 362
    .line 363
    if-eqz v3, :cond_171

    .line 364
    .line 365
    iget-object v3, p0, LQ1/p;->B:LQ1/n;

    .line 366
    .line 367
    invoke-virtual {v4, v3}, Lio/flutter/embedding/engine/FlutterJNI;->removeResizingFlutterUiListener(Lio/flutter/embedding/engine/renderer/l;)V

    .line 368
    .line 369
    .line 370
    :cond_171
    invoke-virtual {v0}, Lio/flutter/embedding/engine/renderer/j;->j()V

    .line 371
    .line 372
    .line 373
    invoke-virtual {v4, v1}, Lio/flutter/embedding/engine/FlutterJNI;->setSemanticsEnabled(Z)V

    .line 374
    .line 375
    .line 376
    iget-object v0, p0, LQ1/p;->k:Landroid/view/View;

    .line 377
    .line 378
    if-eqz v0, :cond_183

    .line 379
    .line 380
    iget-object v1, p0, LQ1/p;->j:Landroid/view/View;

    .line 381
    .line 382
    iget-object v3, p0, LQ1/p;->i:LQ1/h;

    .line 383
    .line 384
    if-ne v1, v3, :cond_183

    .line 385
    .line 386
    iput-object v0, p0, LQ1/p;->j:Landroid/view/View;

    .line 387
    .line 388
    :cond_183
    iget-object v0, p0, LQ1/p;->j:Landroid/view/View;

    .line 389
    .line 390
    invoke-interface {v0}, Lio/flutter/embedding/engine/renderer/m;->c()V

    .line 391
    .line 392
    .line 393
    iget-object v0, p0, LQ1/p;->i:LQ1/h;

    .line 394
    .line 395
    if-eqz v0, :cond_198

    .line 396
    .line 397
    iget-object v0, v0, LQ1/h;->e:Landroid/media/ImageReader;

    .line 398
    .line 399
    invoke-virtual {v0}, Landroid/media/ImageReader;->close()V

    .line 400
    .line 401
    .line 402
    iget-object v0, p0, LQ1/p;->i:LQ1/h;

    .line 403
    .line 404
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 405
    .line 406
    .line 407
    iput-object v2, p0, LQ1/p;->i:LQ1/h;

    .line 408
    .line 409
    :cond_198
    iput-object v2, p0, LQ1/p;->k:Landroid/view/View;

    .line 410
    .line 411
    iput-object v2, p0, LQ1/p;->n:LR1/c;

    .line 412
    .line 413
    return-void

    .line 414
    :cond_19d
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 415
    .line 416
    .line 417
    move-result-object v0

    .line 418
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 419
    .line 420
    .line 421
    new-instance v0, Ljava/lang/ClassCastException;

    .line 422
    .line 423
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 424
    .line 425
    .line 426
    throw v0
.end method

.method public final autofill(Landroid/util/SparseArray;)V
    .registers 16

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    iget-object v2, p0, LQ1/p;->q:Lio/flutter/plugin/editing/j;

    .line 4
    .line 5
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 6
    .line 7
    const/16 v4, 0x1a

    .line 8
    .line 9
    if-ge v3, v4, :cond_e

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_e
    iget-object v3, v2, Lio/flutter/plugin/editing/j;->f:La2/n;

    .line 16
    .line 17
    if-eqz v3, :cond_cc

    .line 18
    .line 19
    iget-object v4, v2, Lio/flutter/plugin/editing/j;->g:Landroid/util/SparseArray;

    .line 20
    .line 21
    if-eqz v4, :cond_cc

    .line 22
    .line 23
    iget-object v3, v3, La2/n;->j:Ly1/z;

    .line 24
    .line 25
    if-nez v3, :cond_1c

    .line 26
    .line 27
    goto/16 :goto_cc

    .line 28
    .line 29
    :cond_1c
    new-instance v4, Ljava/util/HashMap;

    .line 30
    .line 31
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 32
    .line 33
    .line 34
    move v5, v1

    .line 35
    :goto_22
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    .line 36
    .line 37
    .line 38
    move-result v6

    .line 39
    if-ge v5, v6, :cond_73

    .line 40
    .line 41
    invoke-virtual {p1, v5}, Landroid/util/SparseArray;->keyAt(I)I

    .line 42
    .line 43
    .line 44
    move-result v6

    .line 45
    iget-object v7, v2, Lio/flutter/plugin/editing/j;->g:Landroid/util/SparseArray;

    .line 46
    .line 47
    invoke-virtual {v7, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    check-cast v6, La2/n;

    .line 52
    .line 53
    if-eqz v6, :cond_71

    .line 54
    .line 55
    iget-object v6, v6, La2/n;->j:Ly1/z;

    .line 56
    .line 57
    if-nez v6, :cond_3b

    .line 58
    .line 59
    goto :goto_71

    .line 60
    :cond_3b
    invoke-virtual {p1, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v7

    .line 64
    invoke-static {v7}, Lcom/dexterous/flutterlocalnotifications/a;->m(Ljava/lang/Object;)Landroid/view/autofill/AutofillValue;

    .line 65
    .line 66
    .line 67
    move-result-object v7

    .line 68
    invoke-static {v7}, Lio/flutter/plugin/editing/i;->f(Landroid/view/autofill/AutofillValue;)Ljava/lang/CharSequence;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    invoke-interface {v7}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v9

    .line 76
    new-instance v8, La2/p;

    .line 77
    .line 78
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 79
    .line 80
    .line 81
    move-result v10

    .line 82
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 83
    .line 84
    .line 85
    move-result v11

    .line 86
    const/4 v12, -0x1

    .line 87
    const/4 v13, -0x1

    .line 88
    invoke-direct/range {v8 .. v13}, La2/p;-><init>(Ljava/lang/String;IIII)V

    .line 89
    .line 90
    .line 91
    iget-object v6, v6, Ly1/z;->e:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v6, Ljava/lang/String;

    .line 94
    .line 95
    iget-object v7, v3, Ly1/z;->e:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast v7, Ljava/lang/String;

    .line 98
    .line 99
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v7

    .line 103
    if-eqz v7, :cond_6e

    .line 104
    .line 105
    iget-object v6, v2, Lio/flutter/plugin/editing/j;->h:Lio/flutter/plugin/editing/f;

    .line 106
    .line 107
    invoke-virtual {v6, v8}, Lio/flutter/plugin/editing/f;->f(La2/p;)V

    .line 108
    .line 109
    .line 110
    goto :goto_71

    .line 111
    :cond_6e
    invoke-virtual {v4, v6, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    :cond_71
    :goto_71
    add-int/2addr v5, v0

    .line 115
    goto :goto_22

    .line 116
    :cond_73
    iget-object p1, v2, Lio/flutter/plugin/editing/j;->e:LC/j;

    .line 117
    .line 118
    iget p1, p1, LC/j;->c:I

    .line 119
    .line 120
    iget-object v2, v2, Lio/flutter/plugin/editing/j;->d:LE0/j;

    .line 121
    .line 122
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v4}, Ljava/util/HashMap;->size()I

    .line 126
    .line 127
    .line 128
    new-instance v3, Ljava/util/HashMap;

    .line 129
    .line 130
    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v4}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 134
    .line 135
    .line 136
    move-result-object v4

    .line 137
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 138
    .line 139
    .line 140
    move-result-object v4

    .line 141
    :goto_8c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 142
    .line 143
    .line 144
    move-result v5

    .line 145
    if-eqz v5, :cond_b3

    .line 146
    .line 147
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v5

    .line 151
    check-cast v5, Ljava/util/Map$Entry;

    .line 152
    .line 153
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v6

    .line 157
    check-cast v6, La2/p;

    .line 158
    .line 159
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object v5

    .line 163
    check-cast v5, Ljava/lang/String;

    .line 164
    .line 165
    iget-object v7, v6, La2/p;->a:Ljava/lang/String;

    .line 166
    .line 167
    iget v8, v6, La2/p;->b:I

    .line 168
    .line 169
    iget v6, v6, La2/p;->c:I

    .line 170
    .line 171
    const/4 v9, -0x1

    .line 172
    invoke-static {v7, v8, v6, v9, v9}, LE0/j;->j(Ljava/lang/String;IIII)Ljava/util/HashMap;

    .line 173
    .line 174
    .line 175
    move-result-object v6

    .line 176
    invoke-virtual {v3, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    goto :goto_8c

    .line 180
    :cond_b3
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    const/4 v4, 0x2

    .line 185
    new-array v4, v4, [Ljava/io/Serializable;

    .line 186
    .line 187
    aput-object p1, v4, v1

    .line 188
    .line 189
    aput-object v3, v4, v0

    .line 190
    .line 191
    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    iget-object v0, v2, LE0/j;->f:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast v0, Lb2/q;

    .line 198
    .line 199
    const-string v1, "TextInputClient.updateEditingStateWithTag"

    .line 200
    .line 201
    const/4 v2, 0x0

    .line 202
    invoke-virtual {v0, v1, p1, v2}, Lb2/q;->a(Ljava/lang/String;Ljava/lang/Object;Lb2/p;)V

    .line 203
    .line 204
    .line 205
    :cond_cc
    :goto_cc
    return-void
.end method

.method public final b()V
    .registers 3

    .line 1
    iget-object v0, p0, LQ1/p;->g:LQ1/j;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 6
    .line 7
    .line 8
    goto :goto_15

    .line 9
    :cond_8
    iget-object v0, p0, LQ1/p;->h:LQ1/l;

    .line 10
    .line 11
    if-eqz v0, :cond_10

    .line 12
    .line 13
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 14
    .line 15
    .line 16
    goto :goto_15

    .line 17
    :cond_10
    iget-object v0, p0, LQ1/p;->i:LQ1/h;

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 20
    .line 21
    .line 22
    :goto_15
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v0}, Landroid/support/v4/media/session/a;->x(Landroid/content/Context;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    iput-boolean v0, p0, LQ1/p;->f:Z

    .line 31
    .line 32
    const/4 v0, 0x1

    .line 33
    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 37
    .line 38
    .line 39
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 40
    .line 41
    const/16 v1, 0x1a

    .line 42
    .line 43
    if-lt v0, v1, :cond_2f

    .line 44
    .line 45
    invoke-static {p0}, LA/a;->q(LQ1/p;)V

    .line 46
    .line 47
    .line 48
    :cond_2f
    return-void
.end method

.method public final c()Z
    .registers 3

    .line 1
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 2
    .line 3
    if-eqz v0, :cond_10

    .line 4
    .line 5
    iget-object v1, p0, LQ1/p;->j:Landroid/view/View;

    .line 6
    .line 7
    invoke-interface {v1}, Lio/flutter/embedding/engine/renderer/m;->getAttachedRenderer()Lio/flutter/embedding/engine/renderer/j;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    iget-object v0, v0, LR1/c;->b:Lio/flutter/embedding/engine/renderer/j;

    .line 12
    .line 13
    if-ne v0, v1, :cond_10

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    return v0

    .line 17
    :cond_10
    const/4 v0, 0x0

    .line 18
    return v0
.end method

.method public final checkInputConnectionProxy(Landroid/view/View;)Z
    .registers 5

    .line 1
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 2
    .line 3
    if-eqz v0, :cond_2d

    .line 4
    .line 5
    iget-object v0, v0, LR1/c;->s:Lio/flutter/plugin/platform/p;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-nez p1, :cond_d

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    return v1

    .line 14
    :cond_d
    iget-object v0, v0, Lio/flutter/plugin/platform/p;->o:Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    if-nez v2, :cond_1a

    .line 25
    .line 26
    return v1

    .line 27
    :cond_1a
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Landroid/view/View;

    .line 36
    .line 37
    if-ne v0, p1, :cond_28

    .line 38
    .line 39
    const/4 p1, 0x1

    .line 40
    return p1

    .line 41
    :cond_28
    invoke-virtual {v0, p1}, Landroid/view/View;->checkInputConnectionProxy(Landroid/view/View;)Z

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    return p1

    .line 46
    :cond_2d
    invoke-super {p0, p1}, Landroid/view/View;->checkInputConnectionProxy(Landroid/view/View;)Z

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    return p1
.end method

.method public final d()V
    .registers 10

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget v0, v0, Landroid/content/res/Configuration;->uiMode:I

    .line 10
    .line 11
    and-int/lit8 v0, v0, 0x30

    .line 12
    .line 13
    const/16 v1, 0x20

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    if-ne v0, v1, :cond_13

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    move v0, v2

    .line 21
    :goto_14
    iget-object v1, p0, LQ1/p;->w:Landroid/view/textservice/TextServicesManager;

    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    if-eqz v1, :cond_4e

    .line 25
    .line 26
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 27
    .line 28
    const/16 v5, 0x1f

    .line 29
    .line 30
    if-lt v4, v5, :cond_4c

    .line 31
    .line 32
    invoke-static {v1}, LM0/w;->i(Landroid/view/textservice/TextServicesManager;)Ljava/util/List;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    :cond_27
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    if-eqz v4, :cond_41

    .line 45
    .line 46
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    check-cast v4, Landroid/view/textservice/SpellCheckerInfo;

    .line 51
    .line 52
    invoke-virtual {v4}, Landroid/view/textservice/SpellCheckerInfo;->getPackageName()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    const-string v5, "com.google.android.inputmethod.latin"

    .line 57
    .line 58
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v4

    .line 62
    if-eqz v4, :cond_27

    .line 63
    .line 64
    move v1, v2

    .line 65
    goto :goto_42

    .line 66
    :cond_41
    move v1, v3

    .line 67
    :goto_42
    iget-object v4, p0, LQ1/p;->w:Landroid/view/textservice/TextServicesManager;

    .line 68
    .line 69
    invoke-static {v4}, LM0/w;->p(Landroid/view/textservice/TextServicesManager;)Z

    .line 70
    .line 71
    .line 72
    move-result v4

    .line 73
    if-eqz v4, :cond_4e

    .line 74
    .line 75
    if-eqz v1, :cond_4e

    .line 76
    .line 77
    :cond_4c
    move v1, v2

    .line 78
    goto :goto_4f

    .line 79
    :cond_4e
    move v1, v3

    .line 80
    :goto_4f
    iget-object v4, p0, LQ1/p;->n:LR1/c;

    .line 81
    .line 82
    iget-object v4, v4, LR1/c;->o:La2/m;

    .line 83
    .line 84
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    new-instance v5, Ljava/util/HashMap;

    .line 88
    .line 89
    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    .line 90
    .line 91
    .line 92
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    invoke-virtual {v6}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 97
    .line 98
    .line 99
    move-result-object v6

    .line 100
    iget v6, v6, Landroid/content/res/Configuration;->fontScale:F

    .line 101
    .line 102
    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 103
    .line 104
    .line 105
    move-result-object v6

    .line 106
    const-string v7, "textScaleFactor"

    .line 107
    .line 108
    invoke-virtual {v5, v7, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 112
    .line 113
    .line 114
    move-result-object v6

    .line 115
    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    const-string v8, "nativeSpellCheckServiceDefined"

    .line 124
    .line 125
    invoke-virtual {v5, v8, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    const-string v8, "show_password"

    .line 137
    .line 138
    invoke-static {v1, v8, v2}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    if-ne v1, v2, :cond_91

    .line 143
    .line 144
    move v1, v2

    .line 145
    goto :goto_92

    .line 146
    :cond_91
    move v1, v3

    .line 147
    :goto_92
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 148
    .line 149
    .line 150
    move-result-object v1

    .line 151
    const-string v8, "brieflyShowPassword"

    .line 152
    .line 153
    invoke-virtual {v5, v8, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    invoke-static {v1}, Landroid/text/format/DateFormat;->is24HourFormat(Landroid/content/Context;)Z

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    const-string v8, "alwaysUse24HourFormat"

    .line 169
    .line 170
    invoke-virtual {v5, v8, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    const/4 v1, 0x1

    .line 174
    if-eq v0, v1, :cond_b7

    .line 175
    .line 176
    const/4 v1, 0x2

    .line 177
    if-ne v0, v1, :cond_b5

    .line 178
    .line 179
    const-string v0, "dark"

    .line 180
    .line 181
    goto :goto_b9

    .line 182
    :cond_b5
    const/4 v0, 0x0

    .line 183
    throw v0

    .line 184
    :cond_b7
    const-string v0, "light"

    .line 185
    .line 186
    :goto_b9
    const-string v1, "platformBrightness"

    .line 187
    .line 188
    invoke-virtual {v5, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    invoke-virtual {v5, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    invoke-virtual {v5, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v5, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v0

    .line 209
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 213
    .line 214
    const/16 v1, 0x22

    .line 215
    .line 216
    if-lt v0, v1, :cond_da

    .line 217
    .line 218
    goto :goto_db

    .line 219
    :cond_da
    move v2, v3

    .line 220
    :goto_db
    iget-object v0, v4, La2/m;->b:Ly1/z;

    .line 221
    .line 222
    const/4 v1, 0x0

    .line 223
    if-eqz v2, :cond_111

    .line 224
    .line 225
    if-nez v6, :cond_e3

    .line 226
    .line 227
    goto :goto_111

    .line 228
    :cond_e3
    new-instance v2, La2/l;

    .line 229
    .line 230
    invoke-direct {v2, v6}, La2/l;-><init>(Landroid/util/DisplayMetrics;)V

    .line 231
    .line 232
    .line 233
    iget-object v3, v4, La2/m;->a:LC0/f;

    .line 234
    .line 235
    iget-object v4, v3, LC0/f;->f:Ljava/lang/Object;

    .line 236
    .line 237
    check-cast v4, Ljava/util/concurrent/ConcurrentLinkedQueue;

    .line 238
    .line 239
    invoke-virtual {v4, v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;->add(Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    iget-object v4, v3, LC0/f;->h:Ljava/lang/Object;

    .line 243
    .line 244
    check-cast v4, La2/l;

    .line 245
    .line 246
    iput-object v2, v3, LC0/f;->h:Ljava/lang/Object;

    .line 247
    .line 248
    if-nez v4, :cond_fa

    .line 249
    .line 250
    goto :goto_102

    .line 251
    :cond_fa
    new-instance v1, LE0/j;

    .line 252
    .line 253
    const/16 v6, 0x19

    .line 254
    .line 255
    const/4 v7, 0x0

    .line 256
    invoke-direct {v1, v3, v4, v6, v7}, LE0/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 257
    .line 258
    .line 259
    :goto_102
    iget v2, v2, La2/l;->a:I

    .line 260
    .line 261
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 262
    .line 263
    .line 264
    move-result-object v2

    .line 265
    const-string v3, "configurationId"

    .line 266
    .line 267
    invoke-virtual {v5, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    invoke-virtual {v0, v5, v1}, Ly1/z;->i(Ljava/lang/Object;Lb2/c;)V

    .line 271
    .line 272
    .line 273
    return-void

    .line 274
    :cond_111
    :goto_111
    invoke-virtual {v0, v5, v1}, Ly1/z;->i(Ljava/lang/Object;Lb2/c;)V

    .line 275
    .line 276
    .line 277
    return-void
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .registers 4

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_15

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_15

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0, p1, p0}, Landroid/view/KeyEvent$DispatcherState;->startTracking(Landroid/view/KeyEvent;Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    goto :goto_22

    .line 22
    :cond_15
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-ne v0, v1, :cond_22

    .line 27
    .line 28
    invoke-virtual {p0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0, p1}, Landroid/view/KeyEvent$DispatcherState;->handleUpEvent(Landroid/view/KeyEvent;)V

    .line 33
    .line 34
    .line 35
    :cond_22
    :goto_22
    invoke-virtual {p0}, LQ1/p;->c()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_30

    .line 40
    .line 41
    iget-object v0, p0, LQ1/p;->t:LC0/f;

    .line 42
    .line 43
    invoke-virtual {v0, p1}, LC0/f;->H(Landroid/view/KeyEvent;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-nez v0, :cond_36

    .line 48
    .line 49
    :cond_30
    invoke-super {p0, p1}, Landroid/view/View;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    if-eqz p1, :cond_37

    .line 54
    .line 55
    :cond_36
    return v1

    .line 56
    :cond_37
    const/4 p1, 0x0

    .line 57
    return p1
.end method

.method public final e()V
    .registers 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual {v0}, LQ1/p;->c()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_10

    .line 8
    .line 9
    const-string v1, "FlutterView"

    .line 10
    .line 11
    const-string v2, "Tried to send viewport metrics from Android to Flutter but this FlutterView was not attached to a FlutterEngine."

    .line 12
    .line 13
    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_10
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 26
    .line 27
    iget-object v2, v0, LQ1/p;->y:Lio/flutter/embedding/engine/renderer/i;

    .line 28
    .line 29
    iput v1, v2, Lio/flutter/embedding/engine/renderer/i;->a:F

    .line 30
    .line 31
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-static {v1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    iput v1, v2, Lio/flutter/embedding/engine/renderer/i;->t:I

    .line 44
    .line 45
    iget-object v1, v0, LQ1/p;->n:LR1/c;

    .line 46
    .line 47
    iget-object v1, v1, LR1/c;->b:Lio/flutter/embedding/engine/renderer/j;

    .line 48
    .line 49
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    iget v3, v2, Lio/flutter/embedding/engine/renderer/i;->b:I

    .line 53
    .line 54
    if-nez v3, :cond_40

    .line 55
    .line 56
    iget v3, v2, Lio/flutter/embedding/engine/renderer/i;->d:I

    .line 57
    .line 58
    iget v4, v2, Lio/flutter/embedding/engine/renderer/i;->e:I

    .line 59
    .line 60
    if-gtz v3, :cond_58

    .line 61
    .line 62
    if-lez v4, :cond_144

    .line 63
    .line 64
    goto :goto_58

    .line 65
    :cond_40
    iget v4, v2, Lio/flutter/embedding/engine/renderer/i;->c:I

    .line 66
    .line 67
    if-nez v4, :cond_4d

    .line 68
    .line 69
    iget v3, v2, Lio/flutter/embedding/engine/renderer/i;->f:I

    .line 70
    .line 71
    iget v4, v2, Lio/flutter/embedding/engine/renderer/i;->g:I

    .line 72
    .line 73
    if-gtz v3, :cond_58

    .line 74
    .line 75
    if-lez v4, :cond_144

    .line 76
    .line 77
    goto :goto_58

    .line 78
    :cond_4d
    if-lez v3, :cond_144

    .line 79
    .line 80
    if-lez v4, :cond_144

    .line 81
    .line 82
    iget v3, v2, Lio/flutter/embedding/engine/renderer/i;->a:F

    .line 83
    .line 84
    const/4 v4, 0x0

    .line 85
    cmpl-float v3, v3, v4

    .line 86
    .line 87
    if-lez v3, :cond_144

    .line 88
    .line 89
    :cond_58
    :goto_58
    iget-object v3, v2, Lio/flutter/embedding/engine/renderer/i;->u:Ljava/util/ArrayList;

    .line 90
    .line 91
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 92
    .line 93
    .line 94
    iget-object v4, v2, Lio/flutter/embedding/engine/renderer/i;->v:Ljava/util/ArrayList;

    .line 95
    .line 96
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 97
    .line 98
    .line 99
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 100
    .line 101
    .line 102
    move-result v5

    .line 103
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 104
    .line 105
    .line 106
    move-result v6

    .line 107
    add-int/2addr v6, v5

    .line 108
    mul-int/lit8 v5, v6, 0x4

    .line 109
    .line 110
    new-array v5, v5, [I

    .line 111
    .line 112
    new-array v7, v6, [I

    .line 113
    .line 114
    new-array v6, v6, [I

    .line 115
    .line 116
    const/4 v8, 0x0

    .line 117
    move v9, v8

    .line 118
    :goto_75
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 119
    .line 120
    .line 121
    move-result v10

    .line 122
    if-ge v9, v10, :cond_ae

    .line 123
    .line 124
    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v10

    .line 128
    check-cast v10, Lio/flutter/embedding/engine/renderer/a;

    .line 129
    .line 130
    mul-int/lit8 v11, v9, 0x4

    .line 131
    .line 132
    iget-object v12, v10, Lio/flutter/embedding/engine/renderer/a;->a:Landroid/graphics/Rect;

    .line 133
    .line 134
    iget v13, v12, Landroid/graphics/Rect;->left:I

    .line 135
    .line 136
    aput v13, v5, v11

    .line 137
    .line 138
    add-int/lit8 v13, v11, 0x1

    .line 139
    .line 140
    iget v14, v12, Landroid/graphics/Rect;->top:I

    .line 141
    .line 142
    aput v14, v5, v13

    .line 143
    .line 144
    add-int/lit8 v13, v11, 0x2

    .line 145
    .line 146
    iget v14, v12, Landroid/graphics/Rect;->right:I

    .line 147
    .line 148
    aput v14, v5, v13

    .line 149
    .line 150
    add-int/lit8 v11, v11, 0x3

    .line 151
    .line 152
    iget v12, v12, Landroid/graphics/Rect;->bottom:I

    .line 153
    .line 154
    aput v12, v5, v11

    .line 155
    .line 156
    iget v11, v10, Lio/flutter/embedding/engine/renderer/a;->b:I

    .line 157
    .line 158
    invoke-static {v11}, LK/j;->b(I)I

    .line 159
    .line 160
    .line 161
    move-result v11

    .line 162
    aput v11, v7, v9

    .line 163
    .line 164
    iget v10, v10, Lio/flutter/embedding/engine/renderer/a;->c:I

    .line 165
    .line 166
    invoke-static {v10}, LK/j;->b(I)I

    .line 167
    .line 168
    .line 169
    move-result v10

    .line 170
    aput v10, v6, v9

    .line 171
    .line 172
    add-int/lit8 v9, v9, 0x1

    .line 173
    .line 174
    goto :goto_75

    .line 175
    :cond_ae
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 176
    .line 177
    .line 178
    move-result v9

    .line 179
    mul-int/lit8 v9, v9, 0x4

    .line 180
    .line 181
    :goto_b4
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 182
    .line 183
    .line 184
    move-result v10

    .line 185
    if-ge v8, v10, :cond_f8

    .line 186
    .line 187
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v10

    .line 191
    check-cast v10, Lio/flutter/embedding/engine/renderer/a;

    .line 192
    .line 193
    mul-int/lit8 v11, v8, 0x4

    .line 194
    .line 195
    add-int/2addr v11, v9

    .line 196
    iget-object v12, v10, Lio/flutter/embedding/engine/renderer/a;->a:Landroid/graphics/Rect;

    .line 197
    .line 198
    iget v13, v12, Landroid/graphics/Rect;->left:I

    .line 199
    .line 200
    aput v13, v5, v11

    .line 201
    .line 202
    add-int/lit8 v13, v11, 0x1

    .line 203
    .line 204
    iget v14, v12, Landroid/graphics/Rect;->top:I

    .line 205
    .line 206
    aput v14, v5, v13

    .line 207
    .line 208
    add-int/lit8 v13, v11, 0x2

    .line 209
    .line 210
    iget v14, v12, Landroid/graphics/Rect;->right:I

    .line 211
    .line 212
    aput v14, v5, v13

    .line 213
    .line 214
    add-int/lit8 v11, v11, 0x3

    .line 215
    .line 216
    iget v12, v12, Landroid/graphics/Rect;->bottom:I

    .line 217
    .line 218
    aput v12, v5, v11

    .line 219
    .line 220
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 221
    .line 222
    .line 223
    move-result v11

    .line 224
    add-int/2addr v11, v8

    .line 225
    iget v12, v10, Lio/flutter/embedding/engine/renderer/a;->b:I

    .line 226
    .line 227
    invoke-static {v12}, LK/j;->b(I)I

    .line 228
    .line 229
    .line 230
    move-result v12

    .line 231
    aput v12, v7, v11

    .line 232
    .line 233
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 234
    .line 235
    .line 236
    move-result v11

    .line 237
    add-int/2addr v11, v8

    .line 238
    iget v10, v10, Lio/flutter/embedding/engine/renderer/a;->c:I

    .line 239
    .line 240
    invoke-static {v10}, LK/j;->b(I)I

    .line 241
    .line 242
    .line 243
    move-result v10

    .line 244
    aput v10, v6, v11

    .line 245
    .line 246
    add-int/lit8 v8, v8, 0x1

    .line 247
    .line 248
    goto :goto_b4

    .line 249
    :cond_f8
    iget v8, v2, Lio/flutter/embedding/engine/renderer/i;->a:F

    .line 250
    .line 251
    iget v9, v2, Lio/flutter/embedding/engine/renderer/i;->b:I

    .line 252
    .line 253
    iget v10, v2, Lio/flutter/embedding/engine/renderer/i;->c:I

    .line 254
    .line 255
    iget v11, v2, Lio/flutter/embedding/engine/renderer/i;->h:I

    .line 256
    .line 257
    iget v12, v2, Lio/flutter/embedding/engine/renderer/i;->i:I

    .line 258
    .line 259
    iget v13, v2, Lio/flutter/embedding/engine/renderer/i;->j:I

    .line 260
    .line 261
    iget v14, v2, Lio/flutter/embedding/engine/renderer/i;->k:I

    .line 262
    .line 263
    iget v15, v2, Lio/flutter/embedding/engine/renderer/i;->l:I

    .line 264
    .line 265
    iget v3, v2, Lio/flutter/embedding/engine/renderer/i;->m:I

    .line 266
    .line 267
    iget v4, v2, Lio/flutter/embedding/engine/renderer/i;->n:I

    .line 268
    .line 269
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->o:I

    .line 270
    .line 271
    move/from16 v18, v0

    .line 272
    .line 273
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->p:I

    .line 274
    .line 275
    move/from16 v19, v0

    .line 276
    .line 277
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->q:I

    .line 278
    .line 279
    move/from16 v20, v0

    .line 280
    .line 281
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->r:I

    .line 282
    .line 283
    move/from16 v21, v0

    .line 284
    .line 285
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->s:I

    .line 286
    .line 287
    move/from16 v22, v0

    .line 288
    .line 289
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->t:I

    .line 290
    .line 291
    move/from16 v23, v0

    .line 292
    .line 293
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->d:I

    .line 294
    .line 295
    move/from16 v27, v0

    .line 296
    .line 297
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->e:I

    .line 298
    .line 299
    move/from16 v28, v0

    .line 300
    .line 301
    iget v0, v2, Lio/flutter/embedding/engine/renderer/i;->f:I

    .line 302
    .line 303
    iget v2, v2, Lio/flutter/embedding/engine/renderer/i;->g:I

    .line 304
    .line 305
    iget-object v1, v1, Lio/flutter/embedding/engine/renderer/j;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 306
    .line 307
    move/from16 v29, v0

    .line 308
    .line 309
    move/from16 v30, v2

    .line 310
    .line 311
    move/from16 v16, v3

    .line 312
    .line 313
    move/from16 v17, v4

    .line 314
    .line 315
    move-object/from16 v24, v5

    .line 316
    .line 317
    move-object/from16 v26, v6

    .line 318
    .line 319
    move-object/from16 v25, v7

    .line 320
    .line 321
    move-object v7, v1

    .line 322
    invoke-virtual/range {v7 .. v30}, Lio/flutter/embedding/engine/FlutterJNI;->setViewportMetrics(FIIIIIIIIIIIIIII[I[I[IIIII)V

    .line 323
    .line 324
    .line 325
    :cond_144
    return-void
.end method

.method public getAccessibilityNodeProvider()Landroid/view/accessibility/AccessibilityNodeProvider;
    .registers 2

    .line 1
    iget-object v0, p0, LQ1/p;->v:Lio/flutter/view/j;

    .line 2
    .line 3
    if-eqz v0, :cond_f

    .line 4
    .line 5
    iget-object v0, v0, Lio/flutter/view/j;->c:Landroid/view/accessibility/AccessibilityManager;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_f

    .line 12
    .line 13
    iget-object v0, p0, LQ1/p;->v:Lio/flutter/view/j;

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_f
    const/4 v0, 0x0

    .line 17
    return-object v0
.end method

.method public getAttachedFlutterEngine()LR1/c;
    .registers 2

    .line 1
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 2
    .line 3
    return-object v0
.end method

.method public getBinaryMessenger()Lb2/f;
    .registers 2

    .line 1
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 2
    .line 3
    iget-object v0, v0, LR1/c;->c:LS1/b;

    .line 4
    .line 5
    return-object v0
.end method

.method public getCurrentImageSurface()LQ1/h;
    .registers 2

    .line 1
    iget-object v0, p0, LQ1/p;->i:LQ1/h;

    .line 2
    .line 3
    return-object v0
.end method

.method public getViewportMetrics()Lio/flutter/embedding/engine/renderer/i;
    .registers 2

    .line 1
    iget-object v0, p0, LQ1/p;->y:Lio/flutter/embedding/engine/renderer/i;

    .line 2
    .line 3
    return-object v0
.end method

.method public final onApplyWindowInsets(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-super/range {p0 .. p1}, Landroid/view/View;->onApplyWindowInsets(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 10
    .line 11
    const/16 v4, 0x1d

    .line 12
    .line 13
    iget-object v5, v0, LQ1/p;->y:Lio/flutter/embedding/engine/renderer/i;

    .line 14
    .line 15
    if-ne v3, v4, :cond_2c

    .line 16
    .line 17
    invoke-static {v1}, LC/G;->w(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->y(Landroid/graphics/Insets;)I

    .line 22
    .line 23
    .line 24
    move-result v6

    .line 25
    iput v6, v5, Lio/flutter/embedding/engine/renderer/i;->p:I

    .line 26
    .line 27
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->B(Landroid/graphics/Insets;)I

    .line 28
    .line 29
    .line 30
    move-result v6

    .line 31
    iput v6, v5, Lio/flutter/embedding/engine/renderer/i;->q:I

    .line 32
    .line 33
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->D(Landroid/graphics/Insets;)I

    .line 34
    .line 35
    .line 36
    move-result v6

    .line 37
    iput v6, v5, Lio/flutter/embedding/engine/renderer/i;->r:I

    .line 38
    .line 39
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->a(Landroid/graphics/Insets;)I

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->s:I

    .line 44
    .line 45
    :cond_2c
    invoke-virtual {v0}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 46
    .line 47
    .line 48
    move-result v4

    .line 49
    const/4 v6, 0x4

    .line 50
    and-int/2addr v4, v6

    .line 51
    const/4 v7, 0x0

    .line 52
    const/4 v8, 0x1

    .line 53
    if-nez v4, :cond_38

    .line 54
    .line 55
    move v4, v8

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    move v4, v7

    .line 58
    :goto_39
    invoke-virtual {v0}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 59
    .line 60
    .line 61
    move-result v9

    .line 62
    const/4 v10, 0x2

    .line 63
    and-int/2addr v9, v10

    .line 64
    if-nez v9, :cond_43

    .line 65
    .line 66
    move v9, v8

    .line 67
    goto :goto_44

    .line 68
    :cond_43
    move v9, v7

    .line 69
    :goto_44
    const/16 v11, 0x1e

    .line 70
    .line 71
    if-lt v3, v11, :cond_104

    .line 72
    .line 73
    invoke-static {}, LC/I;->D()I

    .line 74
    .line 75
    .line 76
    move-result v4

    .line 77
    invoke-static {v1, v4}, LC/I;->e(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 78
    .line 79
    .line 80
    move-result-object v4

    .line 81
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->y(Landroid/graphics/Insets;)I

    .line 82
    .line 83
    .line 84
    move-result v7

    .line 85
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->h:I

    .line 86
    .line 87
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->B(Landroid/graphics/Insets;)I

    .line 88
    .line 89
    .line 90
    move-result v7

    .line 91
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->i:I

    .line 92
    .line 93
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->D(Landroid/graphics/Insets;)I

    .line 94
    .line 95
    .line 96
    move-result v7

    .line 97
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->j:I

    .line 98
    .line 99
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->a(Landroid/graphics/Insets;)I

    .line 100
    .line 101
    .line 102
    move-result v4

    .line 103
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->k:I

    .line 104
    .line 105
    invoke-static {}, LC/I;->x()I

    .line 106
    .line 107
    .line 108
    move-result v4

    .line 109
    invoke-static {v1, v4}, LC/I;->e(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->y(Landroid/graphics/Insets;)I

    .line 114
    .line 115
    .line 116
    move-result v7

    .line 117
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->l:I

    .line 118
    .line 119
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->B(Landroid/graphics/Insets;)I

    .line 120
    .line 121
    .line 122
    move-result v7

    .line 123
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->m:I

    .line 124
    .line 125
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->D(Landroid/graphics/Insets;)I

    .line 126
    .line 127
    .line 128
    move-result v7

    .line 129
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->n:I

    .line 130
    .line 131
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->a(Landroid/graphics/Insets;)I

    .line 132
    .line 133
    .line 134
    move-result v4

    .line 135
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->o:I

    .line 136
    .line 137
    invoke-static {}, LC/I;->z()I

    .line 138
    .line 139
    .line 140
    move-result v4

    .line 141
    invoke-static {v1, v4}, LC/I;->e(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 142
    .line 143
    .line 144
    move-result-object v4

    .line 145
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->y(Landroid/graphics/Insets;)I

    .line 146
    .line 147
    .line 148
    move-result v7

    .line 149
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->p:I

    .line 150
    .line 151
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->B(Landroid/graphics/Insets;)I

    .line 152
    .line 153
    .line 154
    move-result v7

    .line 155
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->q:I

    .line 156
    .line 157
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->D(Landroid/graphics/Insets;)I

    .line 158
    .line 159
    .line 160
    move-result v7

    .line 161
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->r:I

    .line 162
    .line 163
    invoke-static {v4}, Lio/flutter/plugin/platform/n;->a(Landroid/graphics/Insets;)I

    .line 164
    .line 165
    .line 166
    move-result v4

    .line 167
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->s:I

    .line 168
    .line 169
    invoke-static {v1}, LA/b;->n(Landroid/view/WindowInsets;)Landroid/view/DisplayCutout;

    .line 170
    .line 171
    .line 172
    move-result-object v4

    .line 173
    if-eqz v4, :cond_1aa

    .line 174
    .line 175
    invoke-static {v4}, LC/I;->d(Landroid/view/DisplayCutout;)Landroid/graphics/Insets;

    .line 176
    .line 177
    .line 178
    move-result-object v7

    .line 179
    iget v9, v5, Lio/flutter/embedding/engine/renderer/i;->h:I

    .line 180
    .line 181
    invoke-static {v7}, Lio/flutter/plugin/platform/n;->y(Landroid/graphics/Insets;)I

    .line 182
    .line 183
    .line 184
    move-result v10

    .line 185
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 186
    .line 187
    .line 188
    move-result v9

    .line 189
    invoke-static {v4}, LU1/a;->a(Landroid/view/DisplayCutout;)I

    .line 190
    .line 191
    .line 192
    move-result v10

    .line 193
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 194
    .line 195
    .line 196
    move-result v9

    .line 197
    iput v9, v5, Lio/flutter/embedding/engine/renderer/i;->h:I

    .line 198
    .line 199
    iget v9, v5, Lio/flutter/embedding/engine/renderer/i;->i:I

    .line 200
    .line 201
    invoke-static {v7}, Lio/flutter/plugin/platform/n;->B(Landroid/graphics/Insets;)I

    .line 202
    .line 203
    .line 204
    move-result v10

    .line 205
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 206
    .line 207
    .line 208
    move-result v9

    .line 209
    invoke-static {v4}, LU1/a;->q(Landroid/view/DisplayCutout;)I

    .line 210
    .line 211
    .line 212
    move-result v10

    .line 213
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 214
    .line 215
    .line 216
    move-result v9

    .line 217
    iput v9, v5, Lio/flutter/embedding/engine/renderer/i;->i:I

    .line 218
    .line 219
    iget v9, v5, Lio/flutter/embedding/engine/renderer/i;->j:I

    .line 220
    .line 221
    invoke-static {v7}, Lio/flutter/plugin/platform/n;->D(Landroid/graphics/Insets;)I

    .line 222
    .line 223
    .line 224
    move-result v10

    .line 225
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 226
    .line 227
    .line 228
    move-result v9

    .line 229
    invoke-static {v4}, LU1/a;->p(Landroid/view/DisplayCutout;)I

    .line 230
    .line 231
    .line 232
    move-result v10

    .line 233
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    .line 234
    .line 235
    .line 236
    move-result v9

    .line 237
    iput v9, v5, Lio/flutter/embedding/engine/renderer/i;->j:I

    .line 238
    .line 239
    iget v9, v5, Lio/flutter/embedding/engine/renderer/i;->k:I

    .line 240
    .line 241
    invoke-static {v7}, Lio/flutter/plugin/platform/n;->a(Landroid/graphics/Insets;)I

    .line 242
    .line 243
    .line 244
    move-result v7

    .line 245
    invoke-static {v9, v7}, Ljava/lang/Math;->max(II)I

    .line 246
    .line 247
    .line 248
    move-result v7

    .line 249
    invoke-static {v4}, LU1/a;->o(Landroid/view/DisplayCutout;)I

    .line 250
    .line 251
    .line 252
    move-result v4

    .line 253
    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    .line 254
    .line 255
    .line 256
    move-result v4

    .line 257
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->k:I

    .line 258
    .line 259
    goto/16 :goto_1aa

    .line 260
    .line 261
    :cond_104
    const/4 v11, 0x3

    .line 262
    if-nez v9, :cond_135

    .line 263
    .line 264
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 265
    .line 266
    .line 267
    move-result-object v12

    .line 268
    invoke-virtual {v12}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 269
    .line 270
    .line 271
    move-result-object v13

    .line 272
    invoke-virtual {v13}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 273
    .line 274
    .line 275
    move-result-object v13

    .line 276
    iget v13, v13, Landroid/content/res/Configuration;->orientation:I

    .line 277
    .line 278
    if-ne v13, v10, :cond_135

    .line 279
    .line 280
    const-string v13, "display"

    .line 281
    .line 282
    invoke-virtual {v12, v13}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v12

    .line 286
    check-cast v12, Landroid/hardware/display/DisplayManager;

    .line 287
    .line 288
    invoke-virtual {v12, v7}, Landroid/hardware/display/DisplayManager;->getDisplay(I)Landroid/view/Display;

    .line 289
    .line 290
    .line 291
    move-result-object v12

    .line 292
    invoke-virtual {v12}, Landroid/view/Display;->getRotation()I

    .line 293
    .line 294
    .line 295
    move-result v12

    .line 296
    if-ne v12, v8, :cond_12b

    .line 297
    .line 298
    move v12, v11

    .line 299
    goto :goto_136

    .line 300
    :cond_12b
    if-ne v12, v11, :cond_12f

    .line 301
    .line 302
    move v12, v10

    .line 303
    goto :goto_136

    .line 304
    :cond_12f
    if-eqz v12, :cond_133

    .line 305
    .line 306
    if-ne v12, v10, :cond_135

    .line 307
    .line 308
    :cond_133
    move v12, v6

    .line 309
    goto :goto_136

    .line 310
    :cond_135
    move v12, v8

    .line 311
    :goto_136
    if-eqz v4, :cond_13d

    .line 312
    .line 313
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetTop()I

    .line 314
    .line 315
    .line 316
    move-result v4

    .line 317
    goto :goto_13e

    .line 318
    :cond_13d
    move v4, v7

    .line 319
    :goto_13e
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->h:I

    .line 320
    .line 321
    if-eq v12, v11, :cond_14a

    .line 322
    .line 323
    if-ne v12, v6, :cond_145

    .line 324
    .line 325
    goto :goto_14a

    .line 326
    :cond_145
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetRight()I

    .line 327
    .line 328
    .line 329
    move-result v4

    .line 330
    goto :goto_14b

    .line 331
    :cond_14a
    :goto_14a
    move v4, v7

    .line 332
    :goto_14b
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->i:I

    .line 333
    .line 334
    if-eqz v9, :cond_174

    .line 335
    .line 336
    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 337
    .line 338
    .line 339
    move-result-object v4

    .line 340
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 341
    .line 342
    .line 343
    move-result v4

    .line 344
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 345
    .line 346
    .line 347
    move-result v9

    .line 348
    const-wide v15, 0x3fc70a3d70a3d70aL    # 0.18

    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    int-to-double v13, v9

    .line 354
    int-to-double v8, v4

    .line 355
    mul-double/2addr v8, v15

    .line 356
    cmpg-double v4, v13, v8

    .line 357
    .line 358
    if-gez v4, :cond_169

    .line 359
    .line 360
    move v4, v7

    .line 361
    goto :goto_16d

    .line 362
    :cond_169
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 363
    .line 364
    .line 365
    move-result v4

    .line 366
    :goto_16d
    if-nez v4, :cond_179

    .line 367
    .line 368
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 369
    .line 370
    .line 371
    move-result v4

    .line 372
    goto :goto_17a

    .line 373
    :cond_174
    const-wide v15, 0x3fc70a3d70a3d70aL    # 0.18

    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    :cond_179
    move v4, v7

    .line 379
    :goto_17a
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->j:I

    .line 380
    .line 381
    if-eq v12, v10, :cond_186

    .line 382
    .line 383
    if-ne v12, v6, :cond_181

    .line 384
    .line 385
    goto :goto_186

    .line 386
    :cond_181
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetLeft()I

    .line 387
    .line 388
    .line 389
    move-result v4

    .line 390
    goto :goto_187

    .line 391
    :cond_186
    :goto_186
    move v4, v7

    .line 392
    :goto_187
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->k:I

    .line 393
    .line 394
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->l:I

    .line 395
    .line 396
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->m:I

    .line 397
    .line 398
    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 399
    .line 400
    .line 401
    move-result-object v4

    .line 402
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 403
    .line 404
    .line 405
    move-result v4

    .line 406
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 407
    .line 408
    .line 409
    move-result v8

    .line 410
    int-to-double v8, v8

    .line 411
    int-to-double v12, v4

    .line 412
    mul-double/2addr v12, v15

    .line 413
    cmpg-double v4, v8, v12

    .line 414
    .line 415
    if-gez v4, :cond_1a2

    .line 416
    .line 417
    move v4, v7

    .line 418
    goto :goto_1a6

    .line 419
    :cond_1a2
    invoke-virtual {v1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 420
    .line 421
    .line 422
    move-result v4

    .line 423
    :goto_1a6
    iput v4, v5, Lio/flutter/embedding/engine/renderer/i;->n:I

    .line 424
    .line 425
    iput v7, v5, Lio/flutter/embedding/engine/renderer/i;->o:I

    .line 426
    .line 427
    :cond_1aa
    :goto_1aa
    new-instance v4, Ljava/util/ArrayList;

    .line 428
    .line 429
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 430
    .line 431
    .line 432
    const/16 v7, 0x1c

    .line 433
    .line 434
    if-lt v3, v7, :cond_1da

    .line 435
    .line 436
    invoke-static {v1}, LA/b;->n(Landroid/view/WindowInsets;)Landroid/view/DisplayCutout;

    .line 437
    .line 438
    .line 439
    move-result-object v1

    .line 440
    if-eqz v1, :cond_1da

    .line 441
    .line 442
    invoke-static {v1}, LA/b;->s(Landroid/view/DisplayCutout;)Ljava/util/List;

    .line 443
    .line 444
    .line 445
    move-result-object v1

    .line 446
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 447
    .line 448
    .line 449
    move-result-object v1

    .line 450
    :goto_1c1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 451
    .line 452
    .line 453
    move-result v3

    .line 454
    if-eqz v3, :cond_1da

    .line 455
    .line 456
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v3

    .line 460
    check-cast v3, Landroid/graphics/Rect;

    .line 461
    .line 462
    invoke-virtual {v3}, Landroid/graphics/Rect;->toString()Ljava/lang/String;

    .line 463
    .line 464
    .line 465
    new-instance v7, Lio/flutter/embedding/engine/renderer/a;

    .line 466
    .line 467
    const/4 v11, 0x1

    .line 468
    invoke-direct {v7, v3, v6, v11}, Lio/flutter/embedding/engine/renderer/a;-><init>(Landroid/graphics/Rect;II)V

    .line 469
    .line 470
    .line 471
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 472
    .line 473
    .line 474
    goto :goto_1c1

    .line 475
    :cond_1da
    iget-object v1, v5, Lio/flutter/embedding/engine/renderer/i;->v:Ljava/util/ArrayList;

    .line 476
    .line 477
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 478
    .line 479
    .line 480
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 481
    .line 482
    .line 483
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 484
    .line 485
    const/16 v3, 0x23

    .line 486
    .line 487
    if-lt v1, v3, :cond_230

    .line 488
    .line 489
    iget-object v1, v0, LQ1/p;->G:LQ1/r;

    .line 490
    .line 491
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 492
    .line 493
    .line 494
    move-result-object v3

    .line 495
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 496
    .line 497
    .line 498
    invoke-static {v3}, Landroid/support/v4/media/session/a;->u(Landroid/content/Context;)Landroid/app/Activity;

    .line 499
    .line 500
    .line 501
    move-result-object v1

    .line 502
    const/4 v3, 0x0

    .line 503
    if-nez v1, :cond_1f9

    .line 504
    .line 505
    goto :goto_208

    .line 506
    :cond_1f9
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 507
    .line 508
    .line 509
    move-result-object v1

    .line 510
    if-nez v1, :cond_200

    .line 511
    .line 512
    goto :goto_208

    .line 513
    :cond_200
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 514
    .line 515
    .line 516
    move-result-object v1

    .line 517
    invoke-virtual {v1}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    .line 518
    .line 519
    .line 520
    move-result-object v3

    .line 521
    :goto_208
    if-nez v3, :cond_20d

    .line 522
    .line 523
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 524
    .line 525
    goto :goto_215

    .line 526
    :cond_20d
    invoke-static {}, LC/I;->v()I

    .line 527
    .line 528
    .line 529
    move-result v1

    .line 530
    invoke-static {v3, v1}, LQ1/q;->b(Landroid/view/WindowInsets;I)Ljava/util/List;

    .line 531
    .line 532
    .line 533
    move-result-object v1

    .line 534
    :goto_215
    iget v3, v5, Lio/flutter/embedding/engine/renderer/i;->h:I

    .line 535
    .line 536
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 537
    .line 538
    .line 539
    move-result-object v1

    .line 540
    :goto_21b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 541
    .line 542
    .line 543
    move-result v4

    .line 544
    if-eqz v4, :cond_22e

    .line 545
    .line 546
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 547
    .line 548
    .line 549
    move-result-object v4

    .line 550
    check-cast v4, Landroid/graphics/Rect;

    .line 551
    .line 552
    iget v4, v4, Landroid/graphics/Rect;->bottom:I

    .line 553
    .line 554
    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    .line 555
    .line 556
    .line 557
    move-result v3

    .line 558
    goto :goto_21b

    .line 559
    :cond_22e
    iput v3, v5, Lio/flutter/embedding/engine/renderer/i;->h:I

    .line 560
    .line 561
    :cond_230
    invoke-virtual {v0}, LQ1/p;->e()V

    .line 562
    .line 563
    .line 564
    return-object v2
.end method

.method public final onAttachedToWindow()V
    .registers 11

    .line 1
    sget-object v0, Lq2/i;->e:Lq2/i;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    .line 6
    .line 7
    .line 8
    :try_start_7
    new-instance v3, LA1/d;

    .line 9
    .line 10
    new-instance v4, Lb2/n;

    .line 11
    .line 12
    sget-object v5, Li0/h;->b:Li0/g;

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 15
    .line 16
    .line 17
    move-result-object v6

    .line 18
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-static {v6}, Li0/g;->a(Landroid/content/Context;)Li0/b;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    new-instance v6, Lb2/n;

    .line 26
    .line 27
    const/4 v7, 0x3

    .line 28
    invoke-direct {v6, v7}, Lb2/n;-><init>(I)V

    .line 29
    .line 30
    .line 31
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 32
    .line 33
    .line 34
    iput-object v5, v4, Lb2/n;->e:Ljava/lang/Object;

    .line 35
    .line 36
    iput-object v6, v4, Lb2/n;->f:Ljava/lang/Object;

    .line 37
    .line 38
    const/16 v5, 0xd

    .line 39
    .line 40
    invoke-direct {v3, v5, v4}, LA1/d;-><init>(ILjava/lang/Object;)V
    :try_end_2a
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_7 .. :try_end_2a} :catch_2b

    .line 41
    .line 42
    .line 43
    goto :goto_2c

    .line 44
    :catch_2b
    move-object v3, v1

    .line 45
    :goto_2c
    iput-object v3, p0, LQ1/p;->x:LA1/d;

    .line 46
    .line 47
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    invoke-static {v3}, Landroid/support/v4/media/session/a;->u(Landroid/content/Context;)Landroid/app/Activity;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    iget-object v4, p0, LQ1/p;->x:LA1/d;

    .line 56
    .line 57
    if-eqz v4, :cond_11e

    .line 58
    .line 59
    if-eqz v3, :cond_11e

    .line 60
    .line 61
    new-instance v5, LQ1/m;

    .line 62
    .line 63
    invoke-direct {v5, v2, p0}, LQ1/m;-><init>(ILjava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iput-object v5, p0, LQ1/p;->D:LQ1/m;

    .line 67
    .line 68
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 69
    .line 70
    .line 71
    move-result-object v5

    .line 72
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 73
    .line 74
    const/16 v7, 0x1c

    .line 75
    .line 76
    if-lt v6, v7, :cond_52

    .line 77
    .line 78
    invoke-static {v5}, Ls/b;->a(Landroid/content/Context;)Ljava/util/concurrent/Executor;

    .line 79
    .line 80
    .line 81
    move-result-object v5

    .line 82
    goto :goto_60

    .line 83
    :cond_52
    new-instance v6, Landroid/os/Handler;

    .line 84
    .line 85
    invoke-virtual {v5}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    .line 86
    .line 87
    .line 88
    move-result-object v5

    .line 89
    invoke-direct {v6, v5}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 90
    .line 91
    .line 92
    new-instance v5, Ly/b;

    .line 93
    .line 94
    invoke-direct {v5, v6, v2}, Ly/b;-><init>(Landroid/os/Handler;I)V

    .line 95
    .line 96
    .line 97
    :goto_60
    iget-object v6, p0, LQ1/p;->D:LQ1/m;

    .line 98
    .line 99
    iget-object v4, v4, LA1/d;->f:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast v4, Lb2/n;

    .line 102
    .line 103
    const-string v7, "executor"

    .line 104
    .line 105
    invoke-static {v5, v7}, Lz2/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    const-string v7, "consumer"

    .line 109
    .line 110
    invoke-static {v6, v7}, Lz2/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    iget-object v7, v4, Lb2/n;->e:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v7, Li0/b;

    .line 116
    .line 117
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 118
    .line 119
    .line 120
    new-instance v8, Li0/i;

    .line 121
    .line 122
    invoke-direct {v8, v7, v3, v1}, Li0/i;-><init>(Li0/b;Landroid/app/Activity;Lkotlin/coroutines/Continuation;)V

    .line 123
    .line 124
    .line 125
    new-instance v3, LI2/c;

    .line 126
    .line 127
    sget-object v7, LH2/a;->e:LH2/a;

    .line 128
    .line 129
    const/4 v9, -0x2

    .line 130
    invoke-direct {v3, v8, v0, v9, v7}, LI2/c;-><init>(Li0/i;Lq2/h;ILH2/a;)V

    .line 131
    .line 132
    .line 133
    sget-object v7, LF2/D;->a:LM2/e;

    .line 134
    .line 135
    sget-object v7, LK2/o;->a:LG2/c;

    .line 136
    .line 137
    sget-object v8, LF2/t;->f:LF2/t;

    .line 138
    .line 139
    invoke-virtual {v7, v8}, LF2/s;->g(Lq2/g;)Lq2/f;

    .line 140
    .line 141
    .line 142
    move-result-object v8

    .line 143
    if-nez v8, :cond_106

    .line 144
    .line 145
    invoke-virtual {v7, v0}, LG2/c;->equals(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v8

    .line 149
    if-eqz v8, :cond_97

    .line 150
    .line 151
    goto :goto_9c

    .line 152
    :cond_97
    const/4 v8, 0x6

    .line 153
    invoke-static {v3, v7, v2, v1, v8}, LJ2/k;->a(LJ2/i;LG2/c;ILH2/a;I)LI2/d;

    .line 154
    .line 155
    .line 156
    move-result-object v3

    .line 157
    :goto_9c
    iget-object v2, v4, Lb2/n;->f:Ljava/lang/Object;

    .line 158
    .line 159
    check-cast v2, Lb2/n;

    .line 160
    .line 161
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 162
    .line 163
    .line 164
    const-string v4, "flow"

    .line 165
    .line 166
    invoke-static {v3, v4}, Lz2/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    iget-object v4, v2, Lb2/n;->e:Ljava/lang/Object;

    .line 170
    .line 171
    check-cast v4, Ljava/util/concurrent/locks/ReentrantLock;

    .line 172
    .line 173
    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 174
    .line 175
    .line 176
    iget-object v2, v2, Lb2/n;->f:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v2, Ljava/util/LinkedHashMap;

    .line 179
    .line 180
    :try_start_b3
    invoke-virtual {v2, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v7

    .line 184
    if-nez v7, :cond_fc

    .line 185
    .line 186
    new-instance v7, LF2/L;

    .line 187
    .line 188
    invoke-direct {v7, v5}, LF2/L;-><init>(Ljava/util/concurrent/Executor;)V

    .line 189
    .line 190
    .line 191
    sget-object v5, LF2/t;->f:LF2/t;

    .line 192
    .line 193
    invoke-virtual {v7, v5}, LF2/s;->g(Lq2/g;)Lq2/f;

    .line 194
    .line 195
    .line 196
    move-result-object v5

    .line 197
    if-eqz v5, :cond_c7

    .line 198
    .line 199
    goto :goto_d0

    .line 200
    :cond_c7
    new-instance v5, LF2/X;

    .line 201
    .line 202
    invoke-direct {v5}, LF2/X;-><init>()V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v7, v5}, Lq2/a;->l(Lq2/h;)Lq2/h;

    .line 206
    .line 207
    .line 208
    move-result-object v7

    .line 209
    :goto_d0
    new-instance v5, Lg0/a;

    .line 210
    .line 211
    invoke-direct {v5, v3, v6, v1}, Lg0/a;-><init>(LI2/d;LQ1/m;Lkotlin/coroutines/Continuation;)V

    .line 212
    .line 213
    .line 214
    sget-object v1, LF2/v;->e:LF2/v;

    .line 215
    .line 216
    const/4 v3, 0x1

    .line 217
    invoke-static {v7, v0, v3}, LF2/x;->a(Lq2/h;Lq2/h;Z)Lq2/h;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    sget-object v7, LF2/D;->a:LM2/e;

    .line 222
    .line 223
    if-eq v0, v7, :cond_ec

    .line 224
    .line 225
    sget-object v8, Lq2/d;->e:Lq2/d;

    .line 226
    .line 227
    invoke-interface {v0, v8}, Lq2/h;->g(Lq2/g;)Lq2/f;

    .line 228
    .line 229
    .line 230
    move-result-object v8

    .line 231
    if-nez v8, :cond_ec

    .line 232
    .line 233
    invoke-interface {v0, v7}, Lq2/h;->l(Lq2/h;)Lq2/h;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    :cond_ec
    sget-object v7, LF2/v;->e:LF2/v;

    .line 238
    .line 239
    new-instance v7, LF2/j0;

    .line 240
    .line 241
    invoke-direct {v7, v0, v3}, LF2/a;-><init>(Lq2/h;Z)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v7, v1, v7, v5}, LF2/a;->U(LF2/v;LF2/a;Ly2/p;)V

    .line 245
    .line 246
    .line 247
    invoke-interface {v2, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    goto :goto_fc

    .line 251
    :catchall_fa
    move-exception v0

    .line 252
    goto :goto_102

    .line 253
    :cond_fc
    :goto_fc
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_fe
    .catchall {:try_start_b3 .. :try_end_fe} :catchall_fa

    .line 254
    .line 255
    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 256
    .line 257
    .line 258
    goto :goto_11e

    .line 259
    :goto_102
    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 260
    .line 261
    .line 262
    throw v0

    .line 263
    :cond_106
    new-instance v0, Ljava/lang/StringBuilder;

    .line 264
    .line 265
    const-string v1, "Flow context cannot contain job in it. Had "

    .line 266
    .line 267
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 271
    .line 272
    .line 273
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 274
    .line 275
    .line 276
    move-result-object v0

    .line 277
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 278
    .line 279
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 284
    .line 285
    .line 286
    throw v1

    .line 287
    :cond_11e
    :goto_11e
    return-void
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 5
    .line 6
    if-eqz v0, :cond_18

    .line 7
    .line 8
    iget-object v0, p0, LQ1/p;->s:Lc2/a;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Lc2/a;->b(Landroid/content/res/Configuration;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, LQ1/p;->d()V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    iget-object v0, p0, LQ1/p;->n:LR1/c;

    .line 21
    .line 22
    invoke-static {p1, v0}, Landroid/support/v4/media/session/a;->b(Landroid/content/Context;Lm2/b;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    return-void
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .registers 12

    .line 1
    invoke-virtual {p0}, LQ1/p;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_b

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/view/View;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    return-object p1

    .line 12
    :cond_b
    iget-object v0, p0, LQ1/p;->q:Lio/flutter/plugin/editing/j;

    .line 13
    .line 14
    iget-object v5, p0, LQ1/p;->t:LC0/f;

    .line 15
    .line 16
    iget-object v1, v0, Lio/flutter/plugin/editing/j;->e:LC/j;

    .line 17
    .line 18
    iget v2, v1, LC/j;->b:I

    .line 19
    .line 20
    const/4 v3, 0x1

    .line 21
    const/4 v4, 0x0

    .line 22
    if-ne v2, v3, :cond_1a

    .line 23
    .line 24
    iput-object v4, v0, Lio/flutter/plugin/editing/j;->j:Landroid/view/inputmethod/InputConnection;

    .line 25
    .line 26
    return-object v4

    .line 27
    :cond_1a
    const/4 v6, 0x4

    .line 28
    if-ne v2, v6, :cond_1e

    .line 29
    .line 30
    return-object v4

    .line 31
    :cond_1e
    const/4 v4, 0x3

    .line 32
    if-ne v2, v4, :cond_37

    .line 33
    .line 34
    iget-boolean v2, v0, Lio/flutter/plugin/editing/j;->p:Z

    .line 35
    .line 36
    if-eqz v2, :cond_28

    .line 37
    .line 38
    iget-object p1, v0, Lio/flutter/plugin/editing/j;->j:Landroid/view/inputmethod/InputConnection;

    .line 39
    .line 40
    return-object p1

    .line 41
    :cond_28
    iget-object v2, v0, Lio/flutter/plugin/editing/j;->k:Lio/flutter/plugin/platform/p;

    .line 42
    .line 43
    iget v1, v1, LC/j;->c:I

    .line 44
    .line 45
    invoke-virtual {v2, v1}, Lio/flutter/plugin/platform/p;->m(I)Landroid/view/View;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {v1, p1}, Landroid/view/View;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    iput-object p1, v0, Lio/flutter/plugin/editing/j;->j:Landroid/view/inputmethod/InputConnection;

    .line 54
    .line 55
    return-object p1

    .line 56
    :cond_37
    iget-object v1, v0, Lio/flutter/plugin/editing/j;->f:La2/n;

    .line 57
    .line 58
    iget-object v2, v1, La2/n;->g:La2/o;

    .line 59
    .line 60
    const/4 v7, 0x2

    .line 61
    iget v8, v2, La2/o;->a:I

    .line 62
    .line 63
    if-ne v8, v7, :cond_42

    .line 64
    .line 65
    goto/16 :goto_bc

    .line 66
    .line 67
    :cond_42
    const/4 v9, 0x5

    .line 68
    if-ne v8, v9, :cond_56

    .line 69
    .line 70
    iget-boolean v4, v2, La2/o;->b:Z

    .line 71
    .line 72
    if-eqz v4, :cond_4d

    .line 73
    .line 74
    const/16 v4, 0x1002

    .line 75
    .line 76
    move v6, v4

    .line 77
    goto :goto_4e

    .line 78
    :cond_4d
    move v6, v7

    .line 79
    :goto_4e
    iget-boolean v2, v2, La2/o;->c:Z

    .line 80
    .line 81
    if-eqz v2, :cond_bc

    .line 82
    .line 83
    :goto_52
    or-int/lit16 v6, v6, 0x2000

    .line 84
    .line 85
    goto/16 :goto_bc

    .line 86
    .line 87
    :cond_56
    const/4 v2, 0x6

    .line 88
    if-ne v8, v2, :cond_5c

    .line 89
    .line 90
    move v6, v4

    .line 91
    goto/16 :goto_bc

    .line 92
    .line 93
    :cond_5c
    const/16 v2, 0xb

    .line 94
    .line 95
    if-ne v8, v2, :cond_63

    .line 96
    .line 97
    const/4 v6, 0x0

    .line 98
    goto/16 :goto_bc

    .line 99
    .line 100
    :cond_63
    const/4 v2, 0x7

    .line 101
    if-ne v8, v2, :cond_6a

    .line 102
    .line 103
    const v2, 0x20001

    .line 104
    .line 105
    .line 106
    goto :goto_94

    .line 107
    :cond_6a
    const/16 v2, 0x8

    .line 108
    .line 109
    if-eq v8, v2, :cond_92

    .line 110
    .line 111
    const/16 v2, 0xd

    .line 112
    .line 113
    if-ne v8, v2, :cond_73

    .line 114
    .line 115
    goto :goto_92

    .line 116
    :cond_73
    const/16 v2, 0x9

    .line 117
    .line 118
    if-eq v8, v2, :cond_8f

    .line 119
    .line 120
    const/16 v2, 0xc

    .line 121
    .line 122
    if-ne v8, v2, :cond_7c

    .line 123
    .line 124
    goto :goto_8f

    .line 125
    :cond_7c
    const/16 v2, 0xa

    .line 126
    .line 127
    if-ne v8, v2, :cond_83

    .line 128
    .line 129
    const/16 v2, 0x91

    .line 130
    .line 131
    goto :goto_94

    .line 132
    :cond_83
    if-ne v8, v4, :cond_88

    .line 133
    .line 134
    const/16 v2, 0x61

    .line 135
    .line 136
    goto :goto_94

    .line 137
    :cond_88
    if-ne v8, v6, :cond_8d

    .line 138
    .line 139
    const/16 v2, 0x71

    .line 140
    .line 141
    goto :goto_94

    .line 142
    :cond_8d
    move v2, v3

    .line 143
    goto :goto_94

    .line 144
    :cond_8f
    :goto_8f
    const/16 v2, 0x11

    .line 145
    .line 146
    goto :goto_94

    .line 147
    :cond_92
    :goto_92
    const/16 v2, 0x21

    .line 148
    .line 149
    :goto_94
    iget-boolean v6, v1, La2/n;->a:Z

    .line 150
    .line 151
    if-eqz v6, :cond_9e

    .line 152
    .line 153
    const v6, 0x80080

    .line 154
    .line 155
    .line 156
    :goto_9b
    or-int/2addr v2, v6

    .line 157
    :cond_9c
    move v6, v2

    .line 158
    goto :goto_ae

    .line 159
    :cond_9e
    iget-boolean v6, v1, La2/n;->b:Z

    .line 160
    .line 161
    if-eqz v6, :cond_a6

    .line 162
    .line 163
    const v6, 0x8000

    .line 164
    .line 165
    .line 166
    or-int/2addr v2, v6

    .line 167
    :cond_a6
    iget-boolean v6, v1, La2/n;->c:Z

    .line 168
    .line 169
    if-nez v6, :cond_9c

    .line 170
    .line 171
    const v6, 0x80090

    .line 172
    .line 173
    .line 174
    goto :goto_9b

    .line 175
    :goto_ae
    iget v2, v1, La2/n;->f:I

    .line 176
    .line 177
    if-ne v2, v3, :cond_b5

    .line 178
    .line 179
    or-int/lit16 v6, v6, 0x1000

    .line 180
    .line 181
    goto :goto_bc

    .line 182
    :cond_b5
    if-ne v2, v7, :cond_b8

    .line 183
    .line 184
    goto :goto_52

    .line 185
    :cond_b8
    if-ne v2, v4, :cond_bc

    .line 186
    .line 187
    or-int/lit16 v6, v6, 0x4000

    .line 188
    .line 189
    :cond_bc
    :goto_bc
    iput v6, p1, Landroid/view/inputmethod/EditorInfo;->inputType:I

    .line 190
    .line 191
    const/high16 v2, 0x2000000

    .line 192
    .line 193
    iput v2, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 194
    .line 195
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 196
    .line 197
    const/16 v4, 0x1a

    .line 198
    .line 199
    if-lt v2, v4, :cond_d0

    .line 200
    .line 201
    iget-boolean v4, v1, La2/n;->d:Z

    .line 202
    .line 203
    if-nez v4, :cond_d0

    .line 204
    .line 205
    const/high16 v4, 0x3000000

    .line 206
    .line 207
    iput v4, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 208
    .line 209
    :cond_d0
    iget-object v1, v1, La2/n;->h:Ljava/lang/Integer;

    .line 210
    .line 211
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 212
    .line 213
    .line 214
    move-result v1

    .line 215
    iget-object v4, v0, Lio/flutter/plugin/editing/j;->f:La2/n;

    .line 216
    .line 217
    iget-object v6, v4, La2/n;->i:Ljava/lang/String;

    .line 218
    .line 219
    if-eqz v6, :cond_e0

    .line 220
    .line 221
    iput-object v6, p1, Landroid/view/inputmethod/EditorInfo;->actionLabel:Ljava/lang/CharSequence;

    .line 222
    .line 223
    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->actionId:I

    .line 224
    .line 225
    :cond_e0
    iget v6, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 226
    .line 227
    or-int/2addr v1, v6

    .line 228
    iput v1, p1, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 229
    .line 230
    iget-object v1, v4, La2/n;->m:[Ljava/util/Locale;

    .line 231
    .line 232
    if-eqz v1, :cond_f4

    .line 233
    .line 234
    new-instance v1, Landroid/os/LocaleList;

    .line 235
    .line 236
    iget-object v4, v0, Lio/flutter/plugin/editing/j;->f:La2/n;

    .line 237
    .line 238
    iget-object v4, v4, La2/n;->m:[Ljava/util/Locale;

    .line 239
    .line 240
    invoke-direct {v1, v4}, Landroid/os/LocaleList;-><init>([Ljava/util/Locale;)V

    .line 241
    .line 242
    .line 243
    iput-object v1, p1, Landroid/view/inputmethod/EditorInfo;->hintLocales:Landroid/os/LocaleList;

    .line 244
    .line 245
    :cond_f4
    iget-object v1, v0, Lio/flutter/plugin/editing/j;->f:La2/n;

    .line 246
    .line 247
    iget-object v1, v1, La2/n;->k:[Ljava/lang/String;

    .line 248
    .line 249
    if-eqz v1, :cond_11b

    .line 250
    .line 251
    const/16 v4, 0x19

    .line 252
    .line 253
    if-lt v2, v4, :cond_102

    .line 254
    .line 255
    invoke-static {p1, v1}, LE/a;->c(Landroid/view/inputmethod/EditorInfo;[Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    goto :goto_11b

    .line 259
    :cond_102
    iget-object v4, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 260
    .line 261
    if-nez v4, :cond_10d

    .line 262
    .line 263
    new-instance v4, Landroid/os/Bundle;

    .line 264
    .line 265
    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    .line 266
    .line 267
    .line 268
    iput-object v4, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 269
    .line 270
    :cond_10d
    iget-object v4, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 271
    .line 272
    const-string v6, "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"

    .line 273
    .line 274
    invoke-virtual {v4, v6, v1}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    iget-object v4, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 278
    .line 279
    const-string v6, "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"

    .line 280
    .line 281
    invoke-virtual {v4, v6, v1}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    .line 282
    .line 283
    .line 284
    :cond_11b
    :goto_11b
    const/16 v1, 0x22

    .line 285
    .line 286
    if-lt v2, v1, :cond_138

    .line 287
    .line 288
    const/16 v1, 0x23

    .line 289
    .line 290
    if-lt v2, v1, :cond_126

    .line 291
    .line 292
    invoke-static {p1}, LE/b;->b(Landroid/view/inputmethod/EditorInfo;)V

    .line 293
    .line 294
    .line 295
    :cond_126
    iget-object v1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 296
    .line 297
    if-nez v1, :cond_131

    .line 298
    .line 299
    new-instance v1, Landroid/os/Bundle;

    .line 300
    .line 301
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 302
    .line 303
    .line 304
    iput-object v1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 305
    .line 306
    :cond_131
    iget-object v1, p1, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 307
    .line 308
    const-string v2, "androidx.core.view.inputmethod.EditorInfoCompat.STYLUS_HANDWRITING_ENABLED"

    .line 309
    .line 310
    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 311
    .line 312
    .line 313
    :cond_138
    new-instance v1, Lio/flutter/plugin/editing/c;

    .line 314
    .line 315
    iget-object v2, v0, Lio/flutter/plugin/editing/j;->e:LC/j;

    .line 316
    .line 317
    iget v3, v2, LC/j;->c:I

    .line 318
    .line 319
    iget-object v6, v0, Lio/flutter/plugin/editing/j;->h:Lio/flutter/plugin/editing/f;

    .line 320
    .line 321
    iget-object v4, v0, Lio/flutter/plugin/editing/j;->d:LE0/j;

    .line 322
    .line 323
    move-object v2, p0

    .line 324
    move-object v7, p1

    .line 325
    invoke-direct/range {v1 .. v7}, Lio/flutter/plugin/editing/c;-><init>(LQ1/p;ILE0/j;LC0/f;Lio/flutter/plugin/editing/f;Landroid/view/inputmethod/EditorInfo;)V

    .line 326
    .line 327
    .line 328
    iget-object p1, v0, Lio/flutter/plugin/editing/j;->h:Lio/flutter/plugin/editing/f;

    .line 329
    .line 330
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 331
    .line 332
    .line 333
    invoke-static {p1}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    .line 334
    .line 335
    .line 336
    move-result p1

    .line 337
    iput p1, v7, Landroid/view/inputmethod/EditorInfo;->initialSelStart:I

    .line 338
    .line 339
    iget-object p1, v0, Lio/flutter/plugin/editing/j;->h:Lio/flutter/plugin/editing/f;

    .line 340
    .line 341
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 342
    .line 343
    .line 344
    invoke-static {p1}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    .line 345
    .line 346
    .line 347
    move-result p1

    .line 348
    iput p1, v7, Landroid/view/inputmethod/EditorInfo;->initialSelEnd:I

    .line 349
    .line 350
    iput-object v1, v0, Lio/flutter/plugin/editing/j;->j:Landroid/view/inputmethod/InputConnection;

    .line 351
    .line 352
    return-object v1
.end method

.method public final onDetachedFromWindow()V
    .registers 6

    .line 1
    iget-object v0, p0, LQ1/p;->x:LA1/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_39

    .line 5
    .line 6
    iget-object v2, p0, LQ1/p;->D:LQ1/m;

    .line 7
    .line 8
    if-eqz v2, :cond_39

    .line 9
    .line 10
    iget-object v0, v0, LA1/d;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lb2/n;

    .line 13
    .line 14
    iget-object v0, v0, Lb2/n;->f:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lb2/n;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    iget-object v3, v0, Lb2/n;->e:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v3, Ljava/util/concurrent/locks/ReentrantLock;

    .line 24
    .line 25
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 26
    .line 27
    .line 28
    iget-object v0, v0, Lb2/n;->f:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v0, Ljava/util/LinkedHashMap;

    .line 31
    .line 32
    :try_start_1f
    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    check-cast v4, LF2/U;

    .line 37
    .line 38
    if-eqz v4, :cond_2a

    .line 39
    .line 40
    invoke-interface {v4, v1}, LF2/U;->a(Ljava/util/concurrent/CancellationException;)V

    .line 41
    .line 42
    .line 43
    :cond_2a
    invoke-interface {v0, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, LF2/U;
    :try_end_30
    .catchall {:try_start_1f .. :try_end_30} :catchall_34

    .line 48
    .line 49
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 50
    .line 51
    .line 52
    goto :goto_39

    .line 53
    :catchall_34
    move-exception v0

    .line 54
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 55
    .line 56
    .line 57
    throw v0

    .line 58
    :cond_39
    :goto_39
    iput-object v1, p0, LQ1/p;->D:LQ1/m;

    .line 59
    .line 60
    iput-object v1, p0, LQ1/p;->x:LA1/d;

    .line 61
    .line 62
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 12

    .line 1
    invoke-virtual {p0}, LQ1/p;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_6b

    .line 6
    .line 7
    iget-object v1, p0, LQ1/p;->u:LQ1/a;

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object v8

    .line 13
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-virtual {p1, v0}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    const/4 v3, 0x7

    .line 26
    const/4 v9, 0x1

    .line 27
    if-eq v2, v3, :cond_27

    .line 28
    .line 29
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    const/16 v3, 0x8

    .line 34
    .line 35
    if-ne v2, v3, :cond_25

    .line 36
    .line 37
    goto :goto_27

    .line 38
    :cond_25
    const/4 v2, 0x0

    .line 39
    goto :goto_28

    .line 40
    :cond_27
    :goto_27
    move v2, v9

    .line 41
    :goto_28
    if-eqz v0, :cond_6b

    .line 42
    .line 43
    if-nez v2, :cond_2d

    .line 44
    .line 45
    goto :goto_6b

    .line 46
    :cond_2d
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-static {v0}, LQ1/a;->b(I)I

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    mul-int/lit16 v0, v0, 0x120

    .line 59
    .line 60
    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    .line 61
    .line 62
    .line 63
    move-result-object v7

    .line 64
    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 65
    .line 66
    invoke-virtual {v7, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 70
    .line 71
    .line 72
    move-result v3

    .line 73
    sget-object v6, LQ1/a;->f:Landroid/graphics/Matrix;

    .line 74
    .line 75
    const/4 v5, 0x0

    .line 76
    move-object v2, p1

    .line 77
    invoke-virtual/range {v1 .. v8}, LQ1/a;->a(Landroid/view/MotionEvent;IIILandroid/graphics/Matrix;Ljava/nio/ByteBuffer;Landroid/content/Context;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v7}, Ljava/nio/Buffer;->position()I

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    rem-int/lit16 p1, p1, 0x120

    .line 85
    .line 86
    if-nez p1, :cond_63

    .line 87
    .line 88
    invoke-virtual {v7}, Ljava/nio/Buffer;->position()I

    .line 89
    .line 90
    .line 91
    move-result p1

    .line 92
    iget-object v0, v1, LQ1/a;->a:Lio/flutter/embedding/engine/renderer/j;

    .line 93
    .line 94
    iget-object v0, v0, Lio/flutter/embedding/engine/renderer/j;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 95
    .line 96
    invoke-virtual {v0, v7, p1}, Lio/flutter/embedding/engine/FlutterJNI;->dispatchPointerDataPacket(Ljava/nio/ByteBuffer;I)V

    .line 97
    .line 98
    .line 99
    return v9

    .line 100
    :cond_63
    new-instance p1, Ljava/lang/AssertionError;

    .line 101
    .line 102
    const-string v0, "Packet position is not on field boundary."

    .line 103
    .line 104
    invoke-direct {p1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    throw p1

    .line 108
    :cond_6b
    :goto_6b
    move-object v2, p1

    .line 109
    invoke-super {p0, v2}, Landroid/view/View;->onGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 110
    .line 111
    .line 112
    move-result p1

    .line 113
    return p1
.end method

.method public final onHoverEvent(Landroid/view/MotionEvent;)Z
    .registers 4

    .line 1
    invoke-virtual {p0}, LQ1/p;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_b

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/view/View;->onHoverEvent(Landroid/view/MotionEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1

    .line 12
    :cond_b
    iget-object v0, p0, LQ1/p;->v:Lio/flutter/view/j;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-virtual {v0, p1, v1}, Lio/flutter/view/j;->f(Landroid/view/MotionEvent;Z)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    return p1
.end method

.method public final onMeasure(II)V
    .registers 4

    .line 1
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iput v0, p0, LQ1/p;->E:I

    .line 6
    .line 7
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iput v0, p0, LQ1/p;->F:I

    .line 12
    .line 13
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final onProvideAutofillVirtualStructure(Landroid/view/ViewStructure;I)V
    .registers 20

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    invoke-super/range {p0 .. p2}, Landroid/widget/FrameLayout;->onProvideAutofillVirtualStructure(Landroid/view/ViewStructure;I)V

    .line 4
    .line 5
    .line 6
    move-object/from16 v1, p0

    .line 7
    .line 8
    iget-object v2, v1, LQ1/p;->q:Lio/flutter/plugin/editing/j;

    .line 9
    .line 10
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 11
    .line 12
    const/16 v4, 0x1a

    .line 13
    .line 14
    if-lt v3, v4, :cond_a2

    .line 15
    .line 16
    iget-object v3, v2, Lio/flutter/plugin/editing/j;->g:Landroid/util/SparseArray;

    .line 17
    .line 18
    if-eqz v3, :cond_a1

    .line 19
    .line 20
    iget-object v3, v2, Lio/flutter/plugin/editing/j;->f:La2/n;

    .line 21
    .line 22
    iget-object v3, v3, La2/n;->j:Ly1/z;

    .line 23
    .line 24
    iget-object v3, v3, Ly1/z;->e:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v3, Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v0}, Landroid/view/ViewStructure;->getAutofillId()Landroid/view/autofill/AutofillId;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    const/4 v5, 0x0

    .line 33
    move v6, v5

    .line 34
    :goto_21
    iget-object v7, v2, Lio/flutter/plugin/editing/j;->g:Landroid/util/SparseArray;

    .line 35
    .line 36
    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    .line 37
    .line 38
    .line 39
    move-result v7

    .line 40
    if-ge v6, v7, :cond_a1

    .line 41
    .line 42
    iget-object v7, v2, Lio/flutter/plugin/editing/j;->g:Landroid/util/SparseArray;

    .line 43
    .line 44
    invoke-virtual {v7, v6}, Landroid/util/SparseArray;->keyAt(I)I

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    iget-object v8, v2, Lio/flutter/plugin/editing/j;->g:Landroid/util/SparseArray;

    .line 49
    .line 50
    invoke-virtual {v8, v6}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v8

    .line 54
    check-cast v8, La2/n;

    .line 55
    .line 56
    iget-object v8, v8, La2/n;->j:Ly1/z;

    .line 57
    .line 58
    if-nez v8, :cond_3c

    .line 59
    .line 60
    goto :goto_9e

    .line 61
    :cond_3c
    const/4 v9, 0x1

    .line 62
    invoke-virtual {v0, v9}, Landroid/view/ViewStructure;->addChildCount(I)I

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0, v6}, Landroid/view/ViewStructure;->newChild(I)Landroid/view/ViewStructure;

    .line 66
    .line 67
    .line 68
    move-result-object v10

    .line 69
    invoke-virtual {v10, v4, v7}, Landroid/view/ViewStructure;->setAutofillId(Landroid/view/autofill/AutofillId;I)V

    .line 70
    .line 71
    .line 72
    iget-object v11, v8, Ly1/z;->f:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v11, [Ljava/lang/String;

    .line 75
    .line 76
    array-length v12, v11

    .line 77
    if-lez v12, :cond_51

    .line 78
    .line 79
    invoke-virtual {v10, v11}, Landroid/view/ViewStructure;->setAutofillHints([Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    invoke-virtual {v10, v9}, Landroid/view/ViewStructure;->setAutofillType(I)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v10, v5}, Landroid/view/ViewStructure;->setVisibility(I)V

    .line 86
    .line 87
    .line 88
    iget-object v9, v8, Ly1/z;->h:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v9, Ljava/lang/String;

    .line 91
    .line 92
    if-eqz v9, :cond_60

    .line 93
    .line 94
    invoke-virtual {v10, v9}, Landroid/view/ViewStructure;->setHint(Ljava/lang/CharSequence;)V

    .line 95
    .line 96
    .line 97
    :cond_60
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 98
    .line 99
    .line 100
    move-result v9

    .line 101
    if-ne v9, v7, :cond_87

    .line 102
    .line 103
    iget-object v7, v2, Lio/flutter/plugin/editing/j;->m:Landroid/graphics/Rect;

    .line 104
    .line 105
    if-eqz v7, :cond_87

    .line 106
    .line 107
    iget v11, v7, Landroid/graphics/Rect;->left:I

    .line 108
    .line 109
    iget v12, v7, Landroid/graphics/Rect;->top:I

    .line 110
    .line 111
    invoke-virtual {v7}, Landroid/graphics/Rect;->width()I

    .line 112
    .line 113
    .line 114
    move-result v15

    .line 115
    iget-object v7, v2, Lio/flutter/plugin/editing/j;->m:Landroid/graphics/Rect;

    .line 116
    .line 117
    invoke-virtual {v7}, Landroid/graphics/Rect;->height()I

    .line 118
    .line 119
    .line 120
    move-result v16

    .line 121
    const/4 v13, 0x0

    .line 122
    const/4 v14, 0x0

    .line 123
    invoke-virtual/range {v10 .. v16}, Landroid/view/ViewStructure;->setDimens(IIIIII)V

    .line 124
    .line 125
    .line 126
    iget-object v7, v2, Lio/flutter/plugin/editing/j;->h:Lio/flutter/plugin/editing/f;

    .line 127
    .line 128
    invoke-static {v7}, Landroid/view/autofill/AutofillValue;->forText(Ljava/lang/CharSequence;)Landroid/view/autofill/AutofillValue;

    .line 129
    .line 130
    .line 131
    move-result-object v7

    .line 132
    invoke-virtual {v10, v7}, Landroid/view/ViewStructure;->setAutofillValue(Landroid/view/autofill/AutofillValue;)V

    .line 133
    .line 134
    .line 135
    goto :goto_9e

    .line 136
    :cond_87
    const/4 v15, 0x1

    .line 137
    const/16 v16, 0x1

    .line 138
    .line 139
    const/4 v11, 0x0

    .line 140
    const/4 v12, 0x0

    .line 141
    const/4 v13, 0x0

    .line 142
    const/4 v14, 0x0

    .line 143
    invoke-virtual/range {v10 .. v16}, Landroid/view/ViewStructure;->setDimens(IIIIII)V

    .line 144
    .line 145
    .line 146
    iget-object v7, v8, Ly1/z;->g:Ljava/lang/Object;

    .line 147
    .line 148
    check-cast v7, La2/p;

    .line 149
    .line 150
    iget-object v7, v7, La2/p;->a:Ljava/lang/String;

    .line 151
    .line 152
    invoke-static {v7}, Landroid/view/autofill/AutofillValue;->forText(Ljava/lang/CharSequence;)Landroid/view/autofill/AutofillValue;

    .line 153
    .line 154
    .line 155
    move-result-object v7

    .line 156
    invoke-virtual {v10, v7}, Landroid/view/ViewStructure;->setAutofillValue(Landroid/view/autofill/AutofillValue;)V

    .line 157
    .line 158
    .line 159
    :goto_9e
    add-int/lit8 v6, v6, 0x1

    .line 160
    .line 161
    goto :goto_21

    .line 162
    :cond_a1
    return-void

    .line 163
    :cond_a2
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 164
    .line 165
    .line 166
    return-void
.end method

.method public final onSizeChanged(IIII)V
    .registers 8

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    .line 2
    .line 3
    .line 4
    iget-object p3, p0, LQ1/p;->y:Lio/flutter/embedding/engine/renderer/i;

    .line 5
    .line 6
    iput p1, p3, Lio/flutter/embedding/engine/renderer/i;->b:I

    .line 7
    .line 8
    iput p2, p3, Lio/flutter/embedding/engine/renderer/i;->c:I

    .line 9
    .line 10
    iget-boolean p4, p0, LQ1/p;->f:Z

    .line 11
    .line 12
    const/16 v0, 0x2000

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz p4, :cond_19

    .line 16
    .line 17
    iget v2, p0, LQ1/p;->F:I

    .line 18
    .line 19
    if-nez v2, :cond_19

    .line 20
    .line 21
    iput v1, p3, Lio/flutter/embedding/engine/renderer/i;->f:I

    .line 22
    .line 23
    iput v0, p3, Lio/flutter/embedding/engine/renderer/i;->g:I

    .line 24
    .line 25
    goto :goto_1d

    .line 26
    :cond_19
    iput p2, p3, Lio/flutter/embedding/engine/renderer/i;->f:I

    .line 27
    .line 28
    iput p2, p3, Lio/flutter/embedding/engine/renderer/i;->g:I

    .line 29
    .line 30
    :goto_1d
    if-eqz p4, :cond_28

    .line 31
    .line 32
    iget p2, p0, LQ1/p;->E:I

    .line 33
    .line 34
    if-nez p2, :cond_28

    .line 35
    .line 36
    iput v1, p3, Lio/flutter/embedding/engine/renderer/i;->d:I

    .line 37
    .line 38
    iput v0, p3, Lio/flutter/embedding/engine/renderer/i;->e:I

    .line 39
    .line 40
    goto :goto_2c

    .line 41
    :cond_28
    iput p1, p3, Lio/flutter/embedding/engine/renderer/i;->d:I

    .line 42
    .line 43
    iput p1, p3, Lio/flutter/embedding/engine/renderer/i;->e:I

    .line 44
    .line 45
    :goto_2c
    iget-object p1, p0, LQ1/p;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 46
    .line 47
    const/4 p2, 0x1

    .line 48
    invoke-virtual {p1, v1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    if-eqz p1, :cond_36

    .line 53
    .line 54
    return-void

    .line 55
    :cond_36
    invoke-virtual {p0}, LQ1/p;->e()V

    .line 56
    .line 57
    .line 58
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 4

    .line 1
    invoke-virtual {p0}, LQ1/p;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_b

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    return p1

    .line 12
    :cond_b
    invoke-virtual {p0, p1}, Landroid/view/View;->requestUnbufferedDispatch(Landroid/view/MotionEvent;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, LQ1/p;->u:LQ1/a;

    .line 16
    .line 17
    sget-object v1, LQ1/a;->f:Landroid/graphics/Matrix;

    .line 18
    .line 19
    invoke-virtual {v0, p1, v1}, LQ1/a;->d(Landroid/view/MotionEvent;Landroid/graphics/Matrix;)V

    .line 20
    .line 21
    .line 22
    const/4 p1, 0x1

    .line 23
    return p1
.end method

.method public setDelegate(LQ1/r;)V
    .registers 2

    .line 1
    iput-object p1, p0, LQ1/p;->G:LQ1/r;

    .line 2
    .line 3
    return-void
.end method

.method public setVisibility(I)V
    .registers 4

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LQ1/p;->j:Landroid/view/View;

    .line 5
    .line 6
    instance-of v1, v0, LQ1/j;

    .line 7
    .line 8
    if-eqz v1, :cond_e

    .line 9
    .line 10
    check-cast v0, LQ1/j;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public setWindowInfoListenerDisplayFeatures(Li0/j;)V
    .registers 9

    .line 1
    iget-object p1, p1, Li0/j;->a:Ljava/lang/Object;

    .line 2
    .line 3
    new-instance v0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 6
    .line 7
    .line 8
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    :goto_b
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_59

    .line 17
    .line 18
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Li0/c;

    .line 23
    .line 24
    iget-object v2, v1, Li0/c;->a:Lf0/b;

    .line 25
    .line 26
    invoke-virtual {v2}, Lf0/b;->a()Landroid/graphics/Rect;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    iget-object v2, v1, Li0/c;->a:Lf0/b;

    .line 34
    .line 35
    iget v3, v2, Lf0/b;->c:I

    .line 36
    .line 37
    iget v4, v2, Lf0/b;->a:I

    .line 38
    .line 39
    sub-int/2addr v3, v4

    .line 40
    sget-object v4, Li0/b;->h:Li0/b;

    .line 41
    .line 42
    if-eqz v3, :cond_35

    .line 43
    .line 44
    iget v3, v2, Lf0/b;->d:I

    .line 45
    .line 46
    iget v5, v2, Lf0/b;->b:I

    .line 47
    .line 48
    sub-int/2addr v3, v5

    .line 49
    if-nez v3, :cond_33

    .line 50
    .line 51
    goto :goto_35

    .line 52
    :cond_33
    move-object v3, v4

    .line 53
    goto :goto_37

    .line 54
    :cond_35
    :goto_35
    sget-object v3, Li0/b;->g:Li0/b;

    .line 55
    .line 56
    :goto_37
    const/4 v5, 0x2

    .line 57
    const/4 v6, 0x3

    .line 58
    if-ne v3, v4, :cond_3d

    .line 59
    .line 60
    move v3, v6

    .line 61
    goto :goto_3e

    .line 62
    :cond_3d
    move v3, v5

    .line 63
    :goto_3e
    sget-object v4, Li0/b;->i:Li0/b;

    .line 64
    .line 65
    iget-object v1, v1, Li0/c;->c:Li0/b;

    .line 66
    .line 67
    if-ne v1, v4, :cond_45

    .line 68
    .line 69
    goto :goto_4c

    .line 70
    :cond_45
    sget-object v4, Li0/b;->j:Li0/b;

    .line 71
    .line 72
    if-ne v1, v4, :cond_4b

    .line 73
    .line 74
    move v5, v6

    .line 75
    goto :goto_4c

    .line 76
    :cond_4b
    const/4 v5, 0x1

    .line 77
    :goto_4c
    new-instance v1, Lio/flutter/embedding/engine/renderer/a;

    .line 78
    .line 79
    invoke-virtual {v2}, Lf0/b;->a()Landroid/graphics/Rect;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    invoke-direct {v1, v2, v3, v5}, Lio/flutter/embedding/engine/renderer/a;-><init>(Landroid/graphics/Rect;II)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    goto :goto_b

    .line 90
    :cond_59
    iget-object p1, p0, LQ1/p;->y:Lio/flutter/embedding/engine/renderer/i;

    .line 91
    .line 92
    iget-object p1, p1, Lio/flutter/embedding/engine/renderer/i;->u:Ljava/util/ArrayList;

    .line 93
    .line 94
    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    .line 95
    .line 96
    .line 97
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 98
    .line 99
    .line 100
    invoke-virtual {p0}, LQ1/p;->e()V

    .line 101
    .line 102
    .line 103
    return-void
.end method
