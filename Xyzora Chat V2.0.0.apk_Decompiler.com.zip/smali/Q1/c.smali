###### Class Q1.C0078c (Q1.c)
.class public final LQ1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/window/OnBackAnimationCallback;


# instance fields
.field public final synthetic a:LQ1/d;


# direct methods
.method public constructor <init>(LQ1/d;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LQ1/c;->a:LQ1/d;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onBackCancelled()V
    .registers 4

    .line 1
    iget-object v0, p0, LQ1/c;->a:LQ1/d;

    .line 2
    .line 3
    const-string v1, "cancelBackGesture"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LQ1/d;->l(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    if-eqz v2, :cond_25

    .line 10
    .line 11
    iget-object v0, v0, LQ1/d;->f:LQ1/g;

    .line 12
    .line 13
    invoke-virtual {v0}, LQ1/g;->c()V

    .line 14
    .line 15
    .line 16
    iget-object v0, v0, LQ1/g;->b:LR1/c;

    .line 17
    .line 18
    if-eqz v0, :cond_1e

    .line 19
    .line 20
    iget-object v0, v0, LR1/c;->j:LA1/d;

    .line 21
    .line 22
    iget-object v0, v0, LA1/d;->f:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Lb2/q;

    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    invoke-virtual {v0, v1, v2, v2}, Lb2/q;->a(Ljava/lang/String;Ljava/lang/Object;Lb2/p;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_1e
    const-string v0, "FlutterActivityAndFragmentDelegate"

    .line 32
    .line 33
    const-string v1, "Invoked cancelBackGesture() before FlutterFragment was attached to an Activity."

    .line 34
    .line 35
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    :cond_25
    return-void
.end method

.method public final onBackInvoked()V
    .registers 4

    .line 1
    iget-object v0, p0, LQ1/c;->a:LQ1/d;

    .line 2
    .line 3
    const-string v1, "commitBackGesture"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LQ1/d;->l(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    if-eqz v2, :cond_25

    .line 10
    .line 11
    iget-object v0, v0, LQ1/d;->f:LQ1/g;

    .line 12
    .line 13
    invoke-virtual {v0}, LQ1/g;->c()V

    .line 14
    .line 15
    .line 16
    iget-object v0, v0, LQ1/g;->b:LR1/c;

    .line 17
    .line 18
    if-eqz v0, :cond_1e

    .line 19
    .line 20
    iget-object v0, v0, LR1/c;->j:LA1/d;

    .line 21
    .line 22
    iget-object v0, v0, LA1/d;->f:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Lb2/q;

    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    invoke-virtual {v0, v1, v2, v2}, Lb2/q;->a(Ljava/lang/String;Ljava/lang/Object;Lb2/p;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_1e
    const-string v0, "FlutterActivityAndFragmentDelegate"

    .line 32
    .line 33
    const-string v1, "Invoked commitBackGesture() before FlutterFragment was attached to an Activity."

    .line 34
    .line 35
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    :cond_25
    return-void
.end method

.method public final onBackProgressed(Landroid/window/BackEvent;)V
    .registers 5

    .line 1
    iget-object v0, p0, LQ1/c;->a:LQ1/d;

    .line 2
    .line 3
    const-string v1, "updateBackGestureProgress"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LQ1/d;->l(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    if-eqz v2, :cond_2c

    .line 10
    .line 11
    iget-object v0, v0, LQ1/d;->f:LQ1/g;

    .line 12
    .line 13
    invoke-virtual {v0}, LQ1/g;->c()V

    .line 14
    .line 15
    .line 16
    iget-object v0, v0, LQ1/g;->b:LR1/c;

    .line 17
    .line 18
    if-eqz v0, :cond_25

    .line 19
    .line 20
    iget-object v0, v0, LR1/c;->j:LA1/d;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    invoke-static {p1}, LA1/d;->v(Landroid/window/BackEvent;)Ljava/util/HashMap;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    iget-object v0, v0, LA1/d;->f:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lb2/q;

    .line 32
    .line 33
    const/4 v2, 0x0

    .line 34
    invoke-virtual {v0, v1, p1, v2}, Lb2/q;->a(Ljava/lang/String;Ljava/lang/Object;Lb2/p;)V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_25
    const-string p1, "FlutterActivityAndFragmentDelegate"

    .line 39
    .line 40
    const-string v0, "Invoked updateBackGestureProgress() before FlutterFragment was attached to an Activity."

    .line 41
    .line 42
    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    :cond_2c
    return-void
.end method

.method public final onBackStarted(Landroid/window/BackEvent;)V
    .registers 5

    .line 1
    iget-object v0, p0, LQ1/c;->a:LQ1/d;

    .line 2
    .line 3
    const-string v1, "startBackGesture"

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LQ1/d;->l(Ljava/lang/String;)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    if-eqz v2, :cond_2c

    .line 10
    .line 11
    iget-object v0, v0, LQ1/d;->f:LQ1/g;

    .line 12
    .line 13
    invoke-virtual {v0}, LQ1/g;->c()V

    .line 14
    .line 15
    .line 16
    iget-object v0, v0, LQ1/g;->b:LR1/c;

    .line 17
    .line 18
    if-eqz v0, :cond_25

    .line 19
    .line 20
    iget-object v0, v0, LR1/c;->j:LA1/d;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    invoke-static {p1}, LA1/d;->v(Landroid/window/BackEvent;)Ljava/util/HashMap;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    iget-object v0, v0, LA1/d;->f:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v0, Lb2/q;

    .line 32
    .line 33
    const/4 v2, 0x0

    .line 34
    invoke-virtual {v0, v1, p1, v2}, Lb2/q;->a(Ljava/lang/String;Ljava/lang/Object;Lb2/p;)V

    .line 35
    .line 36
    .line 37
    return-void

    .line 38
    :cond_25
    const-string p1, "FlutterActivityAndFragmentDelegate"

    .line 39
    .line 40
    const-string v0, "Invoked startBackGesture() before FlutterFragment was attached to an Activity."

    .line 41
    .line 42
    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    :cond_2c
    return-void
.end method
