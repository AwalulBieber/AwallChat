###### Class p070x0.b (x0.b)
.class public final Lx0/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lk1/d;


# static fields
.field public static final a:Lx0/b;

.field public static final b:Lk1/c;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lx0/b;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lx0/b;->a:Lx0/b;

    .line 7
    .line 8
    new-instance v0, Ln1/a;

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    invoke-direct {v0, v1}, Ln1/a;-><init>(I)V

    .line 12
    .line 13
    .line 14
    const-class v1, Ln1/e;

    .line 15
    .line 16
    invoke-static {v1, v0}, LK1/c;->j(Ljava/lang/Class;Ln1/a;)Ljava/util/HashMap;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    new-instance v1, Lk1/c;

    .line 21
    .line 22
    invoke-static {v0}, LK1/c;->k(Ljava/util/HashMap;)Ljava/util/Map;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    const-string v2, "storageMetrics"

    .line 27
    .line 28
    invoke-direct {v1, v2, v0}, Lk1/c;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    .line 29
    .line 30
    .line 31
    sput-object v1, Lx0/b;->b:Lk1/c;

    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    check-cast p1, LA0/b;

    .line 2
    .line 3
    check-cast p2, Lk1/e;

    .line 4
    .line 5
    iget-object p1, p1, LA0/b;->a:LA0/f;

    .line 6
    .line 7
    sget-object v0, Lx0/b;->b:Lk1/c;

    .line 8
    .line 9
    invoke-interface {p2, v0, p1}, Lk1/e;->c(Lk1/c;Ljava/lang/Object;)Lk1/e;

    .line 10
    .line 11
    .line 12
    return-void
.end method
