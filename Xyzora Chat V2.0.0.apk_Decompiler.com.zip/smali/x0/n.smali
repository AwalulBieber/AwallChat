###### Class p070x0.n (x0.n)
.class public final Lx0/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lu0/e;


# instance fields
.field public final a:Ljava/util/Set;

.field public final b:Lx0/i;

.field public final c:Lx0/o;


# direct methods
.method public constructor <init>(Ljava/util/Set;Lx0/i;Lx0/o;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lx0/n;->a:Ljava/util/Set;

    .line 5
    .line 6
    iput-object p2, p0, Lx0/n;->b:Lx0/i;

    .line 7
    .line 8
    iput-object p3, p0, Lx0/n;->c:Lx0/o;

    .line 9
    .line 10
    return-void
.end method
