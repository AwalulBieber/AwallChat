###### Class p070x0.o (x0.o)
.class public final Lx0/o;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static volatile e:Lx0/j;


# instance fields
.field public final a:LG0/a;

.field public final b:LG0/a;

.field public final c:LC0/e;

.field public final d:LD0/m;


# direct methods
.method public constructor <init>(LG0/a;LG0/a;LC0/e;LD0/m;LD0/o;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lx0/o;->a:LG0/a;

    .line 5
    .line 6
    iput-object p2, p0, Lx0/o;->b:LG0/a;

    .line 7
    .line 8
    iput-object p3, p0, Lx0/o;->c:LC0/e;

    .line 9
    .line 10
    iput-object p4, p0, Lx0/o;->d:LD0/m;

    .line 11
    .line 12
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    new-instance p1, LD0/n;

    .line 16
    .line 17
    const/4 p2, 0x0

    .line 18
    invoke-direct {p1, p2, p5}, LD0/n;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iget-object p2, p5, LD0/o;->a:Ljava/util/concurrent/Executor;

    .line 22
    .line 23
    invoke-interface {p2, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public static a()Lx0/o;
    .registers 2

    .line 1
    sget-object v0, Lx0/o;->e:Lx0/j;

    .line 2
    .line 3
    if-eqz v0, :cond_d

    .line 4
    .line 5
    iget-object v0, v0, Lx0/j;->j:Ln2/a;

    .line 6
    .line 7
    invoke-interface {v0}, Ln2/a;->get()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Lx0/o;

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_d
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v1, "Not initialized!"

    .line 17
    .line 18
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw v0
.end method

.method public static b(Landroid/content/Context;)V
    .registers 3

    .line 1
    sget-object v0, Lx0/o;->e:Lx0/j;

    .line 2
    .line 3
    if-nez v0, :cond_22

    .line 4
    .line 5
    const-class v0, Lx0/o;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_7
    sget-object v1, Lx0/o;->e:Lx0/j;

    .line 9
    .line 10
    if-nez v1, :cond_1e

    .line 11
    .line 12
    new-instance v1, Lq0/a;

    .line 13
    .line 14
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    iput-object p0, v1, Lq0/a;->a:Landroid/content/Context;

    .line 21
    .line 22
    invoke-virtual {v1}, Lq0/a;->a()Lx0/j;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    sput-object p0, Lx0/o;->e:Lx0/j;

    .line 27
    .line 28
    goto :goto_1e

    .line 29
    :catchall_1c
    move-exception p0

    .line 30
    goto :goto_20

    .line 31
    :cond_1e
    :goto_1e
    monitor-exit v0

    .line 32
    return-void

    .line 33
    :goto_20
    monitor-exit v0
    :try_end_21
    .catchall {:try_start_7 .. :try_end_21} :catchall_1c

    .line 34
    throw p0

    .line 35
    :cond_22
    return-void
.end method


# virtual methods
.method public final c(Lv0/a;)Lx0/n;
    .registers 8

    .line 1
    new-instance v0, Lx0/n;

    .line 2
    .line 3
    if-eqz p1, :cond_b

    .line 4
    .line 5
    sget-object v1, Lv0/a;->d:Ljava/util/Set;

    .line 6
    .line 7
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    goto :goto_16

    .line 12
    :cond_b
    new-instance v1, Lu0/c;

    .line 13
    .line 14
    const-string v2, "proto"

    .line 15
    .line 16
    invoke-direct {v1, v2}, Lu0/c;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-static {v1}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    :goto_16
    invoke-static {}, Lx0/i;->a()LC0/f;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    const-string v3, "cct"

    .line 31
    .line 32
    iput-object v3, v2, LC0/f;->f:Ljava/lang/Object;

    .line 33
    .line 34
    iget-object v3, p1, Lv0/a;->a:Ljava/lang/String;

    .line 35
    .line 36
    iget-object p1, p1, Lv0/a;->b:Ljava/lang/String;

    .line 37
    .line 38
    if-nez p1, :cond_2b

    .line 39
    .line 40
    if-nez v3, :cond_2b

    .line 41
    .line 42
    const/4 p1, 0x0

    .line 43
    goto :goto_4f

    .line 44
    :cond_2b
    if-nez p1, :cond_2f

    .line 45
    .line 46
    const-string p1, ""

    .line 47
    .line 48
    :cond_2f
    new-instance v4, Ljava/lang/StringBuilder;

    .line 49
    .line 50
    const-string v5, "1$"

    .line 51
    .line 52
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    const-string v3, "\\"

    .line 59
    .line 60
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    const-string v3, "UTF-8"

    .line 71
    .line 72
    invoke-static {v3}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    invoke-virtual {p1, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    :goto_4f
    iput-object p1, v2, LC0/f;->g:Ljava/lang/Object;

    .line 81
    .line 82
    invoke-virtual {v2}, LC0/f;->u()Lx0/i;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    invoke-direct {v0, v1, p1, p0}, Lx0/n;-><init>(Ljava/util/Set;Lx0/i;Lx0/o;)V

    .line 87
    .line 88
    .line 89
    return-object v0
.end method
