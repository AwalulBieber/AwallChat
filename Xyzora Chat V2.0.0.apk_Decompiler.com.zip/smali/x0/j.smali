###### Class p070x0.j (x0.j)
.class public final Lx0/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field public e:Ln2/a;

.field public f:Ld0/n;

.field public g:Ln2/a;

.field public h:LD/i;

.field public i:Ln2/a;

.field public j:Ln2/a;


# virtual methods
.method public final close()V
    .registers 2

    .line 1
    iget-object v0, p0, Lx0/j;->i:Ln2/a;

    .line 2
    .line 3
    invoke-interface {v0}, Ln2/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LE0/d;

    .line 8
    .line 9
    check-cast v0, LE0/i;

    .line 10
    .line 11
    invoke-virtual {v0}, LE0/i;->close()V

    .line 12
    .line 13
    .line 14
    return-void
.end method
