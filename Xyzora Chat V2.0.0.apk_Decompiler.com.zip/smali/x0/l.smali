###### Class p070x0.l (x0.l)
.class public abstract Lx0/l;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LJ0/g;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, LJ0/g;

    .line 2
    .line 3
    const/16 v1, 0x19

    .line 4
    .line 5
    invoke-direct {v0, v1}, LJ0/g;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lx0/l;->a:LJ0/g;

    .line 9
    .line 10
    return-void
.end method
