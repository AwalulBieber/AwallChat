###### Class A0.d (A0.d)
.class public final LA0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:LA0/c;


# direct methods
.method public constructor <init>(JLA0/c;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, LA0/d;->a:J

    .line 5
    .line 6
    iput-object p3, p0, LA0/d;->b:LA0/c;

    .line 7
    .line 8
    return-void
.end method
