###### Class A0.b (A0.b)
.class public final LA0/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LA0/f;


# direct methods
.method public constructor <init>(LA0/f;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LA0/b;->a:LA0/f;

    .line 5
    .line 6
    return-void
.end method
