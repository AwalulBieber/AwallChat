###### Class A0.f (A0.f)
.class public final LA0/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:J


# direct methods
.method public constructor <init>(JJ)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, LA0/f;->a:J

    .line 5
    .line 6
    iput-wide p3, p0, LA0/f;->b:J

    .line 7
    .line 8
    return-void
.end method
