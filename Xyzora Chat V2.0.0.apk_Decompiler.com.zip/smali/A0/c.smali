###### Class A0.c (A0.c)
.class public final enum LA0/c;
.super Ljava/lang/Enum;
.source "SourceFile"

# interfaces
.implements Ln1/c;


# static fields
.field public static final enum f:LA0/c;

.field public static final enum g:LA0/c;

.field public static final enum h:LA0/c;

.field public static final enum i:LA0/c;

.field public static final enum j:LA0/c;

.field public static final enum k:LA0/c;

.field public static final enum l:LA0/c;

.field public static final synthetic m:[LA0/c;


# instance fields
.field public final e:I


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 1
    new-instance v0, LA0/c;

    .line 2
    .line 3
    const-string v1, "REASON_UNKNOWN"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v2, v1, v2}, LA0/c;-><init>(ILjava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LA0/c;->f:LA0/c;

    .line 10
    .line 11
    new-instance v1, LA0/c;

    .line 12
    .line 13
    const-string v2, "MESSAGE_TOO_OLD"

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    invoke-direct {v1, v3, v2, v3}, LA0/c;-><init>(ILjava/lang/String;I)V

    .line 17
    .line 18
    .line 19
    sput-object v1, LA0/c;->g:LA0/c;

    .line 20
    .line 21
    new-instance v2, LA0/c;

    .line 22
    .line 23
    const-string v3, "CACHE_FULL"

    .line 24
    .line 25
    const/4 v4, 0x2

    .line 26
    invoke-direct {v2, v4, v3, v4}, LA0/c;-><init>(ILjava/lang/String;I)V

    .line 27
    .line 28
    .line 29
    sput-object v2, LA0/c;->h:LA0/c;

    .line 30
    .line 31
    new-instance v3, LA0/c;

    .line 32
    .line 33
    const-string v4, "PAYLOAD_TOO_BIG"

    .line 34
    .line 35
    const/4 v5, 0x3

    .line 36
    invoke-direct {v3, v5, v4, v5}, LA0/c;-><init>(ILjava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    sput-object v3, LA0/c;->i:LA0/c;

    .line 40
    .line 41
    new-instance v4, LA0/c;

    .line 42
    .line 43
    const-string v5, "MAX_RETRIES_REACHED"

    .line 44
    .line 45
    const/4 v6, 0x4

    .line 46
    invoke-direct {v4, v6, v5, v6}, LA0/c;-><init>(ILjava/lang/String;I)V

    .line 47
    .line 48
    .line 49
    sput-object v4, LA0/c;->j:LA0/c;

    .line 50
    .line 51
    new-instance v5, LA0/c;

    .line 52
    .line 53
    const-string v6, "INVALID_PAYLOD"

    .line 54
    .line 55
    const/4 v7, 0x5

    .line 56
    invoke-direct {v5, v7, v6, v7}, LA0/c;-><init>(ILjava/lang/String;I)V

    .line 57
    .line 58
    .line 59
    sput-object v5, LA0/c;->k:LA0/c;

    .line 60
    .line 61
    new-instance v6, LA0/c;

    .line 62
    .line 63
    const-string v7, "SERVER_ERROR"

    .line 64
    .line 65
    const/4 v8, 0x6

    .line 66
    invoke-direct {v6, v8, v7, v8}, LA0/c;-><init>(ILjava/lang/String;I)V

    .line 67
    .line 68
    .line 69
    sput-object v6, LA0/c;->l:LA0/c;

    .line 70
    .line 71
    filled-new-array/range {v0 .. v6}, [LA0/c;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    sput-object v0, LA0/c;->m:[LA0/c;

    .line 76
    .line 77
    return-void
.end method

.method public constructor <init>(ILjava/lang/String;I)V
    .registers 4

    .line 1
    invoke-direct {p0, p2, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, LA0/c;->e:I

    .line 5
    .line 6
    return-void
.end method

.method public static valueOf(Ljava/lang/String;)LA0/c;
    .registers 2

    .line 1
    const-class v0, LA0/c;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, LA0/c;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[LA0/c;
    .registers 1

    .line 1
    sget-object v0, LA0/c;->m:[LA0/c;

    .line 2
    .line 3
    invoke-virtual {v0}, [LA0/c;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [LA0/c;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final a()I
    .registers 2

    .line 1
    iget v0, p0, LA0/c;->e:I

    .line 2
    .line 3
    return v0
.end method
