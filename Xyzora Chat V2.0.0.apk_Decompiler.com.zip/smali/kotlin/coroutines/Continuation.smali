###### Class kotlin.coroutines.Continuation (kotlin.coroutines.Continuation)
.class public interface abstract Lkotlin/coroutines/Continuation;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract getContext()Lq2/h;
.end method

.method public abstract resumeWith(Ljava/lang/Object;)V
.end method
