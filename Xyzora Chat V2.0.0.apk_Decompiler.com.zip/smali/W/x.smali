###### Class W.x (W.x)
.class public abstract LW/x;
.super Ljava/lang/Object;
.source "SourceFile"
