###### Class W.s (W.s)
.class public abstract LW/s;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:LJ0/g;

.field public b:Ljava/util/ArrayList;

.field public c:J

.field public d:J


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()Z
.end method
