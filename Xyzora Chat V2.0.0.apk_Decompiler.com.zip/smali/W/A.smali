###### Class W.A (W.A)
.class public interface abstract LW/A;
.super Ljava/lang/Object;
.source "SourceFile"
