###### Class W.E (W.E)
.class public final LW/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public e:I

.field public f:I

.field public g:Landroid/widget/OverScroller;

.field public h:Landroid/view/animation/Interpolator;

.field public i:Z

.field public j:Z

.field public final synthetic k:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LW/E;->k:Landroidx/recyclerview/widget/RecyclerView;

    .line 5
    .line 6
    sget-object v0, Landroidx/recyclerview/widget/RecyclerView;->o0:LW/o;

    .line 7
    .line 8
    iput-object v0, p0, LW/E;->h:Landroid/view/animation/Interpolator;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    iput-boolean v1, p0, LW/E;->i:Z

    .line 12
    .line 13
    iput-boolean v1, p0, LW/E;->j:Z

    .line 14
    .line 15
    new-instance v1, Landroid/widget/OverScroller;

    .line 16
    .line 17
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-direct {v1, p1, v0}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    .line 22
    .line 23
    .line 24
    iput-object v1, p0, LW/E;->g:Landroid/widget/OverScroller;

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    .line 1
    iget-boolean v0, p0, LW/E;->i:Z

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, LW/E;->j:Z

    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-object v0, p0, LW/E;->k:Landroidx/recyclerview/widget/RecyclerView;

    .line 10
    .line 11
    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 12
    .line 13
    .line 14
    sget-object v1, LC/C;->a:Ljava/lang/reflect/Field;

    .line 15
    .line 16
    invoke-virtual {v0, p0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final run()V
    .registers 10

    .line 1
    iget-object v0, p0, LW/E;->k:Landroidx/recyclerview/widget/RecyclerView;

    .line 2
    .line 3
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->m:LW/t;

    .line 4
    .line 5
    if-nez v1, :cond_f

    .line 6
    .line 7
    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, LW/E;->g:Landroid/widget/OverScroller;

    .line 11
    .line 12
    invoke-virtual {v0}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_f
    const/4 v6, 0x0

    .line 17
    iput-boolean v6, p0, LW/E;->j:Z

    .line 18
    .line 19
    const/4 v7, 0x1

    .line 20
    iput-boolean v7, p0, LW/E;->i:Z

    .line 21
    .line 22
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->d()V

    .line 23
    .line 24
    .line 25
    iget-object v8, p0, LW/E;->g:Landroid/widget/OverScroller;

    .line 26
    .line 27
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->m:LW/t;

    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v8}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_c3

    .line 37
    .line 38
    invoke-virtual {v8}, Landroid/widget/OverScroller;->getCurrX()I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    invoke-virtual {v8}, Landroid/widget/OverScroller;->getCurrY()I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    iget v3, p0, LW/E;->e:I

    .line 47
    .line 48
    sub-int v3, v1, v3

    .line 49
    .line 50
    iget v4, p0, LW/E;->f:I

    .line 51
    .line 52
    sub-int v4, v2, v4

    .line 53
    .line 54
    iput v1, p0, LW/E;->e:I

    .line 55
    .line 56
    iput v2, p0, LW/E;->f:I

    .line 57
    .line 58
    move v1, v3

    .line 59
    const/4 v3, 0x1

    .line 60
    move v2, v4

    .line 61
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->h0:[I

    .line 62
    .line 63
    const/4 v5, 0x0

    .line 64
    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView;->f(III[I[I)Z

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    if-eqz v3, :cond_4e

    .line 69
    .line 70
    aget v3, v4, v6

    .line 71
    .line 72
    sub-int v3, v1, v3

    .line 73
    .line 74
    aget v1, v4, v7

    .line 75
    .line 76
    sub-int v4, v2, v1

    .line 77
    .line 78
    goto :goto_50

    .line 79
    :cond_4e
    move v3, v1

    .line 80
    move v4, v2

    .line 81
    :goto_50
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Ljava/util/ArrayList;

    .line 82
    .line 83
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    if-nez v1, :cond_5b

    .line 88
    .line 89
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 90
    .line 91
    .line 92
    :cond_5b
    invoke-virtual {v0}, Landroid/view/View;->getOverScrollMode()I

    .line 93
    .line 94
    .line 95
    move-result v1

    .line 96
    const/4 v2, 0x2

    .line 97
    if-eq v1, v2, :cond_65

    .line 98
    .line 99
    invoke-virtual {v0, v3, v4}, Landroidx/recyclerview/widget/RecyclerView;->c(II)V

    .line 100
    .line 101
    .line 102
    :cond_65
    const/4 v1, 0x0

    .line 103
    invoke-virtual {v0, v1, v7}, Landroidx/recyclerview/widget/RecyclerView;->g([II)Z

    .line 104
    .line 105
    .line 106
    invoke-static {v0}, Landroidx/recyclerview/widget/RecyclerView;->a(Landroidx/recyclerview/widget/RecyclerView;)Z

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    if-nez v1, :cond_72

    .line 111
    .line 112
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 113
    .line 114
    .line 115
    :cond_72
    if-eqz v4, :cond_80

    .line 116
    .line 117
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->m:LW/t;

    .line 118
    .line 119
    invoke-virtual {v1}, LW/t;->c()Z

    .line 120
    .line 121
    .line 122
    move-result v1

    .line 123
    if-eqz v1, :cond_80

    .line 124
    .line 125
    if-nez v4, :cond_80

    .line 126
    .line 127
    move v1, v7

    .line 128
    goto :goto_81

    .line 129
    :cond_80
    move v1, v6

    .line 130
    :goto_81
    if-eqz v3, :cond_8f

    .line 131
    .line 132
    iget-object v2, v0, Landroidx/recyclerview/widget/RecyclerView;->m:LW/t;

    .line 133
    .line 134
    invoke-virtual {v2}, LW/t;->b()Z

    .line 135
    .line 136
    .line 137
    move-result v2

    .line 138
    if-eqz v2, :cond_8f

    .line 139
    .line 140
    if-nez v3, :cond_8f

    .line 141
    .line 142
    move v2, v7

    .line 143
    goto :goto_90

    .line 144
    :cond_8f
    move v2, v6

    .line 145
    :goto_90
    if-nez v3, :cond_94

    .line 146
    .line 147
    if-eqz v4, :cond_9b

    .line 148
    .line 149
    :cond_94
    if-nez v2, :cond_9b

    .line 150
    .line 151
    if-eqz v1, :cond_99

    .line 152
    .line 153
    goto :goto_9b

    .line 154
    :cond_99
    move v1, v6

    .line 155
    goto :goto_9c

    .line 156
    :cond_9b
    :goto_9b
    move v1, v7

    .line 157
    :goto_9c
    invoke-virtual {v8}, Landroid/widget/OverScroller;->isFinished()Z

    .line 158
    .line 159
    .line 160
    move-result v2

    .line 161
    if-nez v2, :cond_b6

    .line 162
    .line 163
    if-nez v1, :cond_ab

    .line 164
    .line 165
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->k()Z

    .line 166
    .line 167
    .line 168
    move-result v1

    .line 169
    if-nez v1, :cond_ab

    .line 170
    .line 171
    goto :goto_b6

    .line 172
    :cond_ab
    invoke-virtual {p0}, LW/E;->a()V

    .line 173
    .line 174
    .line 175
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->W:LW/j;

    .line 176
    .line 177
    if-eqz v1, :cond_c3

    .line 178
    .line 179
    invoke-virtual {v1, v0, v3, v4}, LW/j;->a(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 180
    .line 181
    .line 182
    goto :goto_c3

    .line 183
    :cond_b6
    :goto_b6
    invoke-virtual {v0, v6}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 184
    .line 185
    .line 186
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->a0:LW/h;

    .line 187
    .line 188
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 189
    .line 190
    .line 191
    iput v6, v1, LW/h;->c:I

    .line 192
    .line 193
    invoke-virtual {v0, v7}, Landroidx/recyclerview/widget/RecyclerView;->s(I)V

    .line 194
    .line 195
    .line 196
    :cond_c3
    :goto_c3
    iput-boolean v6, p0, LW/E;->i:Z

    .line 197
    .line 198
    iget-boolean v0, p0, LW/E;->j:Z

    .line 199
    .line 200
    if-eqz v0, :cond_cc

    .line 201
    .line 202
    invoke-virtual {p0}, LW/E;->a()V

    .line 203
    .line 204
    .line 205
    :cond_cc
    return-void
.end method
