###### Class W.q (W.q)
.class public interface abstract LW/q;
.super Ljava/lang/Object;
.source "SourceFile"
