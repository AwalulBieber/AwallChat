###### Class W.C0095n (W.n)
.class public final LW/n;
.super LR/b;
.source "SourceFile"


# instance fields
.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(LW/t;I)V
    .registers 3

    .line 1
    iput p2, p0, LW/n;->b:I

    invoke-direct {p0, p1}, LR/b;-><init>(LW/t;)V

    return-void
.end method


# virtual methods
.method public final b(Landroid/view/View;)I
    .registers 4

    .line 1
    iget v0, p0, LW/n;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_46

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, LW/u;

    .line 11
    .line 12
    iget-object v1, p0, LR/b;->a:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, LW/t;

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, LW/u;

    .line 28
    .line 29
    iget-object p1, p1, LW/u;->a:Landroid/graphics/Rect;

    .line 30
    .line 31
    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    .line 32
    .line 33
    add-int/2addr v1, p1

    .line 34
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 35
    .line 36
    add-int/2addr v1, p1

    .line 37
    return v1

    .line 38
    :pswitch_25
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, LW/u;

    .line 43
    .line 44
    iget-object v1, p0, LR/b;->a:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v1, LW/t;

    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    check-cast p1, LW/u;

    .line 60
    .line 61
    iget-object p1, p1, LW/u;->a:Landroid/graphics/Rect;

    .line 62
    .line 63
    iget p1, p1, Landroid/graphics/Rect;->right:I

    .line 64
    .line 65
    add-int/2addr v1, p1

    .line 66
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 67
    .line 68
    add-int/2addr v1, p1

    .line 69
    return v1

    .line 70
    nop

    .line 71
    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_25
    .end packed-switch
.end method

.method public final c(Landroid/view/View;)I
    .registers 4

    .line 1
    iget v0, p0, LW/n;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_46

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, LW/u;

    .line 11
    .line 12
    iget-object v1, p0, LR/b;->a:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, LW/t;

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, LW/u;

    .line 28
    .line 29
    iget-object p1, p1, LW/u;->a:Landroid/graphics/Rect;

    .line 30
    .line 31
    iget p1, p1, Landroid/graphics/Rect;->top:I

    .line 32
    .line 33
    sub-int/2addr v1, p1

    .line 34
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 35
    .line 36
    sub-int/2addr v1, p1

    .line 37
    return v1

    .line 38
    :pswitch_25
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, LW/u;

    .line 43
    .line 44
    iget-object v1, p0, LR/b;->a:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v1, LW/t;

    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    check-cast p1, LW/u;

    .line 60
    .line 61
    iget-object p1, p1, LW/u;->a:Landroid/graphics/Rect;

    .line 62
    .line 63
    iget p1, p1, Landroid/graphics/Rect;->left:I

    .line 64
    .line 65
    sub-int/2addr v1, p1

    .line 66
    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 67
    .line 68
    sub-int/2addr v1, p1

    .line 69
    return v1

    .line 70
    nop

    .line 71
    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_25
    .end packed-switch
.end method

.method public final d()I
    .registers 3

    .line 1
    iget v0, p0, LW/n;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_1e

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LR/b;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LW/t;

    .line 9
    .line 10
    iget v1, v0, LW/t;->g:I

    .line 11
    .line 12
    invoke-virtual {v0}, LW/t;->r()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    sub-int/2addr v1, v0

    .line 17
    return v1

    .line 18
    :pswitch_11
    iget-object v0, p0, LR/b;->a:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, LW/t;

    .line 21
    .line 22
    iget v1, v0, LW/t;->f:I

    .line 23
    .line 24
    invoke-virtual {v0}, LW/t;->t()I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    sub-int/2addr v1, v0

    .line 29
    return v1

    .line 30
    nop

    .line 31
    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method

.method public final e()I
    .registers 2

    .line 1
    iget v0, p0, LW/n;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_18

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LR/b;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LW/t;

    .line 9
    .line 10
    invoke-virtual {v0}, LW/t;->u()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    return v0

    .line 15
    :pswitch_e
    iget-object v0, p0, LR/b;->a:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, LW/t;

    .line 18
    .line 19
    invoke-virtual {v0}, LW/t;->s()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    return v0

    .line 24
    nop

    .line 25
    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method

.method public final f()I
    .registers 4

    .line 1
    iget v0, p0, LW/n;->b:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_28

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LR/b;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LW/t;

    .line 9
    .line 10
    iget v1, v0, LW/t;->g:I

    .line 11
    .line 12
    invoke-virtual {v0}, LW/t;->u()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    sub-int/2addr v1, v2

    .line 17
    invoke-virtual {v0}, LW/t;->r()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    sub-int/2addr v1, v0

    .line 22
    return v1

    .line 23
    :pswitch_16
    iget-object v0, p0, LR/b;->a:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v0, LW/t;

    .line 26
    .line 27
    iget v1, v0, LW/t;->f:I

    .line 28
    .line 29
    invoke-virtual {v0}, LW/t;->s()I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    sub-int/2addr v1, v2

    .line 34
    invoke-virtual {v0}, LW/t;->t()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    sub-int/2addr v1, v0

    .line 39
    return v1

    .line 40
    nop

    .line 41
    :pswitch_data_28
    .packed-switch 0x0
        :pswitch_16
    .end packed-switch
.end method
