###### Class C2.a (C2.a)
.class public interface abstract LC2/a;
.super Ljava/lang/Object;
.source "SourceFile"
