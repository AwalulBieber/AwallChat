###### Class C2.c (C2.c)
.class public interface abstract LC2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC2/a;
