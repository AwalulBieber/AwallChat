###### Class E0.c (E0.c)
.class public interface abstract LE0/c;
.super Ljava/lang/Object;
.source "SourceFile"
