###### Class E0.g (E0.g)
.class public interface abstract LE0/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract apply(Ljava/lang/Object;)Ljava/lang/Object;
.end method
