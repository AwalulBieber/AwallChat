###### Class E0.h (E0.h)
.class public final LE0/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LE0/h;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, LE0/h;->b:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method
