###### Class E0.e (E0.e)
.class public final LE0/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz0/b;


# instance fields
.field public final synthetic e:I

.field public final f:Ld0/n;


# direct methods
.method public synthetic constructor <init>(Ld0/n;I)V
    .registers 3

    .line 1
    iput p2, p0, LE0/e;->e:I

    iput-object p1, p0, LE0/e;->f:Ld0/n;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, LE0/e;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_32

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LE0/e;->f:Ld0/n;

    .line 7
    .line 8
    iget-object v0, v0, Ld0/n;->f:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Landroid/content/Context;

    .line 11
    .line 12
    new-instance v1, LM0/f;

    .line 13
    .line 14
    const/4 v2, 0x5

    .line 15
    invoke-direct {v1, v2}, LM0/f;-><init>(I)V

    .line 16
    .line 17
    .line 18
    new-instance v2, LJ0/g;

    .line 19
    .line 20
    const/4 v3, 0x5

    .line 21
    invoke-direct {v2, v3}, LJ0/g;-><init>(I)V

    .line 22
    .line 23
    .line 24
    new-instance v3, Ly0/e;

    .line 25
    .line 26
    invoke-direct {v3, v0, v1, v2}, Ly0/e;-><init>(Landroid/content/Context;LG0/a;LG0/a;)V

    .line 27
    .line 28
    .line 29
    return-object v3

    .line 30
    :pswitch_1d
    iget-object v0, p0, LE0/e;->f:Ld0/n;

    .line 31
    .line 32
    iget-object v0, v0, Ld0/n;->f:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, Landroid/content/Context;

    .line 35
    .line 36
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    if-eqz v0, :cond_2a

    .line 41
    .line 42
    return-object v0

    .line 43
    :cond_2a
    new-instance v0, Ljava/lang/NullPointerException;

    .line 44
    .line 45
    const-string v1, "Cannot return null from a non-@Nullable @Provides method"

    .line 46
    .line 47
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw v0

    .line 51
    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_1d
    .end packed-switch
.end method
