###### Class E0.j (E0.j)
.class public final LE0/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz0/b;
.implements Lc1/a;
.implements LI2/d;
.implements Lc1/c;
.implements LQ1/w;
.implements Lb2/o;
.implements Lb2/c;
.implements Lb2/d;


# static fields
.field public static h:LE0/j;


# instance fields
.field public final synthetic e:I

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    iput p1, p0, LE0/j;->e:I

    sparse-switch p1, :sswitch_data_40

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/WeakHashMap;

    invoke-direct {p1}, Ljava/util/WeakHashMap;-><init>()V

    .line 4
    invoke-static {p1}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    new-instance p1, Ljava/util/WeakHashMap;

    .line 5
    invoke-direct {p1}, Ljava/util/WeakHashMap;-><init>()V

    .line 6
    invoke-static {p1}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    return-void

    .line 7
    :sswitch_1f
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance p1, Landroid/util/LongSparseArray;

    invoke-direct {p1}, Landroid/util/LongSparseArray;-><init>()V

    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 9
    new-instance p1, Ljava/util/PriorityQueue;

    invoke-direct {p1}, Ljava/util/PriorityQueue;-><init>()V

    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    return-void

    .line 10
    :sswitch_31
    sget-object p1, LJ0/d;->c:LJ0/d;

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 12
    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    return-void

    :sswitch_data_40
    .sparse-switch
        0xe -> :sswitch_31
        0x11 -> :sswitch_1f
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, LE0/j;->e:I

    iput-object p2, p0, LE0/j;->f:Ljava/lang/Object;

    iput-object p3, p0, LE0/j;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LA1/d;)V
    .registers 3

    const/16 v0, 0x10

    iput v0, p0, LE0/j;->e:I

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    new-instance v0, LM2/j;

    invoke-direct {v0}, LM2/j;-><init>()V

    iput-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    .line 31
    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LD/i;)V
    .registers 3

    const/16 v0, 0x13

    iput v0, p0, LE0/j;->e:I

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 33
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LO0/b;LJ0/g;)V
    .registers 3

    const/4 p2, 0x7

    iput p2, p0, LE0/j;->e:I

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    const-string p2, "ClientTelemetry.API"

    iput-object p2, p0, LE0/j;->g:Ljava/lang/Object;

    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LS0/a;Landroidx/lifecycle/G;LR/b;)V
    .registers 5

    const/16 v0, 0x1b

    iput v0, p0, LE0/j;->e:I

    const-string v0, "store"

    invoke-static {p1, v0}, Lz2/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "defaultCreationExtras"

    invoke-static {p3, p1}, Lz2/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    iput-object p2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 36
    iput-object p3, p0, LE0/j;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LS1/b;I)V
    .registers 6

    iput p2, p0, LE0/j;->e:I

    packed-switch p2, :pswitch_data_82

    .line 41
    :pswitch_5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    new-instance p2, LA1/d;

    const/16 v0, 0x15

    invoke-direct {p2, v0, p0}, LA1/d;-><init>(ILjava/lang/Object;)V

    .line 43
    new-instance v0, Lb2/q;

    sget-object v1, Lb2/k;->a:Lb2/k;

    const-string v2, "flutter/localization"

    invoke-direct {v0, p1, v2, v1}, Lb2/q;-><init>(Lb2/f;Ljava/lang/String;Lb2/r;)V

    iput-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 44
    invoke-virtual {v0, p2}, Lb2/q;->b(Lb2/o;)V

    return-void

    .line 45
    :pswitch_1e
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    new-instance p2, LA1/d;

    const/16 v0, 0x1d

    invoke-direct {p2, v0, p0}, LA1/d;-><init>(ILjava/lang/Object;)V

    .line 47
    new-instance v0, Lb2/q;

    sget-object v1, Lb2/k;->a:Lb2/k;

    const-string v2, "flutter/textinput"

    invoke-direct {v0, p1, v2, v1}, Lb2/q;-><init>(Lb2/f;Ljava/lang/String;Lb2/r;)V

    iput-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 48
    invoke-virtual {v0, p2}, Lb2/q;->b(Lb2/o;)V

    return-void

    .line 49
    :pswitch_37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 50
    new-instance p2, LD/i;

    const/16 v0, 0x1b

    invoke-direct {p2, v0, p0}, LD/i;-><init>(ILjava/lang/Object;)V

    .line 51
    new-instance v0, Lb2/q;

    const-string v1, "flutter/platform_views"

    sget-object v2, Lb2/x;->a:Lb2/x;

    invoke-direct {v0, p1, v1, v2}, Lb2/q;-><init>(Lb2/f;Ljava/lang/String;Lb2/r;)V

    iput-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 52
    invoke-virtual {v0, p2}, Lb2/q;->b(Lb2/o;)V

    return-void

    .line 53
    :pswitch_50
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 54
    new-instance p2, LA1/d;

    const/16 v0, 0x18

    invoke-direct {p2, v0, p0}, LA1/d;-><init>(ILjava/lang/Object;)V

    .line 55
    new-instance v0, Lb2/q;

    const-string v1, "flutter/platform_views_2"

    sget-object v2, Lb2/x;->a:Lb2/x;

    invoke-direct {v0, p1, v1, v2}, Lb2/q;-><init>(Lb2/f;Ljava/lang/String;Lb2/r;)V

    iput-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 56
    invoke-virtual {v0, p2}, Lb2/q;->b(Lb2/o;)V

    return-void

    .line 57
    :pswitch_69
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 58
    new-instance p2, LA1/d;

    const/16 v0, 0x17

    invoke-direct {p2, v0, p0}, LA1/d;-><init>(ILjava/lang/Object;)V

    .line 59
    new-instance v0, Lb2/q;

    sget-object v1, Lb2/k;->a:Lb2/k;

    const-string v2, "flutter/platform"

    invoke-direct {v0, p1, v2, v1}, Lb2/q;-><init>(Lb2/f;Ljava/lang/String;Lb2/r;)V

    iput-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 60
    invoke-virtual {v0, p2}, Lb2/q;->b(Lb2/o;)V

    return-void

    :pswitch_data_82
    .packed-switch 0x15
        :pswitch_69
        :pswitch_50
        :pswitch_37
        :pswitch_5
        :pswitch_5
        :pswitch_1e
    .end packed-switch
.end method

.method public constructor <init>(LS1/b;Landroid/content/pm/PackageManager;)V
    .registers 6

    const/16 v0, 0x18

    iput v0, p0, LE0/j;->e:I

    .line 61
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 62
    new-instance v0, LD/i;

    const/16 v1, 0x1c

    invoke-direct {v0, v1, p0}, LD/i;-><init>(ILjava/lang/Object;)V

    .line 63
    iput-object p2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 64
    new-instance p2, Lb2/q;

    const-string v1, "flutter/processtext"

    sget-object v2, Lb2/x;->a:Lb2/x;

    invoke-direct {p2, p1, v1, v2}, Lb2/q;-><init>(Lb2/f;Ljava/lang/String;Lb2/r;)V

    .line 65
    invoke-virtual {p2, v0}, Lb2/q;->b(Lb2/o;)V

    return-void
.end method

.method public constructor <init>(LW/M;)V
    .registers 3

    const/16 v0, 0x12

    iput v0, p0, LE0/j;->e:I

    .line 69
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 70
    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 71
    new-instance p1, LW/L;

    .line 72
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 73
    iput v0, p1, LW/L;->a:I

    .line 74
    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/16 v0, 0xd

    iput v0, p0, LE0/j;->e:I

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, LM0/o;->e(Ljava/lang/Object;)V

    .line 16
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    const v0, 0x7f0e002b

    .line 17
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getResourcePackageName(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/os/IBinder;)V
    .registers 5

    const/4 v0, 0x2

    iput v0, p0, LE0/j;->e:I

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-interface {p1}, Landroid/os/IBinder;->getInterfaceDescriptor()Ljava/lang/String;

    move-result-object v0

    const-string v1, "android.os.IMessenger"

    .line 19
    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1d

    .line 20
    new-instance v0, Landroid/os/Messenger;

    invoke-direct {v0, p1}, Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V

    iput-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    iput-object v2, p0, LE0/j;->g:Ljava/lang/Object;

    goto :goto_2e

    :cond_1d
    const-string v1, "com.google.android.gms.iid.IMessengerCompat"

    .line 21
    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2f

    .line 22
    new-instance v0, LI0/g;

    .line 23
    invoke-direct {v0, p1}, LI0/g;-><init>(Landroid/os/IBinder;)V

    iput-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    iput-object v2, p0, LE0/j;->f:Ljava/lang/Object;

    :goto_2e
    return-void

    .line 24
    :cond_2f
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "MessengerIpcClient"

    const-string v1, "Invalid interface descriptor: "

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 25
    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 26
    new-instance p1, Landroid/os/RemoteException;

    invoke-direct {p1}, Landroid/os/RemoteException;-><init>()V

    throw p1
.end method

.method public constructor <init>(Lj/m;)V
    .registers 7

    const/16 v0, 0xf

    iput v0, p0, LE0/j;->e:I

    const/4 v0, 0x0

    .line 75
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 76
    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 77
    new-instance v1, LO/i;

    invoke-direct {v1, p1}, LO/i;-><init>(Lj/m;)V

    iput-object v1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 78
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 79
    sget-object v1, LO/a;->b:LO/a;

    if-nez v1, :cond_3b

    .line 80
    sget-object v1, LO/a;->a:Ljava/lang/Object;

    monitor-enter v1

    .line 81
    :try_start_1b
    sget-object v2, LO/a;->b:LO/a;

    if-nez v2, :cond_37

    .line 82
    new-instance v2, LO/a;

    .line 83
    invoke-direct {v2}, Landroid/text/Editable$Factory;-><init>()V
    :try_end_24
    .catchall {:try_start_1b .. :try_end_24} :catchall_35

    .line 84
    :try_start_24
    const-string v3, "android.text.DynamicLayout$ChangeWatcher"

    .line 85
    const-class v4, LO/a;

    invoke-virtual {v4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    invoke-static {v3, v0, v4}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    sput-object v0, LO/a;->c:Ljava/lang/Class;
    :try_end_32
    .catchall {:try_start_24 .. :try_end_32} :catchall_32

    .line 86
    :catchall_32
    :try_start_32
    sput-object v2, LO/a;->b:LO/a;

    goto :goto_37

    :catchall_35
    move-exception p1

    goto :goto_39

    .line 87
    :cond_37
    :goto_37
    monitor-exit v1

    goto :goto_3b

    :goto_39
    monitor-exit v1
    :try_end_3a
    .catchall {:try_start_32 .. :try_end_3a} :catchall_35

    throw p1

    .line 88
    :cond_3b
    :goto_3b
    sget-object v0, LO/a;->b:LO/a;

    .line 89
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEditableFactory(Landroid/text/Editable$Factory;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .registers 3

    const/16 v0, 0xc

    iput v0, p0, LE0/j;->e:I

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 28
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V
    .registers 5

    .line 2
    iput p3, p0, LE0/j;->e:I

    iput-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    iput-object p2, p0, LE0/j;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/util/HashMap;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, LE0/j;->e:I

    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    sget-object v0, LH1/b;->a:LH1/b;

    .line 39
    iput-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    .line 40
    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ly1/z;LJ0/g;LM/d;)V
    .registers 4

    const/16 p2, 0xb

    iput p2, p0, LE0/j;->e:I

    .line 66
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 67
    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 68
    iput-object p3, p0, LE0/j;->g:Ljava/lang/Object;

    return-void
.end method

.method public static b(LE0/j;Lorg/json/JSONArray;)I
    .registers 13

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    move v0, p0

    .line 6
    move v1, v0

    .line 7
    move v2, v1

    .line 8
    :goto_7
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    const/4 v4, 0x2

    .line 13
    const/4 v5, 0x4

    .line 14
    const/4 v6, 0x1

    .line 15
    if-ge v0, v3, :cond_6b

    .line 16
    .line 17
    invoke-virtual {p1, v0}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    invoke-static {v5}, LK/j;->c(I)[I

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    array-length v7, v5

    .line 26
    move v8, p0

    .line 27
    :goto_1a
    if-ge v8, v7, :cond_5f

    .line 28
    .line 29
    aget v9, v5, v8

    .line 30
    .line 31
    const/4 v10, 0x1

    .line 32
    if-eq v9, v10, :cond_35

    .line 33
    .line 34
    const/4 v10, 0x2

    .line 35
    if-eq v9, v10, :cond_32

    .line 36
    .line 37
    const/4 v10, 0x3

    .line 38
    if-eq v9, v10, :cond_2f

    .line 39
    .line 40
    const/4 v10, 0x4

    .line 41
    if-ne v9, v10, :cond_2d

    .line 42
    .line 43
    const-string v10, "DeviceOrientation.landscapeRight"

    .line 44
    .line 45
    goto :goto_37

    .line 46
    :cond_2d
    const/4 p0, 0x0

    .line 47
    throw p0

    .line 48
    :cond_2f
    const-string v10, "DeviceOrientation.landscapeLeft"

    .line 49
    .line 50
    goto :goto_37

    .line 51
    :cond_32
    const-string v10, "DeviceOrientation.portraitDown"

    .line 52
    .line 53
    goto :goto_37

    .line 54
    :cond_35
    const-string v10, "DeviceOrientation.portraitUp"

    .line 55
    .line 56
    :goto_37
    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v10

    .line 60
    if-eqz v10, :cond_5c

    .line 61
    .line 62
    invoke-static {v9}, LK/j;->b(I)I

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    if-eqz v3, :cond_54

    .line 67
    .line 68
    if-eq v3, v6, :cond_51

    .line 69
    .line 70
    if-eq v3, v4, :cond_4e

    .line 71
    .line 72
    const/4 v4, 0x3

    .line 73
    if-eq v3, v4, :cond_4b

    .line 74
    .line 75
    goto :goto_56

    .line 76
    :cond_4b
    or-int/lit8 v1, v1, 0x8

    .line 77
    .line 78
    goto :goto_56

    .line 79
    :cond_4e
    or-int/lit8 v1, v1, 0x2

    .line 80
    .line 81
    goto :goto_56

    .line 82
    :cond_51
    or-int/lit8 v1, v1, 0x4

    .line 83
    .line 84
    goto :goto_56

    .line 85
    :cond_54
    or-int/lit8 v1, v1, 0x1

    .line 86
    .line 87
    :goto_56
    if-nez v2, :cond_59

    .line 88
    .line 89
    move v2, v1

    .line 90
    :cond_59
    add-int/lit8 v0, v0, 0x1

    .line 91
    .line 92
    goto :goto_7

    .line 93
    :cond_5c
    add-int/lit8 v8, v8, 0x1

    .line 94
    .line 95
    goto :goto_1a

    .line 96
    :cond_5f
    new-instance p0, Ljava/lang/NoSuchFieldException;

    .line 97
    .line 98
    const-string p1, "No such DeviceOrientation: "

    .line 99
    .line 100
    invoke-static {p1, v3}, LK1/c;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    invoke-direct {p0, p1}, Ljava/lang/NoSuchFieldException;-><init>(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    throw p0

    .line 108
    :cond_6b
    if-eqz v1, :cond_88

    .line 109
    .line 110
    const/16 p1, 0x8

    .line 111
    .line 112
    packed-switch v1, :pswitch_data_8a

    .line 113
    .line 114
    .line 115
    goto :goto_83

    .line 116
    :pswitch_73
    const/16 p0, 0xd

    .line 117
    .line 118
    return p0

    .line 119
    :pswitch_76
    return v4

    .line 120
    :pswitch_77
    const/16 p0, 0xb

    .line 121
    .line 122
    return p0

    .line 123
    :pswitch_7a
    const/16 p0, 0xc

    .line 124
    .line 125
    return p0

    .line 126
    :pswitch_7d
    if-eq v2, v4, :cond_87

    .line 127
    .line 128
    if-eq v2, v5, :cond_85

    .line 129
    .line 130
    if-eq v2, p1, :cond_84

    .line 131
    .line 132
    :goto_83
    return v6

    .line 133
    :cond_84
    :pswitch_84
    return p1

    .line 134
    :cond_85
    :pswitch_85
    const/16 p0, 0x9

    .line 135
    .line 136
    :cond_87
    :pswitch_87
    return p0

    .line 137
    :cond_88
    const/4 p0, -0x1

    .line 138
    return p0

    .line 139
    :pswitch_data_8a
    .packed-switch 0x2
        :pswitch_87
        :pswitch_7d
        :pswitch_85
        :pswitch_7a
        :pswitch_7d
        :pswitch_7d
        :pswitch_84
        :pswitch_7d
        :pswitch_77
        :pswitch_76
        :pswitch_7d
        :pswitch_7d
        :pswitch_7d
        :pswitch_73
    .end packed-switch
.end method

.method public static d(LE0/j;Lorg/json/JSONArray;)Ljava/util/ArrayList;
    .registers 10

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance p0, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    move v1, v0

    .line 11
    :goto_a
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-ge v1, v2, :cond_4d

    .line 16
    .line 17
    invoke-virtual {p1, v1}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-static {}, La2/d;->values()[La2/d;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    array-length v4, v3

    .line 26
    move v5, v0

    .line 27
    :goto_1a
    if-ge v5, v4, :cond_41

    .line 28
    .line 29
    aget-object v6, v3, v5

    .line 30
    .line 31
    iget-object v7, v6, La2/d;->e:Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v7

    .line 37
    if-eqz v7, :cond_3e

    .line 38
    .line 39
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    if-eqz v2, :cond_36

    .line 44
    .line 45
    const/4 v3, 0x1

    .line 46
    if-eq v2, v3, :cond_30

    .line 47
    .line 48
    goto :goto_3b

    .line 49
    :cond_30
    sget-object v2, La2/d;->g:La2/d;

    .line 50
    .line 51
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    goto :goto_3b

    .line 55
    :cond_36
    sget-object v2, La2/d;->f:La2/d;

    .line 56
    .line 57
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    :goto_3b
    add-int/lit8 v1, v1, 0x1

    .line 61
    .line 62
    goto :goto_a

    .line 63
    :cond_3e
    add-int/lit8 v5, v5, 0x1

    .line 64
    .line 65
    goto :goto_1a

    .line 66
    :cond_41
    new-instance p0, Ljava/lang/NoSuchFieldException;

    .line 67
    .line 68
    const-string p1, "No such SystemUiOverlay: "

    .line 69
    .line 70
    invoke-static {p1, v2}, LK1/c;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-direct {p0, p1}, Ljava/lang/NoSuchFieldException;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    throw p0

    .line 78
    :cond_4d
    return-object p0
.end method

.method public static f(LE0/j;Ljava/lang/String;)I
    .registers 7

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x4

    .line 5
    invoke-static {p0}, LK/j;->c(I)[I

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    array-length v1, v0

    .line 10
    const/4 v2, 0x0

    .line 11
    :goto_a
    if-ge v2, v1, :cond_41

    .line 12
    .line 13
    aget v3, v0, v2

    .line 14
    .line 15
    const/4 v4, 0x1

    .line 16
    if-eq v3, v4, :cond_25

    .line 17
    .line 18
    const/4 v4, 0x2

    .line 19
    if-eq v3, v4, :cond_22

    .line 20
    .line 21
    const/4 v4, 0x3

    .line 22
    if-eq v3, v4, :cond_1f

    .line 23
    .line 24
    const/4 v4, 0x4

    .line 25
    if-ne v3, v4, :cond_1d

    .line 26
    .line 27
    const-string v4, "SystemUiMode.edgeToEdge"

    .line 28
    .line 29
    goto :goto_27

    .line 30
    :cond_1d
    const/4 p0, 0x0

    .line 31
    throw p0

    .line 32
    :cond_1f
    const-string v4, "SystemUiMode.immersiveSticky"

    .line 33
    .line 34
    goto :goto_27

    .line 35
    :cond_22
    const-string v4, "SystemUiMode.immersive"

    .line 36
    .line 37
    goto :goto_27

    .line 38
    :cond_25
    const-string v4, "SystemUiMode.leanBack"

    .line 39
    .line 40
    :goto_27
    invoke-virtual {v4, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    if-eqz v4, :cond_3e

    .line 45
    .line 46
    invoke-static {v3}, LK/j;->b(I)I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    const/4 v0, 0x1

    .line 51
    if-eqz p1, :cond_3d

    .line 52
    .line 53
    const/4 v1, 0x2

    .line 54
    if-eq p1, v0, :cond_3c

    .line 55
    .line 56
    if-eq p1, v1, :cond_3a

    .line 57
    .line 58
    return p0

    .line 59
    :cond_3a
    const/4 p0, 0x3

    .line 60
    return p0

    .line 61
    :cond_3c
    return v1

    .line 62
    :cond_3d
    return v0

    .line 63
    :cond_3e
    add-int/lit8 v2, v2, 0x1

    .line 64
    .line 65
    goto :goto_a

    .line 66
    :cond_41
    new-instance p0, Ljava/lang/NoSuchFieldException;

    .line 67
    .line 68
    const-string v0, "No such SystemUiMode: "

    .line 69
    .line 70
    invoke-static {v0, p1}, LK1/c;->o(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-direct {p0, p1}, Ljava/lang/NoSuchFieldException;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    throw p0
.end method

.method public static g(LE0/j;Lorg/json/JSONObject;)La2/c;
    .registers 12

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    const-string p0, "statusBarColor"

    .line 5
    .line 6
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    const/4 v1, 0x0

    .line 11
    if-nez v0, :cond_16

    .line 12
    .line 13
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    move-object v3, p0

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    move-object v3, v1

    .line 24
    :goto_17
    const-string p0, "statusBarIconBrightness"

    .line 25
    .line 26
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const/4 v2, 0x0

    .line 31
    if-nez v0, :cond_2a

    .line 32
    .line 33
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    invoke-static {p0}, LK1/c;->a(Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    move-result p0

    .line 41
    move v4, p0

    .line 42
    goto :goto_2b

    .line 43
    :cond_2a
    move v4, v2

    .line 44
    :goto_2b
    const-string p0, "systemStatusBarContrastEnforced"

    .line 45
    .line 46
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-nez v0, :cond_3d

    .line 51
    .line 52
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->getBoolean(Ljava/lang/String;)Z

    .line 53
    .line 54
    .line 55
    move-result p0

    .line 56
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    move-object v5, p0

    .line 61
    goto :goto_3e

    .line 62
    :cond_3d
    move-object v5, v1

    .line 63
    :goto_3e
    const-string p0, "systemNavigationBarColor"

    .line 64
    .line 65
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_50

    .line 70
    .line 71
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    .line 72
    .line 73
    .line 74
    move-result p0

    .line 75
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    move-object v6, p0

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move-object v6, v1

    .line 82
    :goto_51
    const-string p0, "systemNavigationBarIconBrightness"

    .line 83
    .line 84
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 85
    .line 86
    .line 87
    move-result v0

    .line 88
    if-nez v0, :cond_61

    .line 89
    .line 90
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    invoke-static {p0}, LK1/c;->a(Ljava/lang/String;)I

    .line 95
    .line 96
    .line 97
    move-result v2

    .line 98
    :cond_61
    move v7, v2

    .line 99
    const-string p0, "systemNavigationBarDividerColor"

    .line 100
    .line 101
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    if-nez v0, :cond_74

    .line 106
    .line 107
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    .line 108
    .line 109
    .line 110
    move-result p0

    .line 111
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 112
    .line 113
    .line 114
    move-result-object p0

    .line 115
    move-object v8, p0

    .line 116
    goto :goto_75

    .line 117
    :cond_74
    move-object v8, v1

    .line 118
    :goto_75
    const-string p0, "systemNavigationBarContrastEnforced"

    .line 119
    .line 120
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    if-nez v0, :cond_85

    .line 125
    .line 126
    invoke-virtual {p1, p0}, Lorg/json/JSONObject;->getBoolean(Ljava/lang/String;)Z

    .line 127
    .line 128
    .line 129
    move-result p0

    .line 130
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    :cond_85
    move-object v9, v1

    .line 135
    new-instance v2, La2/c;

    .line 136
    .line 137
    invoke-direct/range {v2 .. v9}, La2/c;-><init>(Ljava/lang/Integer;ILjava/lang/Boolean;Ljava/lang/Integer;ILjava/lang/Integer;Ljava/lang/Boolean;)V

    .line 138
    .line 139
    .line 140
    return-object v2
.end method

.method public static j(Ljava/lang/String;IIII)Ljava/util/HashMap;
    .registers 7

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "text"

    .line 7
    .line 8
    invoke-virtual {v0, v1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    const-string p1, "selectionBase"

    .line 16
    .line 17
    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    const-string p1, "selectionExtent"

    .line 25
    .line 26
    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    const-string p1, "composingBase"

    .line 34
    .line 35
    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    const-string p1, "composingExtent"

    .line 43
    .line 44
    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    return-object v0
.end method

.method public static k(Landroid/text/Editable;Landroid/view/KeyEvent;Z)Z
    .registers 9

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getMetaState()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    invoke-static {p1}, Landroid/view/KeyEvent;->metaStateHasNoModifiers(I)Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    const/4 v0, 0x0

    .line 10
    if-nez p1, :cond_c

    .line 11
    .line 12
    goto :goto_4b

    .line 13
    :cond_c
    invoke-static {p0}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    invoke-static {p0}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    const/4 v2, -0x1

    .line 22
    if-eq p1, v2, :cond_4b

    .line 23
    .line 24
    if-eq v1, v2, :cond_4b

    .line 25
    .line 26
    if-eq p1, v1, :cond_1c

    .line 27
    .line 28
    goto :goto_4b

    .line 29
    :cond_1c
    const-class v2, LM/t;

    .line 30
    .line 31
    invoke-interface {p0, p1, v1, v2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    check-cast v1, [LM/t;

    .line 36
    .line 37
    if-eqz v1, :cond_4b

    .line 38
    .line 39
    array-length v2, v1

    .line 40
    if-lez v2, :cond_4b

    .line 41
    .line 42
    array-length v2, v1

    .line 43
    move v3, v0

    .line 44
    :goto_2b
    if-ge v3, v2, :cond_4b

    .line 45
    .line 46
    aget-object v4, v1, v3

    .line 47
    .line 48
    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 53
    .line 54
    .line 55
    move-result v4

    .line 56
    if-eqz p2, :cond_3b

    .line 57
    .line 58
    if-eq v5, p1, :cond_43

    .line 59
    .line 60
    :cond_3b
    if-nez p2, :cond_3f

    .line 61
    .line 62
    if-eq v4, p1, :cond_43

    .line 63
    .line 64
    :cond_3f
    if-le p1, v5, :cond_48

    .line 65
    .line 66
    if-ge p1, v4, :cond_48

    .line 67
    .line 68
    :cond_43
    invoke-interface {p0, v5, v4}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    .line 69
    .line 70
    .line 71
    const/4 p0, 0x1

    .line 72
    return p0

    .line 73
    :cond_48
    add-int/lit8 v3, v3, 0x1

    .line 74
    .line 75
    goto :goto_2b

    .line 76
    :cond_4b
    :goto_4b
    return v0
.end method


# virtual methods
.method public a(Landroid/view/KeyEvent;LM0/z;)V
    .registers 9

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    const/4 v2, 0x0

    .line 7
    if-eqz v0, :cond_e

    .line 8
    .line 9
    if-eq v0, v1, :cond_e

    .line 10
    .line 11
    invoke-virtual {p2, v2}, LM0/z;->a(Z)V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_e
    iget-object v3, p0, LE0/j;->g:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v3, LM2/j;

    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getUnicodeChar()I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    invoke-virtual {v3, v4}, LM2/j;->a(I)Ljava/lang/Character;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    if-eqz v0, :cond_1d

    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move v1, v2

    .line 31
    :goto_1e
    new-instance v0, LD0/h;

    .line 32
    .line 33
    const/4 v4, 0x4

    .line 34
    invoke-direct {v0, v4, p2}, LD0/h;-><init>(ILjava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    iget-object p2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast p2, LA1/d;

    .line 40
    .line 41
    new-instance v4, Ljava/util/HashMap;

    .line 42
    .line 43
    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 44
    .line 45
    .line 46
    if-eqz v1, :cond_32

    .line 47
    .line 48
    const-string v1, "keyup"

    .line 49
    .line 50
    goto :goto_34

    .line 51
    :cond_32
    const-string v1, "keydown"

    .line 52
    .line 53
    :goto_34
    const-string v5, "type"

    .line 54
    .line 55
    invoke-virtual {v4, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    const-string v1, "keymap"

    .line 59
    .line 60
    const-string v5, "android"

    .line 61
    .line 62
    invoke-virtual {v4, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getFlags()I

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    const-string v5, "flags"

    .line 74
    .line 75
    invoke-virtual {v4, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    invoke-virtual {p1, v2}, Landroid/view/KeyEvent;->getUnicodeChar(I)I

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    const-string v2, "plainCodePoint"

    .line 87
    .line 88
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getUnicodeChar()I

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    const-string v2, "codePoint"

    .line 100
    .line 101
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 105
    .line 106
    .line 107
    move-result v1

    .line 108
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    const-string v2, "keyCode"

    .line 113
    .line 114
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getScanCode()I

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    const-string v2, "scanCode"

    .line 126
    .line 127
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getMetaState()I

    .line 131
    .line 132
    .line 133
    move-result v1

    .line 134
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    const-string v2, "metaState"

    .line 139
    .line 140
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    const-string v1, "character"

    .line 144
    .line 145
    invoke-virtual {v3}, Ljava/lang/Character;->toString()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    invoke-virtual {v4, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getSource()I

    .line 153
    .line 154
    .line 155
    move-result v1

    .line 156
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    const-string v2, "source"

    .line 161
    .line 162
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getDeviceId()I

    .line 166
    .line 167
    .line 168
    move-result v1

    .line 169
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    const-string v2, "deviceId"

    .line 174
    .line 175
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    .line 179
    .line 180
    .line 181
    move-result p1

    .line 182
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 183
    .line 184
    .line 185
    move-result-object p1

    .line 186
    const-string v1, "repeatCount"

    .line 187
    .line 188
    invoke-virtual {v4, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    new-instance p1, LD0/h;

    .line 192
    .line 193
    const/4 v1, 0x5

    .line 194
    invoke-direct {p1, v1, v0}, LD0/h;-><init>(ILjava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    iget-object p2, p2, LA1/d;->f:Ljava/lang/Object;

    .line 198
    .line 199
    check-cast p2, Ly1/z;

    .line 200
    .line 201
    invoke-virtual {p2, v4, p1}, Ly1/z;->i(Ljava/lang/Object;Lb2/c;)V

    .line 202
    .line 203
    .line 204
    return-void
.end method

.method public c(Lc1/h;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LI0/b;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-virtual {p1}, Lc1/h;->e()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-nez v1, :cond_e

    .line 13
    .line 14
    return-object p1

    .line 15
    :cond_e
    invoke-virtual {p1}, Lc1/h;->c()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Landroid/os/Bundle;

    .line 20
    .line 21
    if-eqz v1, :cond_2e

    .line 22
    .line 23
    const-string v2, "google.messenger"

    .line 24
    .line 25
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-eqz v1, :cond_2e

    .line 30
    .line 31
    iget-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p1, Landroid/os/Bundle;

    .line 34
    .line 35
    invoke-virtual {v0, p1}, LI0/b;->a(Landroid/os/Bundle;)Lc1/p;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    sget-object v0, LI0/h;->g:LI0/h;

    .line 40
    .line 41
    sget-object v1, LI0/d;->h:LI0/d;

    .line 42
    .line 43
    invoke-virtual {p1, v0, v1}, Lc1/p;->j(Ljava/util/concurrent/Executor;Lc1/g;)Lc1/p;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    :cond_2e
    return-object p1
.end method

.method public e(Ljava/lang/Object;)V
    .registers 4

    .line 1
    iget v0, p0, LE0/j;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_4c

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LE0/j;

    .line 9
    .line 10
    iget-object v0, v0, LE0/j;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Ly1/z;

    .line 13
    .line 14
    iget-object v0, v0, Ly1/z;->g:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lb2/l;

    .line 17
    .line 18
    invoke-interface {v0, p1}, Lb2/l;->b(Ljava/lang/Object;)Ljava/nio/ByteBuffer;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, LS1/g;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, LS1/g;->a(Ljava/nio/ByteBuffer;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :pswitch_1d
    iget-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p1, LC0/f;

    .line 33
    .line 34
    iget-object v0, p1, LC0/f;->f:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v0, Ljava/util/concurrent/ConcurrentLinkedQueue;

    .line 37
    .line 38
    iget-object v1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v1, La2/l;

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->remove(Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    iget-object p1, p1, LC0/f;->f:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p1, Ljava/util/concurrent/ConcurrentLinkedQueue;

    .line 48
    .line 49
    invoke-virtual {p1}, Ljava/util/concurrent/ConcurrentLinkedQueue;->isEmpty()Z

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    if-nez p1, :cond_4b

    .line 54
    .line 55
    new-instance p1, Ljava/lang/StringBuilder;

    .line 56
    .line 57
    const-string v0, "The queue becomes empty after removing config generation "

    .line 58
    .line 59
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    iget v0, v1, La2/l;->a:I

    .line 63
    .line 64
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    const-string v0, "SettingsChannel"

    .line 72
    .line 73
    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 74
    .line 75
    .line 76
    :cond_4b
    return-void

    .line 77
    :pswitch_data_4c
    .packed-switch 0x19
        :pswitch_1d
    .end packed-switch
.end method

.method public get()Ljava/lang/Object;
    .registers 7

    .line 1
    new-instance v1, LM0/f;

    .line 2
    .line 3
    const/4 v0, 0x5

    .line 4
    invoke-direct {v1, v0}, LM0/f;-><init>(I)V

    .line 5
    .line 6
    .line 7
    new-instance v2, LJ0/g;

    .line 8
    .line 9
    const/4 v0, 0x5

    .line 10
    invoke-direct {v2, v0}, LJ0/g;-><init>(I)V

    .line 11
    .line 12
    .line 13
    sget-object v3, LE0/a;->f:LE0/a;

    .line 14
    .line 15
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, LD/i;

    .line 18
    .line 19
    invoke-virtual {v0}, LD/i;->get()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    move-object v4, v0

    .line 24
    new-instance v0, LE0/i;

    .line 25
    .line 26
    check-cast v4, LE0/l;

    .line 27
    .line 28
    iget-object v5, p0, LE0/j;->g:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v5, Ln2/a;

    .line 31
    .line 32
    invoke-direct/range {v0 .. v5}, LE0/i;-><init>(LG0/a;LG0/a;LE0/a;LE0/l;Ln2/a;)V

    .line 33
    .line 34
    .line 35
    return-object v0
.end method

.method public h(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string p2, "="

    .line 14
    .line 15
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iget-object p2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast p2, Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public i(LI2/e;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 9

    .line 1
    iget v0, p0, LE0/j;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_104

    .line 4
    .line 5
    .line 6
    instance-of v0, p2, LI2/m;

    .line 7
    .line 8
    if-eqz v0, :cond_18

    .line 9
    .line 10
    move-object v0, p2

    .line 11
    check-cast v0, LI2/m;

    .line 12
    .line 13
    iget v1, v0, LI2/m;->i:I

    .line 14
    .line 15
    const/high16 v2, -0x80000000

    .line 16
    .line 17
    and-int v3, v1, v2

    .line 18
    .line 19
    if-eqz v3, :cond_18

    .line 20
    .line 21
    sub-int/2addr v1, v2

    .line 22
    iput v1, v0, LI2/m;->i:I

    .line 23
    .line 24
    goto :goto_1d

    .line 25
    :cond_18
    new-instance v0, LI2/m;

    .line 26
    .line 27
    invoke-direct {v0, p0, p2}, LI2/m;-><init>(LE0/j;Lkotlin/coroutines/Continuation;)V

    .line 28
    .line 29
    .line 30
    :goto_1d
    iget-object p2, v0, LI2/m;->h:Ljava/lang/Object;

    .line 31
    .line 32
    invoke-static {}, Lr2/h;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    iget v2, v0, LI2/m;->i:I

    .line 37
    .line 38
    const/4 v3, 0x1

    .line 39
    if-eqz v2, :cond_3a

    .line 40
    .line 41
    if-ne v2, v3, :cond_32

    .line 42
    .line 43
    iget-object p1, v0, LI2/m;->k:Lj2/n;

    .line 44
    .line 45
    :try_start_2c
    invoke-static {p2}, Lkotlin/a;->b(Ljava/lang/Object;)V
    :try_end_2f
    .catch LJ2/a; {:try_start_2c .. :try_end_2f} :catch_30

    .line 46
    .line 47
    .line 48
    goto :goto_5b

    .line 49
    :catch_30
    move-exception p2

    .line 50
    goto :goto_57

    .line 51
    :cond_32
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 52
    .line 53
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 54
    .line 55
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    throw p1

    .line 59
    :cond_3a
    invoke-static {p2}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    iget-object p2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast p2, LE0/j;

    .line 65
    .line 66
    new-instance v2, Lj2/n;

    .line 67
    .line 68
    iget-object v4, p0, LE0/j;->g:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v4, LI/o;

    .line 71
    .line 72
    invoke-direct {v2, v4, p1}, Lj2/n;-><init>(LI/o;LI2/e;)V

    .line 73
    .line 74
    .line 75
    :try_start_4a
    iput-object v2, v0, LI2/m;->k:Lj2/n;

    .line 76
    .line 77
    iput v3, v0, LI2/m;->i:I

    .line 78
    .line 79
    invoke-virtual {p2, v2, v0}, LE0/j;->i(LI2/e;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p1
    :try_end_52
    .catch LJ2/a; {:try_start_4a .. :try_end_52} :catch_55

    .line 83
    if-ne p1, v1, :cond_5b

    .line 84
    .line 85
    goto :goto_5d

    .line 86
    :catch_55
    move-exception p2

    .line 87
    move-object p1, v2

    .line 88
    :goto_57
    iget-object v0, p2, LJ2/a;->e:LI2/e;

    .line 89
    .line 90
    if-ne v0, p1, :cond_5e

    .line 91
    .line 92
    :cond_5b
    :goto_5b
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 93
    .line 94
    :goto_5d
    return-object v1

    .line 95
    :cond_5e
    throw p2

    .line 96
    :pswitch_5f
    new-instance v0, Lz2/l;

    .line 97
    .line 98
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 99
    .line 100
    .line 101
    new-instance v1, LI2/l;

    .line 102
    .line 103
    iget-object v2, p0, LE0/j;->g:Ljava/lang/Object;

    .line 104
    .line 105
    check-cast v2, LI/p;

    .line 106
    .line 107
    invoke-direct {v1, v0, p1, v2}, LI2/l;-><init>(Lz2/l;LI2/e;LI/p;)V

    .line 108
    .line 109
    .line 110
    iget-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 111
    .line 112
    check-cast p1, LE0/j;

    .line 113
    .line 114
    invoke-virtual {p1, v1, p2}, LE0/j;->i(LI2/e;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    invoke-static {}, Lr2/h;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object p2

    .line 122
    if-ne p1, p2, :cond_7c

    .line 123
    .line 124
    goto :goto_7e

    .line 125
    :cond_7c
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 126
    .line 127
    :goto_7e
    return-object p1

    .line 128
    :pswitch_7f
    instance-of v0, p2, LI2/j;

    .line 129
    .line 130
    if-eqz v0, :cond_92

    .line 131
    .line 132
    move-object v0, p2

    .line 133
    check-cast v0, LI2/j;

    .line 134
    .line 135
    iget v1, v0, LI2/j;->i:I

    .line 136
    .line 137
    const/high16 v2, -0x80000000

    .line 138
    .line 139
    and-int v3, v1, v2

    .line 140
    .line 141
    if-eqz v3, :cond_92

    .line 142
    .line 143
    sub-int/2addr v1, v2

    .line 144
    iput v1, v0, LI2/j;->i:I

    .line 145
    .line 146
    goto :goto_97

    .line 147
    :cond_92
    new-instance v0, LI2/j;

    .line 148
    .line 149
    invoke-direct {v0, p0, p2}, LI2/j;-><init>(LE0/j;Lkotlin/coroutines/Continuation;)V

    .line 150
    .line 151
    .line 152
    :goto_97
    iget-object p2, v0, LI2/j;->h:Ljava/lang/Object;

    .line 153
    .line 154
    invoke-static {}, Lr2/h;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object v1

    .line 158
    iget v2, v0, LI2/j;->i:I

    .line 159
    .line 160
    const/4 v3, 0x2

    .line 161
    const/4 v4, 0x1

    .line 162
    if-eqz v2, :cond_bf

    .line 163
    .line 164
    if-eq v2, v4, :cond_b3

    .line 165
    .line 166
    if-ne v2, v3, :cond_ab

    .line 167
    .line 168
    invoke-static {p2}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    goto :goto_f9

    .line 172
    :cond_ab
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 173
    .line 174
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 175
    .line 176
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    throw p1

    .line 180
    :cond_b3
    iget-object p1, v0, LI2/j;->m:LJ2/m;

    .line 181
    .line 182
    iget-object v2, v0, LI2/j;->l:LI2/e;

    .line 183
    .line 184
    iget-object v4, v0, LI2/j;->k:LE0/j;

    .line 185
    .line 186
    :try_start_b9
    invoke-static {p2}, Lkotlin/a;->b(Ljava/lang/Object;)V
    :try_end_bc
    .catchall {:try_start_b9 .. :try_end_bc} :catchall_bd

    .line 187
    .line 188
    .line 189
    goto :goto_e2

    .line 190
    :catchall_bd
    move-exception p2

    .line 191
    goto :goto_100

    .line 192
    :cond_bf
    invoke-static {p2}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 193
    .line 194
    .line 195
    new-instance p2, LJ2/m;

    .line 196
    .line 197
    iget-object v2, v0, Ls2/c;->f:Lq2/h;

    .line 198
    .line 199
    invoke-static {v2}, Lz2/g;->b(Ljava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    invoke-direct {p2, p1, v2}, LJ2/m;-><init>(LI2/e;Lq2/h;)V

    .line 203
    .line 204
    .line 205
    :try_start_cc
    iget-object v2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 206
    .line 207
    check-cast v2, LI/n;

    .line 208
    .line 209
    iput-object p0, v0, LI2/j;->k:LE0/j;

    .line 210
    .line 211
    iput-object p1, v0, LI2/j;->l:LI2/e;

    .line 212
    .line 213
    iput-object p2, v0, LI2/j;->m:LJ2/m;

    .line 214
    .line 215
    iput v4, v0, LI2/j;->i:I

    .line 216
    .line 217
    invoke-virtual {v2, p2, v0}, LI/n;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v2
    :try_end_dc
    .catchall {:try_start_cc .. :try_end_dc} :catchall_fc

    .line 221
    if-ne v2, v1, :cond_df

    .line 222
    .line 223
    goto :goto_fb

    .line 224
    :cond_df
    move-object v4, p0

    .line 225
    move-object v2, p1

    .line 226
    move-object p1, p2

    .line 227
    :goto_e2
    invoke-virtual {p1}, Ls2/c;->o()V

    .line 228
    .line 229
    .line 230
    iget-object p1, v4, LE0/j;->g:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast p1, LI2/q;

    .line 233
    .line 234
    const/4 p2, 0x0

    .line 235
    iput-object p2, v0, LI2/j;->k:LE0/j;

    .line 236
    .line 237
    iput-object p2, v0, LI2/j;->l:LI2/e;

    .line 238
    .line 239
    iput-object p2, v0, LI2/j;->m:LJ2/m;

    .line 240
    .line 241
    iput v3, v0, LI2/j;->i:I

    .line 242
    .line 243
    invoke-virtual {p1, v2, v0}, LI2/q;->i(LI2/e;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    if-ne p1, v1, :cond_f9

    .line 248
    .line 249
    goto :goto_fb

    .line 250
    :cond_f9
    :goto_f9
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 251
    .line 252
    :goto_fb
    return-object v1

    .line 253
    :catchall_fc
    move-exception p1

    .line 254
    move-object v5, p2

    .line 255
    move-object p2, p1

    .line 256
    move-object p1, v5

    .line 257
    :goto_100
    invoke-virtual {p1}, Ls2/c;->o()V

    .line 258
    .line 259
    .line 260
    throw p2

    .line 261
    :pswitch_data_104
    .packed-switch 0x4
        :pswitch_7f
        :pswitch_5f
    .end packed-switch
.end method

.method public l(IIII)Landroid/view/View;
    .registers 14

    .line 1
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LW/M;

    .line 4
    .line 5
    invoke-interface {v0}, LW/M;->g()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-interface {v0}, LW/M;->f()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    if-le p2, p1, :cond_10

    .line 14
    .line 15
    const/4 v3, 0x1

    .line 16
    goto :goto_11

    .line 17
    :cond_10
    const/4 v3, -0x1

    .line 18
    :goto_11
    const/4 v4, 0x0

    .line 19
    :goto_12
    if-eq p1, p2, :cond_44

    .line 20
    .line 21
    invoke-interface {v0, p1}, LW/M;->c(I)Landroid/view/View;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    invoke-interface {v0, v5}, LW/M;->n(Landroid/view/View;)I

    .line 26
    .line 27
    .line 28
    move-result v6

    .line 29
    invoke-interface {v0, v5}, LW/M;->j(Landroid/view/View;)I

    .line 30
    .line 31
    .line 32
    move-result v7

    .line 33
    iget-object v8, p0, LE0/j;->g:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v8, LW/L;

    .line 36
    .line 37
    iput v1, v8, LW/L;->b:I

    .line 38
    .line 39
    iput v2, v8, LW/L;->c:I

    .line 40
    .line 41
    iput v6, v8, LW/L;->d:I

    .line 42
    .line 43
    iput v7, v8, LW/L;->e:I

    .line 44
    .line 45
    if-eqz p3, :cond_37

    .line 46
    .line 47
    iput p3, v8, LW/L;->a:I

    .line 48
    .line 49
    invoke-virtual {v8}, LW/L;->a()Z

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    if-eqz v6, :cond_37

    .line 54
    .line 55
    return-object v5

    .line 56
    :cond_37
    if-eqz p4, :cond_42

    .line 57
    .line 58
    iput p4, v8, LW/L;->a:I

    .line 59
    .line 60
    invoke-virtual {v8}, LW/L;->a()Z

    .line 61
    .line 62
    .line 63
    move-result v6

    .line 64
    if-eqz v6, :cond_42

    .line 65
    .line 66
    move-object v4, v5

    .line 67
    :cond_42
    add-int/2addr p1, v3

    .line 68
    goto :goto_12

    .line 69
    :cond_44
    return-object v4
.end method

.method public n(Lc1/h;)V
    .registers 3

    .line 1
    iget-object p1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, LE0/j;

    .line 4
    .line 5
    iget-object p1, p1, LE0/j;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p1, Ljava/util/Map;

    .line 8
    .line 9
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lc1/i;

    .line 12
    .line 13
    invoke-interface {p1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public o(LJ1/a;)LE1/n;
    .registers 8

    .line 1
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashMap;

    .line 4
    .line 5
    iget-object v1, p1, LJ1/a;->b:Ljava/lang/reflect/Type;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    if-nez v2, :cond_f6

    .line 12
    .line 13
    iget-object p1, p1, LJ1/a;->a:Ljava/lang/Class;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    if-nez v0, :cond_f0

    .line 20
    .line 21
    const/4 v0, 0x0

    .line 22
    const/4 v2, 0x0

    .line 23
    :try_start_16
    new-array v3, v2, [Ljava/lang/Class;

    .line 24
    .line 25
    invoke-virtual {p1, v3}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    invoke-virtual {v3}, Ljava/lang/reflect/AccessibleObject;->isAccessible()Z

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    if-nez v4, :cond_29

    .line 34
    .line 35
    iget-object v4, p0, LE0/j;->g:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v4, LH1/b;

    .line 38
    .line 39
    invoke-virtual {v4, v3}, LH1/b;->a(Ljava/lang/reflect/AccessibleObject;)V

    .line 40
    .line 41
    .line 42
    :cond_29
    new-instance v4, LA1/d;

    .line 43
    .line 44
    const/4 v5, 0x2

    .line 45
    invoke-direct {v4, v5, v3}, LA1/d;-><init>(ILjava/lang/Object;)V
    :try_end_2f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_16 .. :try_end_2f} :catch_30

    .line 46
    .line 47
    .line 48
    goto :goto_31

    .line 49
    :catch_30
    move-object v4, v0

    .line 50
    :goto_31
    if-eqz v4, :cond_34

    .line 51
    .line 52
    return-object v4

    .line 53
    :cond_34
    const-class v3, Ljava/util/Collection;

    .line 54
    .line 55
    invoke-virtual {v3, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    if-eqz v3, :cond_82

    .line 60
    .line 61
    const-class v0, Ljava/util/SortedSet;

    .line 62
    .line 63
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-eqz v0, :cond_4c

    .line 68
    .line 69
    new-instance v0, LM0/f;

    .line 70
    .line 71
    const/4 v2, 0x3

    .line 72
    invoke-direct {v0, v2}, LM0/f;-><init>(I)V

    .line 73
    .line 74
    .line 75
    goto/16 :goto_e7

    .line 76
    .line 77
    :cond_4c
    const-class v0, Ljava/util/EnumSet;

    .line 78
    .line 79
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_5c

    .line 84
    .line 85
    new-instance v0, LD/i;

    .line 86
    .line 87
    const/4 v2, 0x2

    .line 88
    invoke-direct {v0, v2, v1}, LD/i;-><init>(ILjava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    goto/16 :goto_e7

    .line 92
    .line 93
    :cond_5c
    const-class v0, Ljava/util/Set;

    .line 94
    .line 95
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_6c

    .line 100
    .line 101
    new-instance v0, Lp1/e;

    .line 102
    .line 103
    const/4 v2, 0x3

    .line 104
    invoke-direct {v0, v2}, Lp1/e;-><init>(I)V

    .line 105
    .line 106
    .line 107
    goto/16 :goto_e7

    .line 108
    .line 109
    :cond_6c
    const-class v0, Ljava/util/Queue;

    .line 110
    .line 111
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    if-eqz v0, :cond_7b

    .line 116
    .line 117
    new-instance v0, LJ0/g;

    .line 118
    .line 119
    const/4 v2, 0x4

    .line 120
    invoke-direct {v0, v2}, LJ0/g;-><init>(I)V

    .line 121
    .line 122
    .line 123
    goto :goto_e7

    .line 124
    :cond_7b
    new-instance v0, LM0/f;

    .line 125
    .line 126
    const/4 v2, 0x4

    .line 127
    invoke-direct {v0, v2}, LM0/f;-><init>(I)V

    .line 128
    .line 129
    .line 130
    goto :goto_e7

    .line 131
    :cond_82
    const-class v3, Ljava/util/Map;

    .line 132
    .line 133
    invoke-virtual {v3, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 134
    .line 135
    .line 136
    move-result v3

    .line 137
    if-eqz v3, :cond_e7

    .line 138
    .line 139
    const-class v0, Ljava/util/concurrent/ConcurrentNavigableMap;

    .line 140
    .line 141
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-eqz v0, :cond_99

    .line 146
    .line 147
    new-instance v0, Lp1/e;

    .line 148
    .line 149
    const/4 v2, 0x4

    .line 150
    invoke-direct {v0, v2}, Lp1/e;-><init>(I)V

    .line 151
    .line 152
    .line 153
    goto :goto_e7

    .line 154
    :cond_99
    const-class v0, Ljava/util/concurrent/ConcurrentMap;

    .line 155
    .line 156
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 157
    .line 158
    .line 159
    move-result v0

    .line 160
    if-eqz v0, :cond_a8

    .line 161
    .line 162
    new-instance v0, LJ0/g;

    .line 163
    .line 164
    const/4 v2, 0x2

    .line 165
    invoke-direct {v0, v2}, LJ0/g;-><init>(I)V

    .line 166
    .line 167
    .line 168
    goto :goto_e7

    .line 169
    :cond_a8
    const-class v0, Ljava/util/SortedMap;

    .line 170
    .line 171
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    if-eqz v0, :cond_b7

    .line 176
    .line 177
    new-instance v0, LM0/f;

    .line 178
    .line 179
    const/4 v2, 0x2

    .line 180
    invoke-direct {v0, v2}, LM0/f;-><init>(I)V

    .line 181
    .line 182
    .line 183
    goto :goto_e7

    .line 184
    :cond_b7
    instance-of v0, v1, Ljava/lang/reflect/ParameterizedType;

    .line 185
    .line 186
    if-eqz v0, :cond_e1

    .line 187
    .line 188
    move-object v0, v1

    .line 189
    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    .line 190
    .line 191
    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    aget-object v0, v0, v2

    .line 196
    .line 197
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 198
    .line 199
    .line 200
    invoke-static {v0}, LE1/d;->b(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    invoke-static {v0}, LE1/d;->h(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    .line 205
    .line 206
    .line 207
    move-result-object v2

    .line 208
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 209
    .line 210
    .line 211
    const-class v0, Ljava/lang/String;

    .line 212
    .line 213
    invoke-virtual {v0, v2}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 214
    .line 215
    .line 216
    move-result v0

    .line 217
    if-nez v0, :cond_e1

    .line 218
    .line 219
    new-instance v0, Lp1/e;

    .line 220
    .line 221
    const/4 v2, 0x2

    .line 222
    invoke-direct {v0, v2}, Lp1/e;-><init>(I)V

    .line 223
    .line 224
    .line 225
    goto :goto_e7

    .line 226
    :cond_e1
    new-instance v0, LJ0/g;

    .line 227
    .line 228
    const/4 v2, 0x3

    .line 229
    invoke-direct {v0, v2}, LJ0/g;-><init>(I)V

    .line 230
    .line 231
    .line 232
    :cond_e7
    :goto_e7
    if-eqz v0, :cond_ea

    .line 233
    .line 234
    return-object v0

    .line 235
    :cond_ea
    new-instance v0, LC0/f;

    .line 236
    .line 237
    invoke-direct {v0, p1, v1}, LC0/f;-><init>(Ljava/lang/Class;Ljava/lang/reflect/Type;)V

    .line 238
    .line 239
    .line 240
    return-object v0

    .line 241
    :cond_f0
    new-instance p1, Ljava/lang/ClassCastException;

    .line 242
    .line 243
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 244
    .line 245
    .line 246
    throw p1

    .line 247
    :cond_f6
    new-instance p1, Ljava/lang/ClassCastException;

    .line 248
    .line 249
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 250
    .line 251
    .line 252
    throw p1
.end method

.method public onMethodCall(Lb2/m;Lb2/p;)V
    .registers 6

    .line 1
    iget-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LD/i;

    .line 4
    .line 5
    iget-object v1, v0, LD/i;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LC0/f;

    .line 8
    .line 9
    if-nez v1, :cond_14

    .line 10
    .line 11
    iget-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Ljava/util/Map;

    .line 14
    .line 15
    check-cast p2, LL1/f;

    .line 16
    .line 17
    invoke-virtual {p2, p1}, LL1/f;->b(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    iget-object p1, p1, Lb2/m;->a:Ljava/lang/String;

    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    const-string v1, "getKeyboardState"

    .line 27
    .line 28
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    if-nez p1, :cond_27

    .line 33
    .line 34
    check-cast p2, LL1/f;

    .line 35
    .line 36
    invoke-virtual {p2}, LL1/f;->c()V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :cond_27
    :try_start_27
    iget-object p1, v0, LD/i;->f:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast p1, LC0/f;

    .line 43
    .line 44
    iget-object p1, p1, LC0/f;->f:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p1, [LQ1/w;

    .line 47
    .line 48
    const/4 v0, 0x0

    .line 49
    aget-object p1, p1, v0

    .line 50
    .line 51
    check-cast p1, LQ1/v;

    .line 52
    .line 53
    iget-object p1, p1, LQ1/v;->f:Ljava/util/HashMap;

    .line 54
    .line 55
    invoke-static {p1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    iput-object p1, p0, LE0/j;->f:Ljava/lang/Object;
    :try_end_3c
    .catch Ljava/lang/IllegalStateException; {:try_start_27 .. :try_end_3c} :catch_3d

    .line 60
    .line 61
    goto :goto_4b

    .line 62
    :catch_3d
    move-exception p1

    .line 63
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    const-string v0, "error"

    .line 68
    .line 69
    move-object v1, p2

    .line 70
    check-cast v1, LL1/f;

    .line 71
    .line 72
    const/4 v2, 0x0

    .line 73
    invoke-virtual {v1, v0, p1, v2}, LL1/f;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :goto_4b
    iget-object p1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast p1, Ljava/util/Map;

    .line 79
    .line 80
    check-cast p2, LL1/f;

    .line 81
    .line 82
    invoke-virtual {p2, p1}, LL1/f;->b(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    return-void
.end method

.method public p(Ljava/lang/Class;Ljava/lang/String;)Landroidx/lifecycle/F;
    .registers 3

    .line 1
    const-string p1, "key"

    .line 2
    .line 3
    invoke-static {p2, p1}, Lz2/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    throw p1
.end method

.method public q(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .line 1
    const-string v0, "string"

    .line 2
    .line 3
    iget-object v1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ljava/lang/String;

    .line 6
    .line 7
    iget-object v2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Landroid/content/res/Resources;

    .line 10
    .line 11
    invoke-virtual {v2, p1, v0, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    if-nez p1, :cond_12

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    return-object p1

    .line 19
    :cond_12
    invoke-virtual {v2, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1
.end method

.method public r(Ljava/nio/ByteBuffer;LS1/g;)V
    .registers 8

    .line 1
    iget-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ly1/z;

    .line 4
    .line 5
    :try_start_4
    iget-object v1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lb2/b;

    .line 8
    .line 9
    iget-object v2, v0, Ly1/z;->g:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lb2/l;

    .line 12
    .line 13
    invoke-interface {v2, p1}, Lb2/l;->a(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    new-instance v2, LE0/j;

    .line 18
    .line 19
    const/16 v3, 0x1c

    .line 20
    .line 21
    const/4 v4, 0x0

    .line 22
    invoke-direct {v2, p0, p2, v3, v4}, LE0/j;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 23
    .line 24
    .line 25
    invoke-interface {v1, p1, v2}, Lb2/b;->b(Ljava/lang/Object;LE0/j;)V
    :try_end_1b
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_1b} :catch_1c

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :catch_1c
    move-exception p1

    .line 30
    new-instance v1, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    const-string v2, "BasicMessageChannel#"

    .line 33
    .line 34
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, v0, Ly1/z;->e:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v0, Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    const-string v1, "Failed to handle message"

    .line 49
    .line 50
    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 51
    .line 52
    .line 53
    const/4 p1, 0x0

    .line 54
    invoke-virtual {p2, p1}, LS1/g;->a(Ljava/nio/ByteBuffer;)V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public s(Ljava/lang/CharSequence;IILM/m;)Z
    .registers 12

    .line 1
    const/4 v0, 0x1

    .line 2
    iget v1, p4, LM/m;->c:I

    .line 3
    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x0

    .line 6
    if-nez v1, :cond_5b

    .line 7
    .line 8
    iget-object v1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, LM/d;

    .line 11
    .line 12
    invoke-virtual {p4}, LM/m;->b()LN/a;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    const/16 v5, 0x8

    .line 17
    .line 18
    invoke-virtual {v4, v5}, LC/t;->a(I)I

    .line 19
    .line 20
    .line 21
    move-result v5

    .line 22
    if-eqz v5, :cond_21

    .line 23
    .line 24
    iget-object v6, v4, LC/t;->d:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v6, Ljava/nio/ByteBuffer;

    .line 27
    .line 28
    iget v4, v4, LC/t;->a:I

    .line 29
    .line 30
    add-int/2addr v5, v4

    .line 31
    invoke-virtual {v6, v5}, Ljava/nio/ByteBuffer;->getShort(I)S

    .line 32
    .line 33
    .line 34
    :cond_21
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    sget-object v4, LM/d;->b:Ljava/lang/ThreadLocal;

    .line 38
    .line 39
    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    if-nez v5, :cond_34

    .line 44
    .line 45
    new-instance v5, Ljava/lang/StringBuilder;

    .line 46
    .line 47
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v4, v5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    :cond_34
    invoke-virtual {v4}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    check-cast v4, Ljava/lang/StringBuilder;

    .line 58
    .line 59
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 60
    .line 61
    .line 62
    :goto_3d
    if-ge p2, p3, :cond_48

    .line 63
    .line 64
    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    add-int/2addr p2, v0

    .line 72
    goto :goto_3d

    .line 73
    :cond_48
    iget-object p1, v1, LM/d;->a:Landroid/text/TextPaint;

    .line 74
    .line 75
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    sget p3, Lv/c;->a:I

    .line 80
    .line 81
    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->hasGlyph(Ljava/lang/String;)Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-eqz p1, :cond_58

    .line 86
    .line 87
    move p1, v2

    .line 88
    goto :goto_59

    .line 89
    :cond_58
    move p1, v0

    .line 90
    :goto_59
    iput p1, p4, LM/m;->c:I

    .line 91
    .line 92
    :cond_5b
    iget p1, p4, LM/m;->c:I

    .line 93
    .line 94
    if-ne p1, v2, :cond_60

    .line 95
    .line 96
    return v0

    .line 97
    :cond_60
    return v3
.end method

.method public t(LQ1/C;)Landroid/view/MotionEvent;
    .registers 9

    .line 1
    :goto_0
    iget-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/PriorityQueue;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    iget-object v2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Landroid/util/LongSparseArray;

    .line 12
    .line 13
    iget-wide v3, p1, LQ1/C;->a:J

    .line 14
    .line 15
    if-nez v1, :cond_2c

    .line 16
    .line 17
    invoke-virtual {v0}, Ljava/util/PriorityQueue;->peek()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Ljava/lang/Long;

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 24
    .line 25
    .line 26
    move-result-wide v5

    .line 27
    cmp-long v1, v5, v3

    .line 28
    .line 29
    if-gez v1, :cond_2c

    .line 30
    .line 31
    invoke-virtual {v0}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Ljava/lang/Long;

    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 38
    .line 39
    .line 40
    move-result-wide v0

    .line 41
    invoke-virtual {v2, v0, v1}, Landroid/util/LongSparseArray;->remove(J)V

    .line 42
    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_2c
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    if-nez p1, :cond_43

    .line 50
    .line 51
    invoke-virtual {v0}, Ljava/util/PriorityQueue;->peek()Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Ljava/lang/Long;

    .line 56
    .line 57
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 58
    .line 59
    .line 60
    move-result-wide v5

    .line 61
    cmp-long p1, v5, v3

    .line 62
    .line 63
    if-nez p1, :cond_43

    .line 64
    .line 65
    invoke-virtual {v0}, Ljava/util/PriorityQueue;->poll()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    :cond_43
    invoke-virtual {v2, v3, v4}, Landroid/util/LongSparseArray;->get(J)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    check-cast p1, Landroid/view/MotionEvent;

    .line 73
    .line 74
    invoke-virtual {v2, v3, v4}, Landroid/util/LongSparseArray;->remove(J)V

    .line 75
    .line 76
    .line 77
    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    .line 1
    iget v0, p0, LE0/j;->e:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_56

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :sswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const/16 v1, 0x64

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, LE0/j;->g:Ljava/lang/Object;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const/16 v1, 0x7b

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, LE0/j;->f:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v1, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    const/4 v3, 0x0

    .line 45
    :goto_2c
    if-ge v3, v2, :cond_43

    .line 46
    .line 47
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    check-cast v4, Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    add-int/lit8 v4, v2, -0x1

    .line 57
    .line 58
    if-ge v3, v4, :cond_40

    .line 59
    .line 60
    const-string v4, ", "

    .line 61
    .line 62
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    :cond_40
    add-int/lit8 v3, v3, 0x1

    .line 66
    .line 67
    goto :goto_2c

    .line 68
    :cond_43
    const/16 v1, 0x7d

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    return-object v0

    .line 78
    :sswitch_4d
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Ljava/util/HashMap;

    .line 81
    .line 82
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    return-object v0

    .line 87
    :sswitch_data_56
    .sparse-switch
        0x1 -> :sswitch_4d
        0xc -> :sswitch_a
    .end sparse-switch
.end method

.method public u(ZLcom/google/android/gms/common/api/Status;)V
    .registers 7

    .line 1
    iget-object v0, p0, LE0/j;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/Map;

    .line 4
    .line 5
    monitor-enter v0

    .line 6
    :try_start_5
    new-instance v1, Ljava/util/HashMap;

    .line 7
    .line 8
    iget-object v2, p0, LE0/j;->f:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v2, Ljava/util/Map;

    .line 11
    .line 12
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 13
    .line 14
    .line 15
    monitor-exit v0
    :try_end_f
    .catchall {:try_start_5 .. :try_end_f} :catchall_84

    .line 16
    iget-object v0, p0, LE0/j;->g:Ljava/lang/Object;

    .line 17
    .line 18
    move-object v2, v0

    .line 19
    check-cast v2, Ljava/util/Map;

    .line 20
    .line 21
    monitor-enter v2

    .line 22
    :try_start_15
    new-instance v0, Ljava/util/HashMap;

    .line 23
    .line 24
    iget-object v3, p0, LE0/j;->g:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v3, Ljava/util/Map;

    .line 27
    .line 28
    invoke-direct {v0, v3}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 29
    .line 30
    .line 31
    monitor-exit v2
    :try_end_1f
    .catchall {:try_start_15 .. :try_end_1f} :catchall_81

    .line 32
    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    :goto_27
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    if-eqz v2, :cond_4f

    .line 45
    .line 46
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    check-cast v2, Ljava/util/Map$Entry;

    .line 51
    .line 52
    if-nez p1, :cond_42

    .line 53
    .line 54
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    check-cast v3, Ljava/lang/Boolean;

    .line 59
    .line 60
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    if-nez v3, :cond_42

    .line 65
    .line 66
    goto :goto_27

    .line 67
    :cond_42
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 72
    .line 73
    .line 74
    new-instance p1, Ljava/lang/ClassCastException;

    .line 75
    .line 76
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 77
    .line 78
    .line 79
    throw p1

    .line 80
    :cond_4f
    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    :cond_57
    :goto_57
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 89
    .line 90
    .line 91
    move-result v1

    .line 92
    if-eqz v1, :cond_80

    .line 93
    .line 94
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    check-cast v1, Ljava/util/Map$Entry;

    .line 99
    .line 100
    if-nez p1, :cond_71

    .line 101
    .line 102
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    check-cast v2, Ljava/lang/Boolean;

    .line 107
    .line 108
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    if-eqz v2, :cond_57

    .line 113
    .line 114
    :cond_71
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    check-cast v1, Lc1/i;

    .line 119
    .line 120
    new-instance v2, LI0/q;

    .line 121
    .line 122
    invoke-direct {v2, p2}, LI0/q;-><init>(Lcom/google/android/gms/common/api/Status;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v1, v2}, Lc1/i;->c(Ljava/lang/Exception;)Z

    .line 126
    .line 127
    .line 128
    goto :goto_57

    .line 129
    :cond_80
    return-void

    .line 130
    :catchall_81
    move-exception p1

    .line 131
    :try_start_82
    monitor-exit v2
    :try_end_83
    .catchall {:try_start_82 .. :try_end_83} :catchall_81

    .line 132
    throw p1

    .line 133
    :catchall_84
    move-exception p1

    .line 134
    :try_start_85
    monitor-exit v0
    :try_end_86
    .catchall {:try_start_85 .. :try_end_86} :catchall_84

    .line 135
    throw p1
.end method
