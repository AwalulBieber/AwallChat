###### Class E0.d (E0.d)
.class public interface abstract LE0/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;
