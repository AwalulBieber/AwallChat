###### Class p003b.a (b.a)
.class public final Lb/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb/c;


# instance fields
.field public c:Landroid/os/IBinder;


# virtual methods
.method public final asBinder()Landroid/os/IBinder;
    .registers 2

    .line 1
    iget-object v0, p0, Lb/a;->c:Landroid/os/IBinder;

    .line 2
    .line 3
    return-object v0
.end method
