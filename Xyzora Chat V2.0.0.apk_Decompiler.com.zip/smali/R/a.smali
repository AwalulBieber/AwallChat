###### Class R.a (R.a)
.class public final LR/a;
.super LR/b;
.source "SourceFile"


# static fields
.field public static final b:LR/a;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, LR/a;

    .line 2
    .line 3
    invoke-direct {v0}, LR/b;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LR/a;->b:LR/a;

    .line 7
    .line 8
    return-void
.end method
